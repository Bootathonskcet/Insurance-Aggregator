package insurance;
import JavaBean.LoginJB;
import database.DataBaseConnect;
import insurance.admin.AdminHome;
import insurance.company.CompanyHome;
import insurance.company.CompanyRegistration;
import insurance.customer.CustomerHome;
import insurance.customer.CustomerRegistration;
import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
public class Login extends JFrame{
    Login(){
        setLayout(null);
        
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Container co=getContentPane();
        co.setBackground(java.awt.Color.LIGHT_GRAY);
        setExtendedState(MAXIMIZED_BOTH);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        setTitle("LOGIN");
       
        Font We4ufont=new Font("Georgia", Font.BOLD, 45);
        Font Buttonfont=new Font("Microsoft YaHei Light", Font.BOLD, 20);
        Font Textfont=new Font("Microsoft YaHei",Font.PLAIN, 18);
        Font Passfont=new Font("Microsoft YaHei",Font.PLAIN,16);       
         //Navigation bar
        JPanel nav=new JPanel();
        GroupLayout grouplayout=new GroupLayout(nav);
        nav.setBounds(0, 0, 400, 1000);
        nav.setBackground(new java.awt.Color(3,29,68));
        grouplayout.setAutoCreateGaps(true);
        grouplayout.setAutoCreateContainerGaps(true);
        nav.setLayout(grouplayout);
        add(nav);
       
            //Project title(WE4U)
            JLabel we4u=new JLabel("         WE4U   ");
            we4u.setForeground(Color.white);
            we4u.setFont(We4ufont);
           
            //Login Button
            Icon loginIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\login.png");
            JLabel loginIconLabel=new JLabel(loginIcon);
            JButton login=new JButton(" Login ");
            login.setBackground(new java.awt.Color(3,29,68));
            login.setForeground(new Color(255,255,255));
            login.setMaximumSize(new Dimension(400, 50));
            login.setFocusPainted(false);
            login.setBorder(null);
            login.setMaximumSize(new Dimension(400,60));
            login.setFont(Buttonfont);
            login.add(loginIconLabel);
            login.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mousePressed(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                login.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
                login.setBackground(new Color(3,29,68));
            }

            @Override
            public void mouseExited(MouseEvent e) {
               login.setBorder(null);
               login.setBackground(new Color(3,29,68));
            }
        });
            
            //Goback Button
            Icon gobackIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\goback.png");
            JLabel gobackIconLabel=new JLabel(gobackIcon);
            JButton goback=new JButton(" Go Back ");
            goback.setBackground(new java.awt.Color(64,61,57));
            goback.setForeground(new java.awt.Color(255,252,242));
            goback.setMaximumSize(new Dimension(300, 50));
            goback.setBackground(new java.awt.Color(3,29,68));
            goback.setForeground(new Color(255,255,255));
            goback.setFocusPainted(false);
            goback.setBorder(null);
            goback.setMaximumSize(new Dimension(400,60));
            goback.setFont(Buttonfont);
            goback.add(gobackIconLabel);
           goback.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mousePressed(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                goback.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
                goback.setBackground(new Color(3,29,68));
            }

            @Override
            public void mouseExited(MouseEvent e) {
               goback.setBorder(null);
               goback.setBackground(new Color(3,29,68));
            }
        });
            //adding the components of the nav bar using horizontalgroup method parallely
            grouplayout.setHorizontalGroup(grouplayout.createParallelGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.CENTER)
                    .addComponent(we4u))
                    .addComponent(login)
                    .addComponent(goback)
                   
            );
            // add the gaps between the components using verticalgroup method sequentially
            grouplayout.setVerticalGroup(grouplayout.createSequentialGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(we4u)).addGap(300)
                    .addComponent(login).addGap(30)
                    .addComponent(goback)
                 
            );
           
        // Main area(Login area)
        JPanel area1=new JPanel();//creating main area
        JPanel innerarea2=new JPanel();//This is for creating a gap between the innerarea1 and area1
        JPanel innerarea1=new JPanel();// creating inner form
        area1.setLayout(new BoxLayout(area1,BoxLayout.Y_AXIS));
        area1.setBounds(400, 0, 1517, 1000);
        area1.setBackground(new java.awt.Color(187,222,251));
            innerarea2.setMaximumSize(new Dimension(100, 200));
            innerarea2.setBackground(new java.awt.Color(187,222,251));
            innerarea1.setMaximumSize(new Dimension(600, 470));
            innerarea1.setBorder(new EmptyBorder(20, 100, 0, 100));
            innerarea1.setBackground(new Color(227,242,253));
           
                JPanel panel1=new JPanel();//creating a panel for Emailid(label and textfield)
                panel1.setBorder(new EmptyBorder(0,0,20,0));
                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel1.setBackground(new Color(227,242,253));
                JLabel email=new JLabel("Email Id    ");
                email.setFont(Textfont);
               
                JTextField Email=new JTextField();
                Email.setFont(Textfont);
                Email.setColumns(15);
                Email.setPreferredSize(new Dimension(300,40));
                panel1.add(email);
                panel1.add(Email);
                innerarea1.add(panel1);
               
                JPanel panel2=new JPanel();//creating a panel for password(label and textfield)
                panel2.setBorder(new EmptyBorder(0, 0, 20, 0));
                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel2.setBackground(new Color(227,242,253));
                JLabel password=new JLabel("Password       ");
                password.setFont(Textfont);
                
               
                JPasswordField Password=new JPasswordField();
                Password.setFont(Textfont);
                Password.setPreferredSize(new Dimension(300,40));
                Password.setColumns(15);
                panel2.add(password);
                panel2.add(Password);
                Icon eyeicon = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\eyeicon.png");
                JToggleButton eyebutton= new JToggleButton(eyeicon); 
                eyebutton.setBackground(new Color(227,242,253));
                eyebutton.setBorder(null);
                eyebutton.setFocusPainted(false);
                panel2.add(eyebutton);
                
                innerarea1.add(panel2);
                
                             
               
                
                
                
               eyebutton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(eyebutton.isSelected()){
                            Password.setEchoChar((char)0); //By this line of code. We will actually see the actual characters
                            
                        }else{
                            Password.setEchoChar('•');
                            
                        }
                    }
                });
                
                
                JPanel panel3=new JPanel();//Login button
                panel3.setBorder(new EmptyBorder(0,30,20,0));
                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel3.setBackground(new Color(227,242,253));
                JButton loginbutton=new JButton("     Login      ");
                loginbutton.setBorder(null);
                loginbutton.setBorder(new EmptyBorder(8, 30, 8, 30));
                loginbutton.setBackground(new java.awt.Color(3,29,68));
                loginbutton.setForeground(new java.awt.Color(255,255,255));
                loginbutton.setFont(Textfont);
                loginbutton.setFocusPainted(false);
                panel3.add(loginbutton);
                innerarea1.add(panel3);
                
                JPanel panel4=new JPanel();//creating a panel for password(label and textfield)
                panel4.setBorder(new EmptyBorder(0, 0, 20, 30));
                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel4.setBackground(new Color(227,242,253));
                JLabel NoAccount=new JLabel("Don't have an account?");
                NoAccount.setFont(Textfont);
               
                panel4.add(NoAccount);
                innerarea1.add(panel4);
                
                JPanel panel5=new JPanel();//creating a panel for password(label and textfield)
                panel5.setBorder(new EmptyBorder(0, 0, 20, 0));
                panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel5.setBackground(new Color(227,242,253));
                JLabel Register1=new JLabel("Customer---");
                JLabel CustomerRegister = new JLabel("Register Here");
                CustomerRegister.setFont(Textfont);
                CustomerRegister.setForeground(Color.blue);
                Register1.setFont(Textfont);
               
                panel5.add(Register1);
                panel5.add(CustomerRegister);
                innerarea1.add(panel5);
                
                JPanel panel6=new JPanel();//creating a panel for password(label and textfield)
                panel6.setBorder(new EmptyBorder(0, 0, 20, 0));
                panel6.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel6.setBackground(new Color(227,242,253));
                JLabel Register2=new JLabel("Company---");
                JLabel CompanyRegister = new JLabel("Register Here");
                CompanyRegister.setFont(Textfont);
                CompanyRegister.setForeground(Color.blue);
                Register2.setFont(Textfont);
               
                panel6.add(Register2);
                panel6.add(CompanyRegister);
                innerarea1.add(panel6);
               
        area1.add(innerarea2);
        area1.add(innerarea1);
        add(area1);
       
        setVisible(true);
        
        CustomerRegister.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                new CustomerRegistration();
                setVisible(false);
            }
        });
        CompanyRegister.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                new CompanyRegistration();
                setVisible(false);
            }
        });
        
        goback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Home();
            }
        });
        
        loginbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    LoginJB obj = new LoginJB();
                    obj.setEmail(Email.getText());
                    obj.setPassword(Password.getPassword().toString());
                    
                    int count=0;
                    //border for error fields
                    Border border_error = BorderFactory.createLineBorder(java.awt.Color.RED, 2);
                    Border border_normal = BorderFactory.createLineBorder(java.awt.Color.BLACK, 1);
                    
                    //email validation
                    String email_regex="^[a-z0-9]+[@]{1}[a-z.]+$";
                    System.out.println(obj.getEmail());
                   
                    if(Pattern.matches(email_regex,obj.getEmail())){
                        count++;
                        Email.setBorder(border_normal);
                        Email.setText(obj.getEmail());
                    }
                    else{
                        Email.setBorder(border_error);
                        //Email.setText("Invalid email");
                    }
                    //password validation
                    String password_regex="[A-Za-z0-9]*";
                    String pass_val = String.valueOf(obj.getPassword());
                    System.out.println(Pattern.matches(password_regex,pass_val));
                    if(pass_val.length()>2){
                        count++;
                        Password.setBorder(border_normal);
                        Password.setText(String.valueOf(Password.getPassword()));
                    }
                    else{
                        Password.setBorder(border_error);
                        //Password.setText("Invalid password");
                    }
                    
                    System.out.println(count);
                    Connection conn = null;
                    Statement stmt = null;

                   
                    System.out.println("Connecting to database...");
                    conn = DataBaseConnect.getConnection();

                    //STEP 4: Execute a query
                    System.out.println("Creating statement...");
                    stmt = conn.createStatement();
                    String sql;
                    
                    String id=UUID.randomUUID().toString();
                    System.out.println(id);
                    
                    if(count==2){
                        String pass="";
                        String email="";
                       
                         if(obj.getEmail().equals("admin@gmail.com") && String.valueOf(Password.getPassword()).equals("admin")){
                                new AdminHome();
                                setVisible(false);
                            }
                         
                         
                         else{
                            sql ="SELECT * from companyregistration where Email='"+obj.getEmail()+"'";
                            ResultSet rs = stmt.executeQuery(sql);
                            if(rs.next()){
                                String pwd=String.valueOf(Password.getPassword());
                                if(String.valueOf(rs.getString("Password")).equals(pwd)){

                                    new CompanyHome(rs.getString("Company_id")); 
                                    setVisible(false);

                                }

                                else{
                                    JOptionPane.showMessageDialog(rootPane, "Password is Wrong!");
                                }
                            }
                            else{
                                sql ="SELECT * from customerregistration where Email='"+obj.getEmail()+"'";
                                rs = stmt.executeQuery(sql);
                                if(rs.next()){
                                    String pwd=String.valueOf(Password.getPassword());
                                    if(String.valueOf(rs.getString("Password")).equals(pwd)){                                   

                                        new CustomerHome(rs.getString("Customer_id"));
                                        setVisible(false);

                                    }
                                    else{
                                        System.out.println(Password.getPassword().toString()+" "+rs.getString("Password"));
                                        JOptionPane.showMessageDialog(rootPane, "Password is Wrong!");
                                    }
                                }
                                else{
                                    JOptionPane.showMessageDialog(rootPane, "Email not found! Please register");
                                }
                            }
                    }
                         
                        //setVisible(false);
                    }
                    
                    stmt.close();
                    conn.close();
                }
                
                catch(Exception err){
                    System.out.println(err);
                }
            }
        });
        
       
    }
    public static void main(String [] args){
        new Login();
    }
}