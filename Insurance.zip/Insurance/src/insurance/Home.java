package insurance;
import insurance.company.CompanyRegistration;
import insurance.customer.CustomerRegistration;
import java.awt.Container;
import java.awt.ItemSelectable;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
public class Home extends JFrame{
    Container c;
    Home(){
        c=getContentPane();
        c.setLayout(null);
        setExtendedState(MAXIMIZED_BOTH); 
        setTitle("WE4U");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        
        //Fonts design
        Font navfont=new Font("Georgia",Font.BOLD,45);
        Font butfont=new Font("Microsoft YaHei", Font.BOLD, 20);
            //nav bar on top
            JPanel navigation=new JPanel();
            GroupLayout grouplyt=new GroupLayout(navigation);
            navigation.setBounds(0,0,1920,100);
            navigation.setBackground(new Color(3, 29, 68));
            navigation.setLayout(grouplyt);
            add(navigation);
            
            //We4 label in the top left corner of the nav bar
            JLabel we4u=new JLabel("    WE4U");
            we4u.setBounds(5,5,17,26);
            we4u.setForeground(Color.white);
            we4u.setFont(navfont);
            
            navigation.add(we4u);
            
            //Login button on the top right corner of the nav bar
            JButton login_button=new JButton("LOGIN");
            login_button.setBackground(new Color(3, 29, 68));
            login_button.setFont(butfont);
            login_button.setFocusPainted(false);
            login_button.setForeground(Color.white);
            login_button.setBorder(null);
            Icon icon0 = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\login.png");
            JLabel button3 = new JLabel(icon0);

            //setting the layout positioning for the contents in the nav bar
            grouplyt.setHorizontalGroup(  
                grouplyt.createSequentialGroup()  
                    .addGap(10)
                    .addComponent(we4u)  
                    .addGap(1520)
                    .addComponent(login_button)
                        .addGap(10)
                    .addComponent(button3));
            grouplyt.setVerticalGroup(  
                grouplyt.createParallelGroup(GroupLayout.Alignment.CENTER)
                    .addGap(90)
                    .addComponent(we4u)
                    
                    .addComponent(login_button)
                    .addComponent(button3));
            login_button.setAlignmentX(Component.RIGHT_ALIGNMENT);
            navigation.add(login_button);
            
            login_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new Login();
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }
        });
            
           
            login_button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent me) {
                //goback_button.setBackground(new Color(255,255,255,20));
                login_button.setForeground(Color.white);
                login_button.setBorder(new EmptyBorder(0, 0, 4, 0));
                login_button.setBorder(new MatteBorder(0, 0, 2, 0, Color.WHITE));
            }

            @Override
            public void mouseExited(MouseEvent e) {login_button.setForeground(Color.white);
                login_button.setBorder(null);
            }
            
        });
            
            
            //creating my main  panel
            JPanel main=new JPanel();
            main.setLayout(new BoxLayout(main,BoxLayout.Y_AXIS));
            main.setBounds(130, 145, 1657, 700);
            main.setBackground(new Color(227, 242, 253));
            
            //headerlabel(first sub panel inside my main panel)
            JPanel sixth=new JPanel();
            sixth.setBackground(new Color(227, 242, 253));
            sixth.setLayout(new FlowLayout(FlowLayout.CENTER));
            sixth.setBounds(250,100,120,50);
            sixth.setBorder(new EmptyBorder(0, 40, 0, 0));
                JLabel icon1=new JLabel();
                icon1.setBounds(100, 900, 70, 50);
                icon1.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\home.png"));
                validate();
                sixth.add(icon1);
                main.add(sixth);
            JPanel first=new JPanel();
            first.setLayout(new FlowLayout());
            first.setBackground(new Color(227, 242, 253));
            first.setBounds(0, 150, 1075, 100);
                //adding my topic label
                JLabel space=new JLabel();
                space.setBounds(350,200,1075,75);
                main.add(space);
                JLabel firstlabel=new JLabel("Quick, Hassle Free Buying");
                firstlabel.setForeground(Color.black);
                firstlabel.setFont(new Font("Georgia", Font.BOLD, 45));
                first.add(firstlabel);
                main.add(first);
            
            //paralabel(second subpanel inside main)
            JPanel second=new JPanel();
            second.setLayout(new FlowLayout());
            second.setBackground(new Color(227, 242, 253));
            second.setBounds(50, 250, 1075, 75);
                //adding my content label
                JLabel para=new JLabel("Insurance buying process was never this easy. Get your policy in your inbox within minutes!");
                para.setForeground(Color.black);
                para.setFont(new Font("Microsoft YaHei", Font.PLAIN, 22));
                second.add(para);
                main.add(second);
            
            //Bulletin1(third subpanel inside main)
            JPanel third=new JPanel();
            //third.setLayout(new FlowLayout(FlowLayout.LEADING));
            third.setBackground(new Color(227, 242, 253));
            third.setBounds(50,325,1075,50);
            third.setBorder(new EmptyBorder(50,0 , 0, 50));
                //add my tick in third panel
                JLabel firstpoint=new JLabel();
                firstpoint.setBounds(100, 270, 30, 30);
                firstpoint.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\checkedicon.png"));
                validate();
                third.add(firstpoint);
                
                //adding my first point
                JLabel one=new JLabel("    Get quotes from top insurers instantly.                     ");
                one.setForeground(Color.black);
                one.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
                third.add(one);
                main.add(third);
            
            //Bulletin2(fourth subpanel inside main)
            JPanel fourth=new JPanel();
            //fourth.setLayout(new FlowLayout(FlowLayout.LEADING));
            fourth.setBackground(new Color(227, 242, 253));
            fourth.setBounds(50,375,500,50);
            fourth.setBorder(new EmptyBorder(0, 0, 0, 10));
                //adding my tick in fourth panel
                JLabel secondpoint=new JLabel();
                secondpoint.setBounds(100, 270, 30, 30);
                secondpoint.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\checkedicon.png"));
                validate();
                fourth.add(secondpoint);
                
                //adding my second point
                JLabel two=new JLabel("    Compare plans. Save money by selecting the best plan.  ");
                two.setForeground(Color.black);
                two.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
                fourth.add(two);
                main.add(fourth);
                
            //Bulletin3(fifth subpanel inside main)
            JPanel fifth=new JPanel();
            //fifth.setLayout(new FlowLayout(FlowLayout.LEADING));
            fifth.setBackground(new Color(227, 242, 253));
            fifth.setBounds(50,425,500,50);
            fifth.setBorder(new EmptyBorder(0, 0, 0, 10));
                //adding my tick in fifth panel
                JLabel thirdpoint=new JLabel();
                thirdpoint.setBounds(100, 270, 30, 30);
                thirdpoint.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\checkedicon.png"));
                validate();
                fifth.add(thirdpoint);
                
                //adding my third point
                JLabel three=new JLabel("   Use any online payment method and get policy instantly.");
                three.setForeground(Color.black);
                three.setFont(new Font("Microsoft YaHei", Font.BOLD, 18));
                fifth.add(three);
                main.add(fifth);
                
            
            JPanel seventh=new JPanel();
            seventh.setBackground(new Color(227, 242, 253));
            seventh.setBounds(10,500,1200,200);
            GroupLayout grouplyt3=new GroupLayout(seventh);
            seventh.setLayout(grouplyt3);
            //customer sign up button on the left corner
            JButton customer_signup_button=new JButton("CUSTOMER SIGNUP");
            customer_signup_button.setBackground(new Color(227, 242, 253));
            customer_signup_button.setFont(butfont);
            customer_signup_button.setFocusPainted(false);
            customer_signup_button.setForeground(Color.black);
            customer_signup_button.setBorder(null);
            
            customer_signup_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new CustomerRegistration();
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }
        });
            
            Icon icon2 = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\profile1.png");
            JLabel button7 = new JLabel(icon2);
            
            //company signup button on the right corner
            JButton company_signup_button=new JButton("COMPANY SIGNUP");
            company_signup_button.setBackground(new Color(227, 242, 253));
            company_signup_button.setFont(butfont);
            company_signup_button.setFocusPainted(false);
            company_signup_button.setForeground(Color.black);
            company_signup_button.setBorder(null);
            
            company_signup_button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new CompanyRegistration();
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }
        });
            
            Icon icon3 = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\building.png");
            JLabel button8 = new JLabel(icon3);
            
            grouplyt3.setHorizontalGroup(  
            grouplyt3.createSequentialGroup() 
                .addComponent(button7)
                .addGap(5)
                .addComponent(customer_signup_button)
                .addGap(480)
                .addComponent(button8)
                 .addGap(5)
                .addComponent(company_signup_button)); 
            grouplyt3.setVerticalGroup(  
                grouplyt3.createParallelGroup(GroupLayout.Alignment.CENTER)
                    .addComponent(button7)
                    .addGap(280)
                    .addComponent(customer_signup_button)
                    .addComponent(button8)
                   
                    .addComponent(company_signup_button));
            seventh.add(customer_signup_button);
            seventh.add(company_signup_button);
            main.add(seventh);
            c.add(main);
            customer_signup_button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent me) {
                //goback_button.setBackground(new Color(255,255,255,20));
                customer_signup_button.setForeground(Color.black);
                customer_signup_button.setBorder(new EmptyBorder(0, 0, 4, 0));
                customer_signup_button.setBorder(new MatteBorder(0, 0, 2, 0, Color.black));
                login_button.setForeground(Color.white);
            }

            @Override
            public void mouseExited(MouseEvent e) {login_button.setForeground(Color.black);
                customer_signup_button.setBorder(null);
                login_button.setForeground(Color.white);
            }
            
        });
            company_signup_button.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent me) {
                //goback_button.setBackground(new Color(255,255,255,20));
                company_signup_button.setForeground(Color.black);
                company_signup_button.setBorder(new EmptyBorder(0, 0, 4, 0));
                company_signup_button.setBorder(new MatteBorder(0, 0, 2, 0, Color.black));
            }

            @Override
            public void mouseExited(MouseEvent e) {login_button.setForeground(Color.white);
                company_signup_button.setBorder(null);
            }
            
        });
            //creating a new panel for footer bar
            JPanel footer=new JPanel();
            GroupLayout grouplyt2=new GroupLayout(footer);
            footer.setBounds(0,900,1920,100);
            footer.setBackground(new Color(3, 29, 68));
            footer.setLayout(grouplyt2);
            add(footer);
            //contact us label
            JLabel contact_icon=new JLabel();
            contact_icon.setBounds(5, 0, 150, 61);
            contact_icon.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\phoneICON.png"));
            validate();
            footer.add(contact_icon);
            JLabel contact=new JLabel("CONTACT US:");
            contact.setBounds(50,0,150,61);
            contact.setForeground(new Color(255,252,242));
            contact.setFont(butfont);
            footer.add(contact);
            //mobile number label
            JLabel contact_mobile=new JLabel("9485632145");
            contact_mobile.setBounds(50,5,150,135);
            contact_mobile.setForeground(new Color(255,252,242));
            contact_mobile.setFont(butfont);
            footer.add(contact_mobile);
            //email label
            JLabel email_icon=new JLabel();
            email_icon.setBounds(1675, 45, 200, 61);
            email_icon.setIcon(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\gmailicon.png"));
            validate();
            footer.add(email_icon);
            JLabel contact_email=new JLabel("we4u@gmail.com");
            contact_email.setBounds(1725,45,200,61);
            contact_email.setForeground(new Color(255,252,242));
            contact_email.setFont(butfont);
            footer.add(contact_email);
           
       
        c.setBackground(new Color(187, 222, 251));
        
        setVisible(true);
    }
    public static void main(String[] args) {
        new Home();
    }
   
}