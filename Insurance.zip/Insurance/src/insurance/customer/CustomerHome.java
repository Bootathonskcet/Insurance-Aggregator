package insurance.customer;

import JavaBean.BoughtPoliciesJB;
import JavaBean.CustomerRegistrationJB;
import JavaBean.PaymentJB;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Button;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileReader;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.toedter.calendar.JDateChooser;
import database.DataBaseConnect;


import javax.swing.JTable;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Popup;
import javax.swing.PopupFactory;
import javax.swing.border.LineBorder;
import java.util.Properties;
import java.util.Vector;
import java.util.Properties;
import java.util.regex.Pattern;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.border.Border;


public class CustomerHome extends JFrame implements ActionListener ,MouseListener{
    private Font  BUTTON_FONT=new Font("Microsoft YaHei",Font.BOLD,18);
    private Font  TABLE_FONT=new Font("Microsoft YaHei",Font.PLAIN,18);
    private Font WE4U_FONT=new Font("Georgia",Font.BOLD,45);
    private JButton policies,payPremium,explorePolicies,profile,claim,completed,submitBtn;
    private JPanel mainPanel,profileForm,policiesForm,payPremiumForm,explorePoliciesForm,inner;
    private JTextField firstNameTextField,lastNameTextField,emailTextField,DOB,stateComboBox, districtComboBox;
    private JTextField passwordTextField;
    private Map<String,ArrayList<String>> districtsMap;
    private ArrayList<String>states;
    String company_id="",policy_id="",policyName="";
    LocalDate start_date = java.time.LocalDate.now();
    JLabel duration,frequency;
    JPanel view_policy_filter,explore_policy,claim_policy,completed_policy;
    JTable policyTableEp,policyTablePp,policyTable,claimTable,completedTable;
    String cust_acc,cust_mail;

    public CustomerHome(String customer_id){
        String id=customer_id;
        setLayout(null);
        setTitle("  WE4U");
        setExtendedState(MAXIMIZED_BOTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        Container container=getContentPane();
        BoughtPoliciesJB bp = new BoughtPoliciesJB();


        //navigation
        JPanel nav=new JPanel();
        GroupLayout groupLayout = new GroupLayout(nav);  
        groupLayout.setAutoCreateGaps(true);  
        groupLayout.setAutoCreateContainerGaps(true);  
        nav.setLayout(groupLayout);  


        JLabel we4u=new JLabel("       WE4U");
        we4u.setForeground(Color.WHITE);
        we4u.setFont(WE4U_FONT);

        Icon policyIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\policy.png");
        JLabel policyIconLabel=new JLabel(policyIcon);
        policies = new JButton("Your Policies");
        policies.setBackground(new Color(3,29,68));
        policies.setMaximumSize(new Dimension(400,60));
        policies.setForeground(new Color(255, 252, 242));
        policies.setFont(TABLE_FONT);
        policies.setFocusPainted(false);
        policies.setBorder(null);
        policies.addActionListener(this);
        policies.addMouseListener(this);        
        policies.add(policyIconLabel);

//		nav.add(policies); 


        Icon paymentIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\payment.png");
        JLabel paymentIconLabel=new JLabel(paymentIcon);
        payPremium = new JButton("Pay Premium");
        payPremium.setBackground(new Color(3,29,68));
        payPremium.setMaximumSize(new Dimension(400,60));
        payPremium.setForeground(new Color(255, 252, 242));
        payPremium.setFont(TABLE_FONT);
        payPremium.setFocusPainted(false);
        payPremium.setBorder(null);
        payPremium.addActionListener(this);
        payPremium.addMouseListener(this);
        payPremium.add(paymentIconLabel);
        //nav.add(payPremium);

        Icon exploreIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png");
        JLabel exploreIconLabel=new JLabel(exploreIcon);
        explorePolicies = new JButton("Explore Policies");
        explorePolicies.setBackground(new Color(3,29,68));
        explorePolicies.setMaximumSize(new Dimension(400,60));
        explorePolicies.setForeground(new Color(255, 252, 242));
        explorePolicies.setFont(TABLE_FONT);
        explorePolicies.setFocusPainted(false);
        explorePolicies.setBorder(null);
        explorePolicies.addActionListener(this);
        explorePolicies.addMouseListener(this);
        explorePolicies.add(exploreIconLabel);
        //nav.add(explorePolicies);	
        
        Icon profileIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\user.png");
        JLabel profileIconLabel=new JLabel(profileIcon);
        profile = new JButton("Profile");
        profile.setBackground(new Color(3,29,68));
        profile.setMaximumSize(new Dimension(400,60));
        profile.setForeground(new Color(255, 252, 242));
        profile.setFont(TABLE_FONT);
        profile.setBorder(new LineBorder(Color.WHITE, 0));
        profile.setFocusPainted(false);
        profile.setBorder(null);
        profile.addActionListener(this);
        profile.addMouseListener(this);
        profile.add(profileIconLabel);

        //nav.add(profile);
        Icon claimIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\claim.png");
        JLabel claimIconLabel=new JLabel(claimIcon);
        claim = new JButton("Claim");
        claim.setBackground(new Color(3,29,68));
        claim.setMaximumSize(new Dimension(400,60));
        claim.setForeground(new Color(255, 252, 242));
        claim.setFont(TABLE_FONT);
        claim.setBorder(new LineBorder(Color.WHITE, 0));
        claim.setFocusPainted(false);
        claim.setBorder(null);
        claim.addActionListener(this);
        claim.addMouseListener(this);
        claim.add(claimIconLabel);
        
        Icon completedIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\completed.png");
        JLabel completedIconLabel=new JLabel(completedIcon);
        completed = new JButton("Completed/Claimed Policies");
        completed.setBackground(new Color(3,29,68));
        completed.setMaximumSize(new Dimension(400,60));
        completed.setForeground(new Color(255, 252, 242));
        completed.setFont(TABLE_FONT);
        completed.setBorder(new LineBorder(Color.WHITE, 0));
        completed.setFocusPainted(false);
        completed.setBorder(null);
        completed.addActionListener(this);
        completed.addMouseListener(this);
        completed.add(completedIconLabel);
        
        
        Icon logoutIcon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\logout.png");
        JLabel logoutIconLabel=new JLabel(logoutIcon);
        JButton logout = new JButton("Logout");
        logout.setBackground(new Color(3,29,68));
        logout.setMaximumSize(new Dimension(400,60));
        logout.setForeground(new Color(255, 252, 242));
        logout.setFont(TABLE_FONT);
        logout.setBorder(new LineBorder(Color.WHITE, 0));
        logout.setFocusPainted(false);
        logout.setBorder(null);
        logout.addActionListener(this);
        logout.addMouseListener(this);
        logout.add(logoutIconLabel);
        
        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        

        groupLayout.setHorizontalGroup(groupLayout.createParallelGroup()
        .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(we4u))
        .addComponent(policies)
        .addComponent(payPremium)
        .addComponent(explorePolicies)
        .addComponent(profile)
        .addComponent(claim)
        .addComponent(completed)
        .addComponent(logout));

        groupLayout.setVerticalGroup(groupLayout.createSequentialGroup()
        .addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(we4u)).addGap(100)
        .addComponent(policies)
                .addGap(30)
        .addComponent(payPremium)
                .addGap(30)
        .addComponent(explorePolicies)
                .addGap(30)
        .addComponent(profile)
        .addGap(30)
        .addComponent(claim)
        .addGap(30)
        .addComponent(completed)
        .addGap(30)
        .addComponent(logout));


        nav.setBounds(0,0,400,1000);
        nav.setBackground(new Color(3,29,68));

        add(nav);


        mainPanel=new JPanel();
        mainPanel.setBounds(400,0,1517,1000);

        mainPanel.setBackground(new Color(187,222,251));
        
        
        profileForm=new JPanel();
        //profileForm.setBackground(Color.BLUE);
        profileForm.setLayout(new BoxLayout(profileForm,BoxLayout.Y_AXIS));
        profileForm.setPreferredSize(new Dimension(1200,730));
        profileForm.setBackground(new Color(227, 242, 253));
        //profile form
            try{

                Connection conn = null;
                Statement stmt1 = null,stmt2=null;


                System.out.println("Connecting to database...");
               conn = DataBaseConnect.getConnection();

                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                stmt1 = conn.createStatement();
                String sql;
                sql = "select * from customerregistration where Customer_id='"+customer_id+"'";
                ResultSet rs = stmt1.executeQuery(sql);
                
                while(rs.next()){
                    System.out.println(1);
                    

                    JPanel innerarea2=new JPanel();
                    //innerarea2.setLayout(new BoxLayout(innerarea2,BoxLayout.Y_AXIS));
                    innerarea2.setPreferredSize(new Dimension(100,50));
                    innerarea2.setBackground(new java.awt.Color(187,222,251));
                    innerarea2.setVisible(true);    
                    profileForm.add(innerarea2);

                    JPanel innerPanel=new JPanel();
                    JLabel firstNameLabel= new JLabel("First Name");
                    firstNameLabel.setFont(TABLE_FONT);
                    firstNameLabel.setForeground(Color.BLACK);
                    firstNameTextField =new JTextField(rs.getString("FirstName"));
                    firstNameTextField.setColumns(30);
                    firstNameTextField.setFont(TABLE_FONT);
                    firstNameTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    firstNameTextField.setBackground(new Color(227, 242, 253));
                    innerPanel.add(firstNameLabel);
                    innerPanel.add(firstNameTextField);
                    innerPanel.setBorder(new EmptyBorder(20, 0, 0, 0));
                    innerPanel.setBackground(new Color(227, 242, 253));
                    firstNameLabel.setPreferredSize(new Dimension(400,30));
                    firstNameTextField.setPreferredSize(new Dimension(400,30));
                    profileForm.add(innerPanel);

                    JPanel innerPanel1=new JPanel();
                    JLabel lastNameLabel= new JLabel("Last Name");
                    lastNameLabel.setForeground(Color.BLACK);
                    lastNameLabel.setFont(TABLE_FONT);
                    lastNameTextField =new JTextField(rs.getString("LastName"));
                    lastNameTextField.setColumns(30);
                    lastNameTextField.setFont(TABLE_FONT);
                    lastNameTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    lastNameTextField.setBackground(new Color(227, 242, 253));
                    lastNameLabel.setPreferredSize(new Dimension(400,30));
                    lastNameTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel1.add(lastNameLabel);
                    innerPanel1.add(lastNameTextField);
                    innerPanel1.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel1);


                    JPanel innerPanel2=new JPanel();
                    JLabel DOBLabel=new JLabel("DOB:");
                    DOBLabel.setFont(TABLE_FONT);
                    DOBLabel.setForeground(Color.BLACK);
                    DOB=new JTextField(rs.getString("Date_Of_Birth"));
                    DOB.setEditable(false);
                    DOB.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    DOB.setBackground(new Color(227, 242, 253));
                    DOBLabel.setPreferredSize(new Dimension(400,30));
                    innerPanel2.add(DOBLabel);
                    innerPanel2.add(DOB);
                    DOB.setPreferredSize(new Dimension(200, 30));
                    DOB.setFont(TABLE_FONT);
                    innerPanel2.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel2);
                    
                    JDateChooser Date_of_birth=new JDateChooser();
                    Date_of_birth.setPreferredSize(new Dimension(310, 35));
                    Date_of_birth.setFont(TABLE_FONT);

                    innerPanel2.add(Date_of_birth);
                    profileForm.add(innerPanel2);


                    //parse JSON
                    populateDistrictsMap();


                    JPanel innerpanel3=new JPanel();//creating a panel for state(label and textfield)
                    JLabel lbl_state=new JLabel("State                    ");
                    lbl_state.setFont(TABLE_FONT);
                    lbl_state.setPreferredSize(new Dimension(400,30));
                    String S[]={"Select","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Karnataka","Kerala","Chhattisgarh","Uttar Pradesh","Goa", "Gujarat","Himachal Pradesh",
                    "Jammu and Kashmir","Jharkhand","West Bengal","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Punjab","Rajasthan","Sikkim",
                    "Tamil Nadu","Telangana","Tripura","Uttarakhand","Andaman and Nicobar","Pondicherry","Dadra and Nagar Haveli","Daman and Diu","Delhi","Chandigarh","Lakshadweep"};
                    JComboBox State=new JComboBox(S);
                    State.setPreferredSize(new Dimension(510, 35));
                    State.setFont(TABLE_FONT);
                    State.setBackground(Color.white);
                    

                    innerpanel3.add(lbl_state);
                    innerpanel3.add(State);
                    innerpanel3.setBackground(new Color(227,242,253));
                    profileForm.add(innerpanel3);


                    Object obj = null;
                    try {
                            obj = new JSONParser().parse(new FileReader("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\insurance\\districts.json"));
                    } catch (Exception e) {
                            e.printStackTrace();
                    } 

                    JSONObject jo = (JSONObject) obj;

                    ArrayList<String>states=new ArrayList<String>();
                    districtsMap=new HashMap<String,ArrayList<String>>();  

                    JSONArray jsonArray=(JSONArray)jo.get("states");

                    Iterator<JSONObject> it=jsonArray.iterator();

                    while(it.hasNext()) {
                            JSONObject temp1=it.next();
                            String state=temp1.get("state").toString();
                            states.add(state);

                            JSONArray districtsJSONArray=(JSONArray)temp1.get("districts");

                             Iterator<String> it2=districtsJSONArray.iterator();
                             ArrayList<String> districts=new ArrayList<String>();

                             while(it2.hasNext()) {
                                            districts.add(it2.next());
                             }
                             districtsMap.put(state,districts);

                    }

                    JPanel innerpanel4=new JPanel();//creating a panel for district(label and Datechooser(calendar))
                    innerpanel4.setBorder(new EmptyBorder(0, 0, 5, 0));
                    JLabel district=new JLabel("District                  ");
                    district.setFont(TABLE_FONT);
                    district.setPreferredSize(new Dimension(400, 35));


                    JComboBox District=new JComboBox();
                    
                    State.addItemListener(new ItemListener() {
                        @Override
                        public void itemStateChanged(ItemEvent e) {

                            if(e.getStateChange()==ItemEvent.SELECTED){
                                //District.add(districtsMap.get(State.getSelectedItem()).toArray());
                                District.removeAllItems();
                                Object dis[]=districtsMap.get(State.getSelectedItem()).toArray();
                                for(int d=0;d<dis.length;d++){
                                    District.addItem(dis[d]);
                                }
                            }

                        }
                    });
                    District.setFont(TABLE_FONT);                
                    District.setPreferredSize(new Dimension(510, 35));
                    District.setBackground(Color.white);
                    
                    innerpanel4.add(district);
                    innerpanel4.add(District); 
                    innerpanel4.setBackground(new Color(227,242,253));
                    State.setSelectedItem(rs.getString("State"));
                    District.setSelectedItem(rs.getString("District"));
                    profileForm.add(innerpanel4);


                    

                    JPanel innerPanel5=new JPanel();
                    JLabel emailLabel= new JLabel("Email");
                    emailLabel.setFont(TABLE_FONT);
                    emailLabel.setForeground(Color.BLACK);
                    emailTextField =new JTextField(rs.getString("Email"));
                    emailTextField.setFont(TABLE_FONT);
                    emailTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    emailTextField.setBackground(new Color(227, 242, 253));
                    emailTextField.setColumns(30);
                    emailLabel.setPreferredSize(new Dimension(400,30));
                    emailTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel5.setBackground(new Color(227, 242, 253));
                    innerPanel5.add(emailLabel);
                    innerPanel5.add(emailTextField);

                    profileForm.add(innerPanel5);

                    JPanel innerPanel6=new JPanel();
                    JLabel passwordLabel= new JLabel("Password");
                    passwordLabel.setFont(TABLE_FONT);
                    passwordLabel.setForeground(Color.BLACK);
                    passwordTextField =new JTextField(rs.getString("Password"));
                    passwordTextField.setColumns(30);
                    passwordTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    passwordTextField.setBackground(new Color(227, 242, 253));
                    passwordTextField.setFont(TABLE_FONT);
                    passwordLabel.setPreferredSize(new Dimension(400,30));
                    passwordTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel6.add(passwordLabel);
                    innerPanel6.add(passwordTextField);
                    innerPanel6.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel6);

                    JPanel innerPanel7=new JPanel();
                    JLabel mobileNoLabel= new JLabel("Mobile");
                    mobileNoLabel.setFont(TABLE_FONT);
                    mobileNoLabel.setForeground(Color.BLACK);
                    JTextField mobileNoTextField =new JTextField(rs.getString("Mobile_no"));
                    mobileNoTextField.setColumns(30);
                    mobileNoTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    mobileNoTextField.setBackground(new Color(227, 242, 253));
                    mobileNoTextField.setFont(TABLE_FONT);
                    mobileNoLabel.setPreferredSize(new Dimension(400,30));
                    mobileNoTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel7.add(mobileNoLabel);
                    innerPanel7.add(mobileNoTextField);
                    innerPanel7.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel7);
                    
                    JPanel innerPanel8=new JPanel();
                    JLabel adhaarNoLabel= new JLabel("Aadhar");
                    adhaarNoLabel.setFont(TABLE_FONT);
                    adhaarNoLabel.setForeground(Color.BLACK);
                    JTextField adhaarNoTextField =new JTextField(rs.getString("Adhaar_no"));
                    adhaarNoTextField.setColumns(30);
                    adhaarNoTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    adhaarNoTextField.setBackground(new Color(227, 242, 253));
                    adhaarNoTextField.setFont(TABLE_FONT);
                    adhaarNoLabel.setPreferredSize(new Dimension(400,30));
                    adhaarNoTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel8.add(adhaarNoLabel);
                    innerPanel8.add(adhaarNoTextField);
                    innerPanel8.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel8);
                    
                    JPanel innerPanel9=new JPanel();
                    JLabel accountNoLabel= new JLabel("Account No.");
                    accountNoLabel.setFont(TABLE_FONT);
                    accountNoLabel.setForeground(Color.BLACK);
                    JTextField accountNoTextField =new JTextField(rs.getString("Account_no"));
                    accountNoTextField.setColumns(30);
                    accountNoTextField.setBorder(new MatteBorder(0,0,2,0,new Color(187,222,251)));
                    accountNoTextField.setBackground(new Color(227, 242, 253));
                    accountNoTextField.setFont(TABLE_FONT);
                    accountNoLabel.setPreferredSize(new Dimension(400,30));
                    accountNoTextField.setPreferredSize(new Dimension(400,30));
                    innerPanel9.add(accountNoLabel);
                    innerPanel9.add(accountNoTextField);
                    innerPanel9.setBackground(new Color(227, 242, 253));
                    profileForm.add(innerPanel9);
                    
                    JPanel innerPanel10=new JPanel(new BorderLayout(20, 0));//Login button
                    //panel4.setBorder(new MatteBorder(1, 1, 0,1,Color.white));
                    innerPanel10.setBorder(new EmptyBorder(30, 30, 0, 30));
                    innerPanel10.setLayout(new FlowLayout(FlowLayout.CENTER));
                    innerPanel10.setBackground(new Color(3,29,68));
                    JButton updatebutton=new JButton("Update");
                    updatebutton.setBorder(null);
                    updatebutton.setBorder(new EmptyBorder(8, 20, 8, 20));
                    updatebutton.setBackground(new java.awt.Color(255,183,3));
                    updatebutton.setForeground(Color.BLACK);
                    updatebutton.setFont(TABLE_FONT);
                    innerPanel10.add(updatebutton);
                    profileForm.add(innerPanel10);
                    updatebutton.addActionListener((ActionEvent e) -> {

                        try {
                            CustomerRegistrationJB ob = new CustomerRegistrationJB();
                            ob.setFirstName(firstNameTextField.getText());
                            ob.setLastName(lastNameTextField.getText());
                            ob.setDate_Of_Birth(((JTextField)Date_of_birth.getDateEditor().getUiComponent()).getText());
                            ob.setAdhaar_no(adhaarNoTextField.getText());
                            ob.setState(State.getSelectedItem().toString());
                            ob.setDistrict(District.getSelectedItem().toString());
                            ob.setEmail(emailTextField.getText());
                            ob.setPassword(passwordTextField.getText());
                            ob.setAccount_no(accountNoTextField.getText());
                            ob.setMobile(mobileNoTextField.getText());
                            //border for error fields
                            Border border_error = new MatteBorder(0,0,2,0,Color.RED);
                            Border border_normal = new MatteBorder(0,0,2,0,new Color(187,222,251));

                            int count=0;

                            //firstname validation
                            if(ob.getFirstName().length()>2){
                                count++;
                                firstNameTextField.setBorder(border_normal);
                                firstNameTextField.setText(ob.getFirstName());
                            }
                            else{
                                firstNameTextField.setBorder(border_error);
                                //First_Name.setText("Invalid name");
                            }
                            //lastname validation
                            if(ob.getLastName().length()>0){
                                count++;
                                lastNameTextField.setBorder(border_normal);
                                lastNameTextField.setText(ob.getLastName());
                            }
                            else{
                                lastNameTextField.setBorder(border_error);
                                //Last_Name.setText("Invalid name");
                            }
                            //date of birth validation
                            if(ob.getDate_Of_Birth().length()>2){
                                count++;
                                Date_of_birth.setBorder(border_normal);
                            }
                            else{
                                Date_of_birth.setBorder(border_error);
                            }
                            //state validation
                            if(!ob.getState().equals("--Select--")){
                                count++;
                                State.setBorder(border_normal);
                                State.setSelectedItem(ob.getState());
                            }
                            else{
                                State.setBorder(border_error);
                                //State.setSelectedItem("Invalid state");
                            }
                            //district validation
                            if(ob.getDistrict().length()>2){
                                count++;
                                District.setBorder(border_normal);
                                District.setSelectedItem(ob.getDistrict());
                            }
                            else{
                                District.setBorder(border_error);
                                //District.setSelectedItem("Invalid district");
                            }
                            //email validation
                            String email_regex="^[a-z0-9]+[@]{1}[a-z.]+$";

                            if(Pattern.matches(email_regex,ob.getEmail())){
                                count++;
                                emailTextField.setBorder(border_normal);
                                emailTextField.setText(ob.getEmail());
                            }
                            else{
                                emailTextField.setBorder(border_error);
                                //Email.setText("Invalid email");
                            }
                            //password validation
                            String password_regex="^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9])[A-Za-z0-9]*[^A-Za-z0-9]$";
                            if(Pattern.matches(password_regex,ob.getPassword().toString())){
                                count++;
                                passwordTextField.setBorder(border_normal);
                                passwordTextField.setText(ob.getPassword().toString());
                            }
                            else{
                                passwordTextField.setBorder(border_error);
                                //Password.setText("Invalid password");
                            }
                            //mobileno validation
                            if(ob.getMobile().length()==10){
                                count++;
                                mobileNoTextField.setBorder(border_normal);
                                mobileNoTextField.setText(ob.getMobile());
                            }
                            else{
                                mobileNoTextField.setBorder(border_error);
                                //Mobile_no.setText("Invalid mobile no");
                            }
                            //adhaar no validation
                            if(ob.getAdhaar_no().length()==12){
                                count++;
                                adhaarNoTextField.setBorder(border_normal);
                                adhaarNoTextField.setText(ob.getAdhaar_no());
                            }
                            else{
                                adhaarNoTextField.setBorder(border_error);
                                //Adhaar_number.setText("Invalid adhaar no");
                            }
                            //account no validation
                            if(ob.getAccount_no().length()==15){
                                count++;
                                accountNoTextField.setBorder(border_normal);
                                accountNoTextField.setText(ob.getAccount_no());
                            }
                            else{
                                accountNoTextField.setBorder(border_error);
                                //Account_no.setText("Invalid account no");
                            }

                            System.out.println(count);
                            Statement stmt3=null;
                            Connection conn1 = DataBaseConnect.getConnection();
                            stmt3 = conn1.createStatement();
                            String sql1;
        //                    int id=0;
        //                    sql = "SELECT max(Customer_id) from customerregistration";
        //                    ResultSet rs = stmt.executeQuery(sql);
        //                    while(rs.next()){
        //                        id = rs.getInt("max(Customer_id)");
        //                        id++;
        //                    }


                            if(count==10){
                                sql1 = "Update customerregistration set FirstName = '"+ob.getFirstName()+"',LastName = '"+ob.getLastName()+"',"
                                        + "Date_Of_Birth = '"+ob.getDate_Of_Birth()+"',State = '"+ob.getState()+"',District = '"+ob.getDistrict()+"',"
                                        + "Email = '"+ob.getEmail()+"',Password = '"+String.valueOf(ob.getPassword())+"',"
                                        + "Account_no = '"+ob.getAccount_no()+"',Mobile_no = '"+ob.getMobile()+"',Adhaar_no = '"+ob.getAdhaar_no()+"' where Customer_id = '"+customer_id+"'";
                                stmt3.executeUpdate(sql1);
                                JOptionPane.showMessageDialog(rootPane, "Updation Success!");
                                

                            }
                            //rs.close();
                            stmt3.close();
                            conn1.close();

                        }


                        catch(SQLIntegrityConstraintViolationException sql1){
                            JOptionPane.showMessageDialog(rootPane, "Aadhar or Account no. already in use!!!");
                            System.out.println(sql);
                        }
                        catch(Exception err){                    
                            JOptionPane.showMessageDialog(rootPane, "Enter Details!");
                            System.out.println(err);
                        }
            
                        
                    });
                    profileForm.setVisible(true);
                    
                    
                    
                    
                }

            }
            catch(Exception err){
                System.out.println(err);
            }
            mainPanel.add(profileForm);
            
            
            //policies form
            policiesForm=new JPanel();
            policiesForm.setBackground(new Color(227, 242, 253));
            Vector rowData=new Vector();
            String columnNames[]= {"Company Name","Policy Type","Policy Name","Premium","Start Date"
                            ,"End Date","Next Payment","Sum Insured","Frequency"};
            
            
            policyTable = new JTable();
            DefaultTableModel tableModel3 = (DefaultTableModel) policyTable.getModel();
            policyTable=new JTable(tableModel3);
            
            
            for(int i=0;i<columnNames.length;i++) {
                    tableModel3.addColumn(columnNames[i]);
            }


            tableModel3.addRow(columnNames);
            
            //divya's part
            try{

                Connection conn = null;
                Statement stmt1 = null,stmt2=null;


                System.out.println("Connecting to database...");
               conn = DataBaseConnect.getConnection();

                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                stmt1 = conn.createStatement();
                String sql;
                String status = "Completed";
                sql = "select * from bought_policies where Customer_id='"+customer_id+"' and Status<>'"+"Completed"+"'";
                ResultSet rs = stmt1.executeQuery(sql);
                
                while(rs.next()){
                    System.out.println(1);
                    String company_id = rs.getString("Company_id");
                    stmt2=conn.createStatement();
                    ResultSet rs1 = stmt2.executeQuery("select Company_name from companyregistration where Company_id='"+company_id+"'");
                    String cname="";
                    if(rs1.next()) {
                        cname=rs1.getString("Company_name");
                        System.out.println(cname);
                    }
                    rs1.close();
                    String[]innerData= {cname,rs.getString("Policy_type"),rs.getString("Policy_name"),String.valueOf(rs.getInt("Premium")),
                        rs.getString("Start_date").toString(),rs.getString("End_date").toString(),rs.getString("next_payment").toString(),
                        rs.getString("Sum_insured"),rs.getString("Frequency")};
                    System.out.println(innerData);
                    Vector colData=new Vector(Arrays.asList(innerData)); 
                    tableModel3.addRow(colData);
                    
                }

            }
            catch(Exception err){
                System.out.println(err);
            }

            policyTable.setDefaultEditor(Object.class, null);
            
            
//            int n=((DefaultTableModel)policyTable.getModel()).getRowCount();
//            ((DefaultTableModel)policyTable.getModel()).removeRow(0);


            policyTable.setBorder(new EmptyBorder(30, 0, 0, 0));
            policyTable.setShowGrid(false);
            policyTable.setShowHorizontalLines(true);
            policyTable.setSelectionBackground(Color.WHITE);
            policyTable.setPreferredSize(new Dimension(1400,900));
            policyTable.setForeground(Color.BLACK);
            policyTable.setBackground(new Color(227, 242, 253));
            policyTable.setFont(TABLE_FONT);
            policyTable.setIntercellSpacing(new Dimension(2,2));
            Color color = UIManager.getColor("Table.gridColor");
            MatteBorder border = new MatteBorder(1, 1, 1,1, Color.BLACK);
            policyTable.setBorder(border);


            JScrollPane scrollPane=new JScrollPane();
            scrollPane.setViewportView(policyTable);

            policyTable.setRowHeight(50);
            policiesForm.add(policyTable);

            mainPanel.add(policiesForm);
            policiesForm.setVisible(false);
            policies.addActionListener(this);
            

            //pay premium form
            payPremiumForm=new JPanel();//creating main area
            payPremiumForm.setBackground(new Color(227, 242, 253));
            
            inner = new JPanel();
            inner.setPreferredSize(new Dimension(100,50));
            inner.setBackground(new Color(187,222,251));
            mainPanel.add(inner);
            inner.setVisible(false);
            
//            policy name, company name ,next payment premium ,status  ---pay premium table
            Vector rowDataPp=new Vector();
            String columnNamesPp[]= {"Company Name","Policy Name","Next Payment","Premium","Status","Pay"};
            
            policyTablePp = new JTable();
            DefaultTableModel tableModel1 = (DefaultTableModel) policyTablePp.getModel();
            policyTablePp=new JTable(tableModel1);
            
            
            for(int i=0;i<columnNamesPp.length;i++) {
                    tableModel1.addColumn(columnNamesPp[i]);
            }


            tableModel1.addRow(columnNamesPp);
                        
            
            try{
            	
                Connection conn = null;
                Statement stmt1 = null,stmt2=null;


                System.out.println("Connecting to database...");
                conn = DataBaseConnect.getConnection();

                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                stmt1 = conn.createStatement();
                String sql;

                sql = "select * from bought_policies where Customer_id = '"+customer_id+"' and Status<>'"+"Completed"+"'";
                ResultSet rs = stmt1.executeQuery(sql);

                while(rs.next()){
                    System.out.println(1);
                    String company_id = rs.getString("Company_id");
                    stmt2=conn.createStatement();
                    ResultSet rs1 = stmt2.executeQuery("select Company_name from companyregistration where Company_id='"+company_id+"'");
                    String cname="";
                    if(rs1.next()) {
                        cname=rs1.getString("Company_name");
                        System.out.println(cname);
                    }
                    rs1.close();
                    
                    long millis=System.currentTimeMillis();  
                    java.sql.Date today_date=new java.sql.Date(millis);  
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                    Date end=df.parse(rs.getString("next_payment"));
                    long diffInMillies = Math.abs(end.getTime() - today_date.getTime());
                    long diffdays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                    String status="";
                    if(diffdays<0){
                        status= "Due";
                    }
                    else{
                        status = diffdays+" days left";
                    }

                    System.out.println(diffdays);
                    String[]innerData= {cname,rs.getString("Policy_name"),rs.getString("next_payment"),rs.getString("Premium"),status,"PAY"};
                    System.out.println(innerData);
                    Vector colData=new Vector(Arrays.asList(innerData)); 
                    tableModel1.addRow(colData);

                }

            }
            catch(Exception err){
                System.out.println(err);
            }
            policyTablePp.setShowGrid(false);
            policyTablePp.setShowHorizontalLines(true);
            policyTablePp.setPreferredSize(new Dimension(1400,870));
            policyTablePp.setForeground(Color.BLACK);
            policyTablePp.setBackground(new Color(227, 242, 253));
            policyTablePp.setFont(TABLE_FONT);
            Color colorEp = UIManager.getColor("Table.gridColor");
            MatteBorder borderEp = new MatteBorder(1, 1, 1,1, Color.black);
            policyTablePp.setBorder(borderEp);
            policyTablePp.setRowHeight(50);
            policyTablePp.setGridColor(new Color(3, 29, 68));
            policyTablePp.setIntercellSpacing(new Dimension(0,0));

            //policyTablePp.setDefaultEditor(Object.class, null);
            policyTablePp.setEnabled(true);
            
            
            policyTablePp.addMouseListener(new java.awt.event.MouseAdapter(){
            	public void mouseClicked(java.awt.event.MouseEvent evt) {

                    int row = policyTablePp.rowAtPoint(evt.getPoint());
                    int col = policyTablePp.columnAtPoint(evt.getPoint());
                    if(col==5) {
                    	try{
                    		
                            Connection conn = null;
                            Statement stmt1 = null,stmt2=null,stmt3=null;


                            System.out.println("Connecting to database...");
                            conn = DataBaseConnect.getConnection();

                            //STEP 4: Execute a query
                            System.out.println("Creating statement...");
                            stmt1 = conn.createStatement();
                            stmt2 = conn.createStatement();
                            stmt3 = conn.createStatement();
                            String sql;
                            
                            

                            policyTablePp.setEnabled(false);
                            String companyName=policyTablePp.getValueAt(row, 0).toString();
                            policyName=policyTablePp.getValueAt(row, 1).toString();
                            String nextPayment=policyTablePp.getValueAt(row, 2).toString();
                            String Premium=policyTablePp.getValueAt(row, 3).toString();
                            System.out.print(companyName+" "+policyName+" "+Premium+" ");
                            
                            policyTablePp.setEnabled(false);
                            //use this details to get frequency duration and start date
                            JPanel buyPanel=new JPanel();
                            buyPanel.setLayout(new BoxLayout(buyPanel,BoxLayout.Y_AXIS));
                            //buyPanel.setBounds(500, 500, 400, 200);
                            buyPanel.setPreferredSize(new Dimension(700,400));
                            buyPanel.setBackground(new Color(3,29,68));
                            
                            
                            ResultSet rs3 = stmt3.executeQuery("select Company_id from companyregistration where Company_Name = '"+companyName+"'");
                            if(rs3.next()) company_id = rs3.getString("Company_id");
                            System.out.println(company_id);
                            stmt3.close();
                            System.out.println(policyName);
                            ResultSet rs1 = stmt2.executeQuery("select * from policy where Policy_name ='"+policyName+"' and Company_id ='"+company_id+"'");
                            if(rs1.next()){
                                policy_id = rs1.getString("Policy_id");
                            }
                            rs1.close();
                            System.out.println(policy_id);
                            stmt2.close();
                            stmt2 = conn.createStatement();
                            String c_status="Completed";
                            sql = "select* from bought_policies where Customer_id='"+customer_id+"' and Policy_id='"+policy_id+"' and Status<>'"+c_status+"'";
                            ResultSet rs2 =  stmt2.executeQuery(sql);
                            //System.out.println(rs2.getString("Policy_id"));
                            
                            if(rs2.next()){
                                String CustomerName = rs2.getString("Customer_name");
                                String policyType=rs2.getString("Policy_type");
                                Popup buyPopup=new PopupFactory().getPopup(explorePoliciesForm,buyPanel,850,300);

                                JPanel panel1=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel1.setBackground(new Color(3,29,68));
                                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                                JLabel amountLabel=new JLabel("Payment Amount:");

                                amountLabel.setForeground(Color.WHITE);
                                amountLabel.setFont(TABLE_FONT);

                                JLabel amountPayableLabel=new JLabel();
                                amountPayableLabel.setFont(TABLE_FONT);
                                amountPayableLabel.setText(rs2.getString("Premium").toString());
                                amountPayableLabel.setForeground(Color.WHITE);


                                panel1.add(amountLabel);
                                panel1.add(amountPayableLabel);
                                buyPanel.add(panel1);


                                JPanel panel2=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel2.setBackground(new Color(3,29,68));
                                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                                JLabel dateLabel=new JLabel("Payment Date:");

                                dateLabel.setForeground(Color.WHITE);
                                dateLabel.setFont(TABLE_FONT);

                                JLabel dateShowLabel=new JLabel();
                                dateShowLabel.setFont(TABLE_FONT);
                                dateShowLabel.setText(new Date().toString());
                                dateShowLabel.setForeground(Color.WHITE);

                                //Date.setEditable(false);

                                panel2.add(dateLabel);
                                panel2.add(dateShowLabel);
                                buyPanel.add(panel2);


                                JPanel panel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel3.setBackground(new Color(3,29,68));
                                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                                panel3.setSize(70, 70);
                                JLabel policyLabel=new JLabel("Policy name:");

                                policyLabel.setForeground(Color.WHITE);
                                policyLabel.setFont(TABLE_FONT);

                                JLabel policyShowLabel=new JLabel();
                                policyShowLabel.setFont(TABLE_FONT);
                                policyShowLabel.setForeground(Color.WHITE);
                                policyShowLabel.setText(rs2.getString("Policy_name"));


                                panel3.add(policyLabel);
                                panel3.add(policyShowLabel);
                                buyPanel.add(panel3);

                                JPanel panel4=new JPanel(new BorderLayout(20, 0));//Login button
                                //panel4.setBorder(new MatteBorder(1, 1, 0,1,Color.white));
                                panel4.setBorder(new EmptyBorder(10, 30, 10, 30));
                                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                                panel4.setBackground(new Color(3,29,68));
                                JButton paybutton=new JButton("Pay Now");
                                paybutton.setBorder(null);
                                paybutton.setBorder(new EmptyBorder(8, 20, 8, 20));
                                paybutton.setBackground(new java.awt.Color(255,183,3));
                                paybutton.setForeground(Color.BLACK);
                                paybutton.setFont(TABLE_FONT);
                                paybutton.addActionListener((ActionEvent e) -> {
                                    
                                    try {
                                        PaymentJB obj = new PaymentJB();
                                        obj.setPolicy_name(policyName);
                                        obj.setPayment_amount(Integer.parseInt(amountPayableLabel.getText()));
                                        obj.setPayment_date(java.time.LocalDate.now());
                                        obj.setPayment_time(String.valueOf(java.time.LocalTime.now()));
                                        Connection conn1 = null;
                                        Statement stmt = null;
                                        System.out.println("Connecting to database...");
                                        conn1 = DataBaseConnect.getConnection();
                                        //STEP 4: Execute a query
                                        System.out.println("Creating statement...");
                                        stmt = conn1.createStatement();
                                        String sql1;
                                        String trans_id=UUID.randomUUID().toString();
                                        System.out.println(trans_id);
                                        sql1 = "INSERT INTO payment values('"+trans_id+"','"+policy_id+"','"+obj.getPolicy_name()+"',"
                                                + "'"+obj.getPayment_date()+"','"+obj.getPayment_time()+"','"+obj.getPayment_amount()+"',"
                                                + "'"+company_id+"','"+customer_id+"')";
                                        stmt.executeUpdate(sql1);
                                        JOptionPane.showMessageDialog(rootPane, "Payment Success!");
                                        stmt.close();
                                        //update ayment table to next payment of the month
                                        stmt = conn1.createStatement();
                                        ResultSet rs4 = stmt.executeQuery("select * from bought_policies where Policy_id='"+policy_id+"' and Customer_id='"+customer_id+"' and Status<>'"+"Completed"+"'");
                                        if (rs4.next()) {
                                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                            Calendar c = Calendar.getInstance();
                                            //Setting the date to the given date
                                            c.setTime(sdf.parse(nextPayment));
                                            int no_of_pay = rs4.getInt("No_of_payments");
                                            String freq = rs4.getString("Frequency");
                                            int diff=0;
                                            switch(freq){
                                                case "Monthly":{
                                                    diff=30;
                                                    break;
                                                }
                                                case "Quaterly":{                                                
                                                    diff=91;
                                                    break;
                                                }
                                                case "Semi-Annually":{
                                                    diff=182;
                                                    break;
                                                }
                                                case "Annually":{
                                                    diff=365;
                                                    break;
                                                }
                                            }
                                            c.add(Calendar.DAY_OF_MONTH,diff);
                                            String nextDate=sdf.format(c.getTime());
                                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                            LocalDate next_pay_Date = LocalDate.parse(nextDate, formatter);
                                            System.out.println("Next Date:"+nextDate);
                                            no_of_pay--;
                                            System.out.println("No_of pay updated"+no_of_pay);
                                            long millis=System.currentTimeMillis();
                                            java.sql.Date today_date=new java.sql.Date(millis);
                                            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                            Date end=df.parse(nextDate);
                                            long diffInMillies = Math.abs(end.getTime() - today_date.getTime());
                                            long diffdays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                                            String status="";
                                            if(diffdays<0){
                                                status= "Due";
                                            }
                                            else{                                        
                                                status = diffdays+" days left";
                                            }
                                            System.out.println(diffdays);
                                            if(no_of_pay<=0){
                                                status = "Completed";
                                            }
                                            sql1 = "update bought_policies set Next_payment = '"+next_pay_Date+"',No_of_payments='"+no_of_pay+"',Status='"+status+"' where Policy_id = '"+policy_id+"'";
                                            stmt=conn1.createStatement();
                                            stmt.executeUpdate(sql1);
                                            
                                            Statement stmt_cust=null;
                                            Connection conn_cust=DataBaseConnect.getConnection();
                                            
                                            String cust="select * from customerregistration where Customer_id='"+id+"'";
                                            stmt_cust=conn_cust.createStatement();
                                            ResultSet rs_cust=stmt_cust.executeQuery(cust);
                                            
                                            while(rs_cust.next()){
                                                cust_mail=rs_cust.getString("Email");
                                                cust_acc=rs_cust.getString("Account_no");
                                            }
                                                                                        
                                            //pay for policy send mail
                                            String host="smtp.gmail.com";
                                            final String user="hackaholics4@gmail.com";
                                            final String password="DaggUs4#";

                                            String to=cust_mail;
                                            
                                            int acc=Integer.valueOf(cust_acc.substring(11, 15));

                                            System.out.println(to+" "+acc);
                                            //imported code
                                            Properties props = new Properties();
                                            props.put("mail.smtp.starttls.enable", "true");
                                            props.put("mail.smtp.host", host);
                                            props.put("mail.smtp.user", user);
                                            props.put("mail.smtp.password", password);
                                            props.put("mail.smtp.port", "587");
                                            props.put("mail.smtp.auth", "true");

                                            
                                            Session session = Session.getDefaultInstance(props,
                                            new javax.mail.Authenticator() {
                                                @Override
                                                protected PasswordAuthentication getPasswordAuthentication() {
                                                    return new PasswordAuthentication(user,password);
                                                }
                                            });

                                            //imported code
                                            try {
                                                MimeMessage message = new MimeMessage(session);
                                                message.setFrom(new InternetAddress(user));
                                                message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                                                message.setSubject("WE4U | Receipt for your Payment");
                                                message.setContent("<h3>Hi "+CustomerName+",</h3><br>Hope you are doing well, We are WE4U ,on behalf of the "+companyName+" insurance Company for the policy "+policyName+",Thank you for the payment."
                                                        + " For your convenience we have attached the receipt of your payment. The charge will "
                                                        + "appear on your Account XXXXXXXXXXX"+acc+" as WE4U insurance .<br><br><table><tr><td>Transaction ID        </td><td>"+trans_id+"</td></tr><tr><td>Payment Date</td><td>"+obj.getPayment_date()+"</td></tr>"
                                                                +"<tr><td>Company</td><td>"+companyName+"</td></tr><tr><td>Insurance</td><td>"+obj.getPolicy_name()+"</td></tr><tr><td>Amount</td><td>"+obj.getPayment_amount()+"</td></tr><tr><td>Next payment date</td><td>"+next_pay_Date+"</td></tr>"
                                                                        + "<br>For any discrepancies,Contact us hackaholics4@gmail.com.<br><br>Regards,<br>WE4U Team.","text/html");


                                                        Transport.send(message);

                                                System.out.println("message sent!");

                                            }
                                            catch (MessagingException mex)
                                            {
                                                System.out.println("Error: unable to send message....");
                                                mex.printStackTrace();
                                            }
                                            setVisible(false);
                                            new CustomerHome(id);
                                        }
                                    }catch(Exception err){
                                        System.out.println(err);
                                    }
                                });


                                panel4.add(paybutton);
                                
                                JButton cancelbutton=new JButton("Cancel");
                                cancelbutton.setBackground(new java.awt.Color(255,183,3));
                                cancelbutton.setForeground(Color.BLACK);
                                cancelbutton.setFont(TABLE_FONT);
                                cancelbutton.setBorder(null);
                                cancelbutton.setBorder(new EmptyBorder(8, 15, 8, 15));
                                
                                cancelbutton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                            buyPopup.hide();
                                            policyTablePp.setEnabled(true);

                                    }

                                });
                            
                                panel4.add(cancelbutton);
                                buyPanel.add(panel4);

                                buyPopup.show();
                            }                   


                    		
                    	}
                    	 catch(Exception err){
                    		 System.out.println(err);
                    }
                    }
            	}
            });

            JScrollPane scrollPanePp=new JScrollPane();
            scrollPanePp.setViewportView(policyTablePp);

            //policyTablePp.setRowHeight(30);

            payPremiumForm.add(policyTablePp);

            mainPanel.add(payPremiumForm);
            payPremium.addActionListener(this);
            payPremiumForm.setVisible(false);
            
            
            //claim from
            claim_policy=new JPanel();
            policiesForm.setBackground(new Color(227, 242, 253));
            String columnNamescl[]= {"Company Name","Policy Type","Policy Name","Start Date","End Date","Sum Insured","Claim"};
            
            
            claimTable = new JTable();
            DefaultTableModel tableModel4 = (DefaultTableModel) claimTable.getModel();
            claimTable=new JTable(tableModel4);
            
            
            for(int i=0;i<columnNamescl.length;i++) {
                    tableModel4.addColumn(columnNamescl[i]);
            }


            tableModel4.addRow(columnNamescl);
            
            //divya's part
            try{

                Connection conn = null;
                Statement stmt1 = null,stmt2=null;


                System.out.println("Connecting to database...");
               conn = DataBaseConnect.getConnection();

                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                stmt1 = conn.createStatement();
                String sql;
                sql = "select * from bought_policies where Customer_id='"+customer_id+"' and Claimed_status='"+"Not Claimed"+"'";
                ResultSet rs = stmt1.executeQuery(sql);
                
                while(rs.next()){
                    System.out.println(1);
                    String company_id = rs.getString("Company_id");
                    stmt2=conn.createStatement();
                    ResultSet rs1 = stmt2.executeQuery("select Company_name from companyregistration where Company_id='"+company_id+"'");
                    String cname="";
                    if(rs1.next()) {
                        cname=rs1.getString("Company_name");
                        System.out.println(cname);
                    }
                    rs1.close();
                    String[]innerData= {cname,rs.getString("Policy_type"),rs.getString("Policy_name"),
                        rs.getString("Start_date"),rs.getString("End_date"),
                        rs.getString("Sum_insured"),"CLAIM"};
                    System.out.println(innerData);
                    Vector colData=new Vector(Arrays.asList(innerData)); 
                    tableModel4.addRow(colData);
                    
                }

            }
            catch(Exception err){
                System.out.println(err);
            }

            claimTable.setDefaultEditor(Object.class, null);
            
            
//            int n=((DefaultTableModel)policyTable.getModel()).getRowCount();
//            ((DefaultTableModel)policyTable.getModel()).removeRow(0);


            claimTable.setBorder(new EmptyBorder(30, 0, 0, 0));
            claimTable.setShowGrid(false);
            claimTable.setShowHorizontalLines(true);
            claimTable.setSelectionBackground(Color.WHITE);
            claimTable.setPreferredSize(new Dimension(1400,870));
            claimTable.setForeground(Color.BLACK);
            claimTable.setBackground(new Color(227, 242, 253));
            claimTable.setFont(TABLE_FONT);
            claimTable.setIntercellSpacing(new Dimension(2,2));
            claimTable.setBorder(border);


            scrollPane=new JScrollPane();
            scrollPane.setViewportView(claimTable);

            
            claimTable.setDefaultEditor(Object.class, null);
            claimTable.addMouseListener(new java.awt.event.MouseAdapter(){
            	public void mouseClicked(java.awt.event.MouseEvent evt) {

                    int row = claimTable.rowAtPoint(evt.getPoint());
                    int col = claimTable.columnAtPoint(evt.getPoint());
                    if(col==6) {
                    	try{
                    		
                            Connection conn = null;
                            Statement stmt1 = null,stmt2=null,stmt3=null;


                            System.out.println("Connecting to database...");
                            conn = DataBaseConnect.getConnection();

                            //STEP 4: Execute a query
                            System.out.println("Creating statement...");
                            stmt1 = conn.createStatement();
                            stmt2 = conn.createStatement();
                            stmt3 = conn.createStatement();
                            String sql;
                            
                            

                            claimTable.setEnabled(false);
                            String companyName=claimTable.getValueAt(row, 0).toString();
                            String policyName=claimTable.getValueAt(row, 2).toString();
                            String policyType=claimTable.getValueAt(row, 1).toString();
                            String startdate=claimTable.getValueAt(row, 3).toString();
                            String sumInsured=claimTable.getValueAt(row, 4).toString();
                            System.out.print(companyName+" "+policyName+" "+startdate+" ");
                            
                            //use this details to get frequency duration and start date
                            JPanel claimPanel=new JPanel();
                            claimPanel.setLayout(new BoxLayout(claimPanel,BoxLayout.Y_AXIS));
                            //buyPanel.setBounds(500, 500, 400, 200);
                            claimPanel.setPreferredSize(new Dimension(700,400));
                            claimPanel.setBackground(new Color(3,29,68));
                            ResultSet rs3 = stmt3.executeQuery("select * from companyregistration where Company_Name = '"+companyName+"'");
                            if(rs3.next()) company_id = rs3.getString("Company_id");
                            System.out.println(company_id);
                            
                            System.out.println(policyName);
                            ResultSet rs1 = stmt2.executeQuery("select Policy_id from policy where Policy_name ='"+policyName+"' and Company_id ='"+company_id+"'");
                            if(rs1.next()){
                                policy_id = rs1.getString("Policy_id");
                            }
                            rs1.close();
                            System.out.println(policy_id);
                            stmt2.close();
                            stmt2 = conn.createStatement();
                            String c_status="Not Claimed";
                            sql = "select* from bought_policies where Customer_id='"+customer_id+"' and Claimed_status='"+c_status+"' ";
                            ResultSet rs2 =  stmt2.executeQuery(sql);
                            //System.out.println(rs2.getString("Policy_id"));
                            
                            if(rs2.next()){
                                String CustomerName = rs2.getString("Customer_name");
                                String companyEmail=rs3.getString("Email");
                                Popup claimPopup=new PopupFactory().getPopup(claim_policy,claimPanel,850,300);

                                JPanel panel1=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel1.setBackground(new Color(3,29,68));
                                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                                JLabel amountLabel=new JLabel("Claim Amount:");

                                amountLabel.setForeground(Color.WHITE);
                                amountLabel.setFont(TABLE_FONT);

                                JLabel amountClaimableLabel=new JLabel();
                                amountClaimableLabel.setFont(TABLE_FONT);
                                amountClaimableLabel.setText(rs2.getString("Sum_insured").toString());
                                amountClaimableLabel.setForeground(Color.WHITE);


                                panel1.add(amountLabel);
                                panel1.add(amountClaimableLabel);
                                claimPanel.add(panel1);


                                JPanel panel2=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel2.setBackground(new Color(3,29,68));
                                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                                JLabel dateLabel=new JLabel("Claim Date:");

                                dateLabel.setForeground(Color.WHITE);
                                dateLabel.setFont(TABLE_FONT);

                                JLabel dateShowLabel=new JLabel();
                                dateShowLabel.setFont(TABLE_FONT);
                                dateShowLabel.setText(new Date().toString());
                                dateShowLabel.setForeground(Color.WHITE);

                                //Date.setEditable(false);

                                panel2.add(dateLabel);
                                panel2.add(dateShowLabel);
                                claimPanel.add(panel2);


                                JPanel panel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
                                panel3.setBackground(new Color(3,29,68));
                                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                                panel3.setSize(70, 70);
                                JLabel policyLabel=new JLabel("Policy name:");

                                policyLabel.setForeground(Color.WHITE);
                                policyLabel.setFont(TABLE_FONT);

                                JLabel policyShowLabel=new JLabel();
                                policyShowLabel.setFont(TABLE_FONT);
                                policyShowLabel.setForeground(Color.WHITE);
                                policyShowLabel.setText(rs2.getString("Policy_name"));


                                panel3.add(policyLabel);
                                panel3.add(policyShowLabel);
                                claimPanel.add(panel3);

                                JPanel panel4=new JPanel(new BorderLayout(20, 0));//Login button
                                //panel4.setBorder(new MatteBorder(1, 1, 0,1,Color.white));
                                panel4.setBorder(new EmptyBorder(10, 30, 10, 30));
                                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                                panel4.setBackground(new Color(3,29,68));
                                JButton claimbutton=new JButton("Claim Policy");
                                claimbutton.setBorder(null);
                                claimbutton.setBorder(new EmptyBorder(8, 20, 8, 20));
                                claimbutton.setBackground(new java.awt.Color(255,183,3));
                                claimbutton.setForeground(Color.BLACK);
                                claimbutton.setFont(TABLE_FONT);
                                claimbutton.addActionListener((ActionEvent e) -> {
                                    //pay for policy send mail
                                    String host="smtp.gmail.com";
                                    final String user="hackaholics4@gmail.com";
                                    final String password="DaggUs4#";

                                    String to="hackaholics4@gmail.com";

                                    //imported code
                                    Properties props = new Properties();
                                    props.put("mail.smtp.starttls.enable", "true");
                                    props.put("mail.smtp.host", host);
                                    props.put("mail.smtp.user", user);
                                    props.put("mail.smtp.password", password);
                                    props.put("mail.smtp.port", "587");
                                    props.put("mail.smtp.auth", "true");


                                    Session session = Session.getDefaultInstance(props,
                                    new javax.mail.Authenticator() {
                                        @Override
                                        protected PasswordAuthentication getPasswordAuthentication() {
                                            return new PasswordAuthentication(user,password);
                                        }
                                    });

                                    //imported code
                                    try {
                                        MimeMessage message = new MimeMessage(session);
                                        message.setFrom(new InternetAddress(user));
                                        message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
                                        message.setSubject("WE4U | Regarding Claim of Insurance");
                                        message.setContent("<h3> Hi "+CustomerName+", </h3>Hope u r doing well, We are WE4U ,on behalf of the "
                                                + "<b>"+companyName+"</b> insurance Company for "+policyType+" insurace, "+policyName+" policy ,Your request for the claim has been redirected"
                                                + " to the Insurer,You will get a reponse asap for further process from "+companyEmail+".<br><br>Thank you.<br>For any discrepancies,Contact us hackaholics4@gmail.com"
                                                +"<br><br>Regards,<br> Team WE4U.","text/html");


                                                Transport.send(message);

                                        System.out.println("message sent!");

                                    }
                                    catch (MessagingException mex)
                                    {
                                        System.out.println("Error: unable to send message....");
                                        mex.printStackTrace();
                                    }
                                    try {
                                        PaymentJB obj = new PaymentJB();
                                        obj.setPolicy_name(policyName);
                                        obj.setPayment_amount(Integer.parseInt(amountClaimableLabel.getText()));
                                        obj.setPayment_date(java.time.LocalDate.now());
                                        obj.setPayment_time(String.valueOf(java.time.LocalTime.now()));
                                        Connection conn1 = null;
                                        Statement stmt = null;
                                        System.out.println("Connecting to database...");
                                        conn1 = DataBaseConnect.getConnection();
                                        //STEP 4: Execute a query
                                        System.out.println("Creating statement...");
                                        stmt = conn1.createStatement();
                                        String sql1;
                                        String trans_id=UUID.randomUUID().toString();
                                        System.out.println(trans_id);
                                        String Claimed="Claimed";
                                        sql1 = "update bought_policies set Claimed_status='"+Claimed+"',Claimed_date='"+obj.getPayment_date()+"' where Customer_id = '"+customer_id+"'";
                                        stmt.executeUpdate(sql1);
                                        JOptionPane.showMessageDialog(rootPane, "Claim Success!");
                                        stmt.close();
                                        //update ayment table to next payment of the month
                                        
                                        setVisible(false);
                                        new CustomerHome(id);
                                        
                                    }catch(Exception err){
                                        System.out.println(err);
                                    }
                                });


                                panel4.add(claimbutton);
                                
                                JButton cancelbutton=new JButton("Cancel");
                                cancelbutton.setBackground(new java.awt.Color(255,183,3));
                                cancelbutton.setForeground(Color.BLACK);
                                cancelbutton.setFont(TABLE_FONT);
                                cancelbutton.setBorder(null);
                                cancelbutton.setBorder(new EmptyBorder(8, 15, 8, 15));
                                
                                cancelbutton.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                            claimPopup.hide();
                                            claimTable.setEnabled(true);

                                    }

                                });
                            
                                panel4.add(cancelbutton);
                                claimPanel.add(panel4);

                                claimPopup.show();
                            }                   


                    		
                    	}
                    	 catch(Exception err){
                    		 System.out.println(err);
                    }
                    }
            	}
            });
            claimTable.setRowHeight(50);
            claim_policy.add(claimTable);

            mainPanel.add(claim_policy);
            claim_policy.setVisible(false);
            claim.addActionListener(this);
            
            //explore policies
            
            
            explore_policy=new JPanel();
            //explore_policy.setLayout(new BoxLayout(explore_policy,BoxLayout.PAGE_AXIS));
            explore_policy.setBounds(400, 0, 1517, 1000);
            explore_policy.setBackground(new Color(187,222,251));
            
            explorePoliciesForm=new JPanel();
            explorePoliciesForm.setBackground(new Color(227, 242, 253));
            explorePoliciesForm.setPreferredSize(new Dimension(1300,870));
            
            view_policy_filter=new JPanel();
            view_policy_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
            view_policy_filter.setBackground(new Color(3,29,68));
            view_policy_filter.setPreferredSize(new Dimension(1300, 100));
            
            JPanel search_by_type=new JPanel();
            search_by_type.setBorder(new EmptyBorder(0,0,10,0));
            search_by_type.setLayout(new FlowLayout(FlowLayout.CENTER));
            JLabel filter_type=new JLabel("SEARCH BY POLICY TYPE  ");
            filter_type.setFont(TABLE_FONT);
            filter_type.setForeground(Color.WHITE);
            search_by_type.add(filter_type);

            String filter_type_array[]={"All","Health Insurance","Life Insurance","Automobile Insurance","Property Insuarnce","Travel Insurance"};
            JComboBox cmb_filter_type = new JComboBox(filter_type_array);
            cmb_filter_type.setFont(TABLE_FONT);
            cmb_filter_type.setPreferredSize(new Dimension(230, 40));
            search_by_type.add(cmb_filter_type);       

            search_by_type.add(cmb_filter_type);
            search_by_type.setBackground(new Color(3,29,68));

            JLabel filter_frequency=new JLabel("          SEARCH BY FREQUENCY  ");
            filter_frequency.setFont(TABLE_FONT);
            filter_frequency.setForeground(Color.WHITE);


            search_by_type.add(filter_frequency);
            search_by_type.setBackground(new Color(3,29,68));




            String filter_frequency_array[]={"All","Monthly","Quaterly","Semi-Annually","Annually"};
            JComboBox cmb_filter_frequency = new JComboBox(filter_frequency_array);
            cmb_filter_frequency.setFont(TABLE_FONT);
            cmb_filter_frequency.setPreferredSize(new Dimension(230, 40));
            search_by_type.add(cmb_filter_frequency);       

            search_by_type.add(cmb_filter_frequency);
            search_by_type.setBackground(new Color(3,29,68));

            JLabel btn_search = new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
            btn_search.setPreferredSize(new Dimension(42, 42));
            search_by_type.add(btn_search);


            view_policy_filter.add(search_by_type);

//            Vector rowDataEp=new Vector();
            String columnNamesEp[]= {"Company Name","Policy Type","Policy Name","Sum Insured","Buy"};
//            Vector columnNamesVEp=new Vector(Arrays.asList(columnNamesEp));
//            rowDataEp.add(new Vector(Arrays.asList(columnNamesEp)));
            
            policyTableEp = new JTable();
            DefaultTableModel tableModel = (DefaultTableModel) policyTableEp.getModel();
            for(int i=0;i<columnNamesEp.length;i++) {
                    tableModel.addColumn(columnNamesEp[i]);
            }


            tableModel.addRow(columnNamesEp);
                        
                        
            btn_search.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try{
                    int n=((DefaultTableModel)policyTableEp.getModel()).getRowCount();

                    for(int i=n-1;i>=1;i--)
                        ((DefaultTableModel)policyTableEp.getModel()).removeRow(i);


                    Connection conn = null;
                    Statement stmt1 = null,stmt2=null;


                    System.out.println("Connecting to database...");
                    conn = DataBaseConnect.getConnection();

                    //STEP 4: Execute a query
                    System.out.println("Creating statement...");
                    stmt1 = conn.createStatement();
                    String sql;

                    if(cmb_filter_type.getSelectedItem().equals("All") && cmb_filter_frequency.getSelectedItem().equals("All")){

                        sql="select * from policy";
                    }
                    else if(cmb_filter_type.getSelectedItem().equals("All")){
                        sql="select * from policy where Frequency='"+cmb_filter_frequency.getSelectedItem()+"'";
                    }
                    else if(cmb_filter_frequency.getSelectedItem().equals("All")){
                        sql="select * from policy where Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                    }                                
                    else{
                        sql="select * from policy where Frequency='"+cmb_filter_frequency.getSelectedItem()+"' and Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                    }

                    ResultSet rs = stmt1.executeQuery(sql);

                    while(rs.next()){
                        System.out.println(1);
                        String company_id = rs.getString("Company_id");
                        stmt2=conn.createStatement();
                        ResultSet rs1 = stmt2.executeQuery("select Company_name from companyregistration where Company_id='"+company_id+"'");
                        String cname="";
                        if(rs1.next()) {
                            cname=rs1.getString("Company_name");
                            System.out.println(cname);
                        }
                        rs1.close();
                        String[]innerData= {cname,rs.getString("Policy_type"),rs.getString("Policy_name"),rs.getString("Sum_insured"),"BUY"};
                        System.out.println(innerData);
                        Vector colDataEp=new Vector(Arrays.asList(innerData)); 
                        tableModel.addRow(colDataEp);

                    }

                }
                catch(Exception err){
                    System.out.println(err);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseExited(MouseEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
            
            


            policyTableEp.setPreferredSize(new Dimension(1300,860));
            policyTableEp.setForeground(Color.black);
            policyTableEp.setShowGrid(false);
            policyTableEp.setShowHorizontalLines(true);
            policyTableEp.setBackground(new Color(227, 242, 253));
            policyTableEp.setFont(TABLE_FONT);
            policyTableEp.setRowHeight(50);
            policyTableEp.setIntercellSpacing(new Dimension(0,0));
            colorEp = UIManager.getColor("Table.gridColor");
            borderEp = new MatteBorder(1, 1, 1,1, Color.BLACK);
            policyTableEp.setBorder(borderEp);


            policyTableEp.setDefaultEditor(Object.class, null);

            policyTableEp.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {

                    int row = policyTableEp.rowAtPoint(evt.getPoint());
                    int col = policyTableEp.columnAtPoint(evt.getPoint());
                    if(col==4) {
                        try{

                            Connection conn = null;
                            Statement stmt1 = null,stmt2=null,stmt3=null;


                            System.out.println("Connecting to database...");
                            conn = DataBaseConnect.getConnection();

                            //STEP 4: Execute a query
                            System.out.println("Creating statement...");
                            stmt1 = conn.createStatement();
                            String sql;

                            
                            String companyName=policyTableEp.getValueAt(row, 0).toString();
                            String policyType=policyTableEp.getValueAt(row, 1).toString();
                            String policyName=policyTableEp.getValueAt(row, 2).toString();
                            String sumInsured=policyTableEp.getValueAt(row, 3).toString();
                            System.out.print(companyName+" "+policyType+" "+policyName+" "+sumInsured);
                            policyTableEp.setEnabled(false);
                            //use this details to get frequency duration and start date
                            JPanel buyPanel=new JPanel();
                            buyPanel.setLayout(new BoxLayout(buyPanel,BoxLayout.Y_AXIS));
                            buyPanel.setPreferredSize(new Dimension(700,400));
                            buyPanel.setBackground(new Color(3,29,68));
                            buyPanel.setBorder(null);



                            Popup buyPopup=new PopupFactory().getPopup(explorePoliciesForm,buyPanel,850,300);

                            JPanel buyPanelInner=new JPanel(new FlowLayout(FlowLayout.CENTER));
                            JLabel startDateLabel=new JLabel("Start Date:");
                            JLabel startDate=new JLabel(start_date.toString());
                            startDateLabel.setFont(TABLE_FONT);
                            startDateLabel.setForeground(Color.WHITE);
                            startDate.setFont(TABLE_FONT);
                            startDate.setForeground(Color.WHITE);
                            buyPanelInner.add(startDateLabel);
                            buyPanelInner.add(startDate);
                            buyPanelInner.setBackground(new Color(3,29,68));
                            buyPanel.add(buyPanelInner);
                            
                            
                            
                            System.out.println(3);
                            stmt2=conn.createStatement();
                            stmt3 = conn.createStatement();
                            ResultSet rs1 = stmt2.executeQuery("select Company_id from companyregistration where Company_Name='"+companyName+"'");
                            
                            
                            if(rs1.next()) {
                                company_id=rs1.getString("Company_id");
                            }
                            
                            
                            ResultSet rs2 = stmt3.executeQuery("Select Policy_id from policy where Policy_name='"+policyName+"'");
                            if(rs2.next()) policy_id = rs2.getString("Policy_id");
                            
                            sql = "Select * from policy where Company_id='"+company_id+"' and Policy_name='"+policyName+"'";
                            ResultSet rs = stmt1.executeQuery(sql);
                            System.out.println(3);
                            
                            if(rs.next()){
                            JPanel buyPanelInner1=new JPanel(new FlowLayout(FlowLayout.CENTER));
                            JLabel durationLabel=new JLabel("Duration :");
                            duration=new JLabel(String.valueOf(rs.getInt("Duration"))+" "+"Years");
                            durationLabel.setFont(TABLE_FONT);
                            durationLabel.setForeground(Color.white);
                            duration.setFont(TABLE_FONT);
                            duration.setForeground(Color.white);
                            buyPanelInner1.add(durationLabel);
                            buyPanelInner1.add(duration);
                            buyPanelInner1.setBackground(new Color(3,29,68));
                            buyPanel.add(buyPanelInner1);

                            JPanel buyPanelInner2=new JPanel(new FlowLayout(FlowLayout.CENTER));
                            JLabel frequencyLabel=new JLabel("Frequency :");
                            frequency=new JLabel(rs.getString("Frequency"));
                            frequency.setFont(TABLE_FONT);
                            frequency.setForeground(Color.white);
                            frequencyLabel.setFont(TABLE_FONT);
                            frequencyLabel.setForeground(Color.white);
                            buyPanelInner2.add(frequencyLabel);
                            buyPanelInner2.add(frequency);
                            buyPanelInner2.setBackground(new Color(3,29,68));
                            buyPanel.add(buyPanelInner2);

                            JPanel buyPanelInner3=new JPanel(new FlowLayout(FlowLayout.CENTER));
                            JLabel premiumLabel=new JLabel("Premium :");
                            JLabel premium=new JLabel(String.valueOf(rs.getInt("Premium")));
                            premium.setFont(TABLE_FONT);
                            premiumLabel.setFont(TABLE_FONT);
                            premium.setForeground(Color.white);
                            premiumLabel.setForeground(Color.white);
                            buyPanelInner3.add(premiumLabel);
                            buyPanelInner3.add(premium);
                            buyPanelInner3.setBackground(new Color(3,29,68));
                            buyPanel.add(buyPanelInner3);
                            
                            bp.setCompany_id(company_id);
                            bp.setCompany_name(companyName);
                            bp.setCustomer_id(customer_id);
                            bp.setPolicy_name(policyName);
                            bp.setStart_date(start_date);
                            bp.setFrequency(frequency.getText());
                            bp.setDuration(rs.getInt("Duration"));
                            bp.setPremium(Integer.parseInt(premium.getText()));
                            bp.setPolicy_type(policyType);
                            bp.setPolicy_id(policy_id);
                            }
                            JPanel buyPanelInner4=new JPanel(new FlowLayout(FlowLayout.CENTER));
                            buyPanelInner4.setBackground(new Color(3,29,68));
                            JButton buyButton=new JButton("    Buy    ");
                            buyButton.setBorder(null);
                            buyButton.setBorder(new EmptyBorder(8, 20, 8, 20));
                            buyButton.setBackground(new java.awt.Color(255,183,3));
                            buyButton.setForeground(Color.BLACK);
                            buyButton.setFont(TABLE_FONT);
                            buyButton.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                        //add this policy to customer policies
                                        policyTableEp.setEnabled(true);
                                        
                                        try{
                                            

                                            Connection conn = null;
                                            Statement stmt,stmt1 = null;


                                            System.out.println("Connecting to database...");
                                            conn = DataBaseConnect.getConnection();

                                            //STEP 4: Execute a query
                                            System.out.println("Creating statement...");
                                            stmt = conn.createStatement();
                                            stmt1 = conn.createStatement();
                                            String sql;
                                            String bought_id=UUID.randomUUID().toString();
                                            System.out.println(bought_id);
                                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                            Calendar c = Calendar.getInstance();
                                            //Setting the date to the given date
                                            c.setTime(sdf.parse(start_date.toString()));
                                            int number_of_days = bp.getDuration()*365;

                                            //Number of Days to add
                                            c.add(Calendar.DAY_OF_MONTH, number_of_days);  
                                            //Date after adding the days to the given date
                                            String newDate = sdf.format(c.getTime());  
                                            //Displaying the new Date after addition of Days
                                            System.out.println("Date after Addition: "+newDate);
                                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                            LocalDate endDate = LocalDate.parse(newDate, formatter);
                                            System.out.println(endDate);
                                            
                                            int no_of_pay=0;
                                            String freq=bp.getFrequency();
                                            int diff=0;
                                            switch(freq){
                                                case "Monthly":{
                                                    no_of_pay=bp.getDuration()*12;
                                                    diff=30;
                                                    break;
                                                }
                                                case "Quaterly":{
                                                    no_of_pay=bp.getDuration()*3;
                                                    diff=91;
                                                    break;
                                                }
                                                case "Semi-Annually":{
                                                    no_of_pay=bp.getDuration()*2;
                                                    diff=182;
                                                    break;
                                                }
                                                case "Annually":{
                                                    no_of_pay=bp.getDuration()*1;
                                                    diff=365;
                                                    break;
                                                }
                                            }
                                            c.setTime(sdf.parse(start_date.toString()));
                                            c.add(Calendar.DAY_OF_MONTH,diff);
                                            String nextDate=sdf.format(c.getTime());
                                            
                                            LocalDate next_pay_Date = LocalDate.parse(nextDate, formatter);
                                            bp.setEnd_date(endDate);
                                            bp.setBought_id(bought_id);
                                            bp.setNo_of_payments(no_of_pay);
                                            bp.setNext_payment(next_pay_Date);
                                            bp.setSum_insured(Integer.parseInt(sumInsured));
                                            String customer_name="";
                                            sql="select FirstName from customerregistration where Customer_id='"+customer_id+"'";
                                            ResultSet rs4 = stmt1.executeQuery(sql);
                                            if(rs4.next()) customer_name = rs4.getString("FirstName");
                                            
                                            bp.setCustomer_name(customer_name);
                                            
                                            c.add(Calendar.DAY_OF_MONTH,diff);
                                            System.out.println("Next Date:"+nextDate);
                                            bp.setNo_of_payments(no_of_pay);
                                            long millis=System.currentTimeMillis();
                                            java.sql.Date today_date=new java.sql.Date(millis);
                                            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                            Date end=df.parse(nextDate);
                                            long diffInMillies = Math.abs(end.getTime() - today_date.getTime());
                                            long diffdays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                                            String status=diffdays+" days left";
                                            

                                            sql = "insert into bought_policies values('"+bp.getBought_id()+"','"+bp.getCustomer_id()+"','"+bp.getCustomer_name()+"','"+bp.getCompany_id()+"','"+bp.getPolicy_id()+"',"
                                                    + "'"+bp.getPolicy_name()+"','"+bp.getCompany_name()+"','"+bp.getPolicy_type()+"','"+bp.getStart_date()+"','"+bp.getEnd_date()+"','"+bp.getNo_of_payments()+"',"
                                                    + "'"+bp.getPremium()+"','"+bp.getDuration()+"','"+bp.getFrequency()+"','"+bp.getNext_payment()+"','"+bp.getSum_insured()+"','"+status+"','Not Claimed',null)";
                                            stmt.executeUpdate(sql);
                                            JOptionPane.showMessageDialog(rootPane, "Policy Bought Successfully!");
                                            
                                            setVisible(false);
                                            new CustomerHome(id);
                                        }
                                        catch(Exception err){
                                            System.out.println(err);
                                        }
                                        buyPopup.hide();
                                }

                            });
                            JButton cancelButton=new JButton("   Cancel    ");
                            cancelButton.setFont(TABLE_FONT);
                            cancelButton.setBorder(null);
                            cancelButton.setBorder(new EmptyBorder(8, 20, 8, 20));
                            cancelButton.setBackground(new java.awt.Color(255,183,3));
                            cancelButton.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                        policyTableEp.setEnabled(true);
                                        buyPopup.hide();
                                }
                            });
                            buyPanelInner4.add(cancelButton);
                            buyPanelInner4.add(buyButton);
                            buyPanel.add(buyPanelInner4);

                            buyPopup.show();
                            
                        }
                        catch(Exception err){
                            System.out.println(err);
                        }
                    }
                }
            });

            explorePoliciesForm.add(policyTableEp);
            explore_policy.add(view_policy_filter);
            explore_policy.add(explorePoliciesForm);



            explore_policy.setVisible(false);
            add(explore_policy);
            
            
            //completed/claim policies form
            completed_policy=new JPanel();
            completed_policy.setBackground(new Color(227, 242, 253));
            String columnNamescc[]= {"Company Name","Policy Type","Policy Name","Start Date"
                            ,"End Date","Policy Status","Sum Insured","Claimed Status","Claimed Date"};
            
            
            completedTable = new JTable();
            DefaultTableModel tableModel5 = (DefaultTableModel) completedTable.getModel();
            completedTable=new JTable(tableModel5);
            
            
            for(int i=0;i<columnNamescc.length;i++) {
                    tableModel5.addColumn(columnNamescc[i]);
            }


            tableModel5.addRow(columnNamescc);
            
            //divya's part
            try{

                Connection conn = null;
                Statement stmt1 = null,stmt2=null;


                System.out.println("Connecting to database...");
               conn = DataBaseConnect.getConnection();

                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                stmt1 = conn.createStatement();
                String sql;
                sql = "select * from bought_policies where Customer_id='"+customer_id+"' and Status='"+"Completed"+"' and Claimed_status='"+"Claimed"+"'";
                ResultSet rs = stmt1.executeQuery(sql);
                
                while(rs.next()){
                    System.out.println(1);
                    String company_id = rs.getString("Company_id");
                    stmt2=conn.createStatement();
                    ResultSet rs1 = stmt2.executeQuery("select Company_name from companyregistration where Company_id='"+company_id+"'");
                    String cname="";
                    if(rs1.next()) {
                        cname=rs1.getString("Company_name");
                        System.out.println(cname);
                    }
                    rs1.close();
                    String[]innerData= {cname,rs.getString("Policy_type"),rs.getString("Policy_name"),
                        rs.getString("Start_date"),rs.getString("End_date"),rs.getString("Status"),
                        rs.getString("Sum_insured"),rs.getString("Claimed_status"),rs.getString("Claimed_date")};
                    System.out.println(innerData);
                    Vector colData=new Vector(Arrays.asList(innerData)); 
                    tableModel5.addRow(colData);
                    
                }

            }
            catch(Exception err){
                System.out.println(err);
            }

            completedTable.setDefaultEditor(Object.class, null);
            
            
//            int n=((DefaultTableModel)policyTable.getModel()).getRowCount();
//            ((DefaultTableModel)policyTable.getModel()).removeRow(0);


            completedTable.setBorder(new EmptyBorder(30, 0, 0, 0));
            completedTable.setShowGrid(false);
            completedTable.setShowHorizontalLines(true);
            completedTable.setSelectionBackground(Color.WHITE);
            completedTable.setPreferredSize(new Dimension(1400,870));
            completedTable.setForeground(Color.BLACK);
            completedTable.setBackground(new Color(227, 242, 253));
            completedTable.setFont(TABLE_FONT);
            completedTable.setIntercellSpacing(new Dimension(2,2));
            completedTable.setBorder(border);


            scrollPane=new JScrollPane();
            scrollPane.setViewportView(completedTable);

            completedTable.setRowHeight(50);
            completed_policy.add(completedTable);

            mainPanel.add(completed_policy);
            completed_policy.setVisible(false);
            completed.addActionListener(this);
            

            add(mainPanel);

            setVisible(true);
    }



    public static void main(String[] args) {
        //new CustomerHome("37fc7f07-f620-4ada-5712-edd2b45dcdcf");


    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource().equals(profile)) {
                profileForm.setVisible(true);
                policiesForm.setVisible(false);
                payPremiumForm.setVisible(false);
                explore_policy.setVisible(false);
                view_policy_filter.setVisible(false);
                claim_policy.setVisible(false);
                completed_policy.setVisible(false);
        }

        if(e.getSource().equals(policies)) {
                profileForm.setVisible(false);
                policiesForm.setVisible(true);
                payPremiumForm.setVisible(false);
                explore_policy.setVisible(false);
                view_policy_filter.setVisible(false);
                claim_policy.setVisible(false);
                completed_policy.setVisible(false);
        }

        if(e.getSource().equals(payPremium)) {
                profileForm.setVisible(false);
                policiesForm.setVisible(false);
                payPremiumForm.setVisible(true);
                explore_policy.setVisible(false);
                view_policy_filter.setVisible(false);
                inner.setVisible(true);
                claim_policy.setVisible(false);
                completed_policy.setVisible(false);
        }

        if(e.getSource().equals(explorePolicies)) {
                profileForm.setVisible(false);
                policiesForm.setVisible(false);
                payPremiumForm.setVisible(false);
                explore_policy.setVisible(true);
                view_policy_filter.setVisible(true);
                claim_policy.setVisible(false);
                completed_policy.setVisible(false);
        }
        if(e.getSource().equals(claim)) {
                profileForm.setVisible(false);
                policiesForm.setVisible(false);
                payPremiumForm.setVisible(false);
                explore_policy.setVisible(false);
                view_policy_filter.setVisible(false);
                claim_policy.setVisible(true);
                completed_policy.setVisible(false);
        }
        if(e.getSource().equals(completed)) {
                profileForm.setVisible(false);
                policiesForm.setVisible(false);
                payPremiumForm.setVisible(false);
                explore_policy.setVisible(false);
                view_policy_filter.setVisible(false);
                claim_policy.setVisible(false);
                completed_policy.setVisible(true);
        }

    }


//    @Override
//    public void itemStateChanged(ItemEvent e) {
//
//            if(e.getSource().equals(stateComboBox)) {
//                    System.out.println(districtsMap.get(e.getItem().toString()));
//                    districtComboBox.removeAllItems();
//
//                    Object[] districts=districtsMap.get(e.getItem().toString()).toArray();
//
//                    for(int i=0;i<districts.length;i++) {
//                            districtComboBox.addItem((String)districts[i]);
//                    }
//
//
//            }
//
//    }
    
    @Override
    public void mouseEntered(MouseEvent e) {

        if(e.getSource().equals(policies)) {
            policies.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            policies.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(payPremium)) {
            payPremium.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            payPremium.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(profile)) {
            profile.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            profile.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(explorePolicies)) {
            explorePolicies.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            explorePolicies.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(claim)) {
            claim.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            claim.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(completed)) {
            completed.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
            completed.setBackground(new Color(3,29,68));
        }
    }



    @Override
    public void mouseExited(MouseEvent e) {
        if(e.getSource().equals(policies)) {
            policies.setBorder(null);
            policies.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(payPremium)) {

            payPremium.setBorder(null);
            payPremium.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(profile)) {

            profile.setBorder(null);
            profile.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(explorePolicies)) {

            explorePolicies.setBorder(null);
            explorePolicies.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(claim)) {

            claim.setBorder(null);
            claim.setBackground(new Color(3,29,68));
        }
        if(e.getSource().equals(completed)) {

            completed.setBorder(null);
            completed.setBackground(new Color(3,29,68));
        }
    }
    @Override
    public void mouseClicked(MouseEvent e) {
            // TODO Auto-generated method stub

    }



    @Override
    public void mousePressed(MouseEvent e) {
            // TODO Auto-generated method stub

    }



    @Override
    public void mouseReleased(MouseEvent e) {
            // TODO Auto-generated method stub

    }

    private void populateDistrictsMap() {
        Object obj = null;
        try {
                obj = new JSONParser().parse(new FileReader("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\insurance\\districts.json"));
        } catch (Exception e) {
                e.printStackTrace();
        } 

        JSONObject jo = (JSONObject) obj;

        states=new ArrayList<String>();
        districtsMap=new HashMap<String,ArrayList<String>>();  

        JSONArray jsonArray=(JSONArray)jo.get("states");

        Iterator<JSONObject> it=jsonArray.iterator();

        while(it.hasNext()) {
            JSONObject temp=it.next();
            String state=temp.get("state").toString();
            states.add(state);

            JSONArray districtsJSONArray=(JSONArray)temp.get("districts");

            Iterator<String> it2=districtsJSONArray.iterator();
            ArrayList<String> districts=new ArrayList<String>();

            while(it2.hasNext()) {
                           districts.add(it2.next());
            }
            districtsMap.put(state,districts);

        }

    }

}