package insurance.customer;
import JavaBean.CustomerRegistrationJB;
import database.DataBaseConnect;
import com.toedter.calendar.JDateChooser;
import java.awt.Container;
import java.util.*;
import java.awt.Color;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileReader;
import java.sql.Connection;

import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JComboBox;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;





public class CustomerRegistration extends JFrame implements ItemListener,MouseListener{
    private Map<String,ArrayList<String>> districtsMap;
    JComboBox State,District;
    private JButton register;

    public CustomerRegistration() {
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setTitle("CUSTOMER REGISTRATION");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        Container co=getContentPane();
        co.setBackground(java.awt.Color.LIGHT_GRAY);
       
        Font We4ufont=new Font("Georgia", Font.BOLD, 45);
        Font Buttonfont=new Font("Microsoft YaHei", Font.BOLD, 24);
        Font Textfont=new Font("Microsoft YaHei",Font.PLAIN, 18);
       
        //Navigation bar
        JPanel nav=new JPanel();
        GroupLayout grouplayout=new GroupLayout(nav);
        nav.setBounds(0, 0, 400, 1000);
        nav.setBackground(new java.awt.Color(3,29,68));
        grouplayout.setAutoCreateGaps(true);
        grouplayout.setAutoCreateContainerGaps(true);
        nav.setLayout(grouplayout);
        add(nav);
           
            //Project title(WE4U)
            JLabel we4u=new JLabel(" WE4U");
            //we4u.setBounds(84,100,100,70);
            we4u.setForeground(Color.white);
            we4u.setFont(We4ufont);
       
           
            //Company registration button
            Icon customer_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\customer.png");
            JLabel customericon=new JLabel(customer_icon);
            JButton customerreg=new JButton(" Customer SignUp ");
            customerreg.setBackground(new java.awt.Color(3,29,68));
            customerreg.setForeground(new java.awt.Color(255,252,242));
            customerreg.setFocusPainted(false);
            customerreg.setMaximumSize(new Dimension(400, 50));
            customerreg.setFont(Buttonfont);
            customerreg.setBorder(null);
            customerreg.setFocusPainted(false);
           
           
           
            //adding the components of the nav bar using horizontalgroup method parallely
            grouplayout.setHorizontalGroup(grouplayout.createParallelGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.CENTER)
                    .addComponent(we4u)
                    .addComponent(customericon)
                    .addComponent(customerreg)
                   
                    ));
            // add the gaps between the components using verticalgroup method sequentially
            grouplayout.setVerticalGroup(grouplayout.createSequentialGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(we4u)).addGap(150)
                    .addComponent(customericon)
                    .addGap(10)
                    .addComponent(customerreg).addGap(75)
                 
            );
       
        // Main area(Customer area)
        JPanel area1=new JPanel();//creating main area
        JPanel innerarea2=new JPanel();//This is for creating a gap between the innerarea1 and area1
        JPanel innerarea1=new JPanel();// creating inner form
        area1.setLayout(new BoxLayout(area1,BoxLayout.Y_AXIS));
        area1.setBounds(400, 0, 1517, 1000);
        area1.setBackground(new java.awt.Color(187,222,251));
            innerarea2.setMaximumSize(new Dimension(100, 75));
            innerarea2.setBackground(new java.awt.Color(187,222,251));
            innerarea1.setMaximumSize(new Dimension(550, 730));
            innerarea1.setBorder(new EmptyBorder(20, 0, 0, 0));
            innerarea1.setBackground(new Color(227,242,253));
           
                JPanel panel1=new JPanel();//creating a panel for firstname(label and textfield)
                panel1.setBorder(new EmptyBorder(0,0,10,0));
                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel First_name_lbl=new JLabel("First Name      ");
                First_name_lbl.setFont(Textfont);
                panel1.setBackground(new Color(227,242,253));
               
                JTextField First_Name=new JTextField();
                First_Name.setFont(Textfont);
                First_Name.setPreferredSize(new Dimension(275,35));
                First_Name.setColumns(15);
               
                panel1.add(First_name_lbl);
                panel1.add(First_Name);
                innerarea1.add(panel1);
               
                JPanel panel2=new JPanel();//creating a panel for lastname(label and textfield)
                panel2.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Last_Name_lbl=new JLabel("Last Name       ");
                Last_Name_lbl.setFont(Textfont);
                panel2.setBackground(new Color(227,242,253));
               
                JTextField Last_Name=new JTextField();
                Last_Name.setFont(Textfont);
                Last_Name.setColumns(15);
                Last_Name.setPreferredSize(new Dimension(275,35));
               
                panel2.add(Last_Name_lbl);
                panel2.add(Last_Name);
                innerarea1.add(panel2);
               
                JPanel panel3=new JPanel();//creating a panel for dob(label and Datechooser(calendar))
                panel3.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Date_of_birth_lbl=new JLabel("DOB                 ");
                panel3.setBackground(new Color(227,242,253));
                Date_of_birth_lbl.setFont(Textfont);
               
                JDateChooser Date_of_birth=new JDateChooser();
                Date_of_birth.setPreferredSize(new Dimension(260, 35));
                Date_of_birth.setFont(Textfont);
               
                panel3.add(Date_of_birth_lbl);
                panel3.add(Date_of_birth);
                innerarea1.add(panel3);
               
                JPanel panel4=new JPanel();//creating a panel for age(label and textfield)
                panel4.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Adhaar_number_lbl=new JLabel("AdhaarNo       ");
                panel4.setBackground(new Color(227,242,253));
                Adhaar_number_lbl.setFont(Textfont);
               
                JTextField Adhaar_number=new JTextField();
                Adhaar_number.setFont(Textfont);
                Adhaar_number.setPreferredSize(new Dimension(275, 35));
                Adhaar_number.setColumns(15);
               
                panel4.add(Adhaar_number_lbl);
                panel4.add(Adhaar_number);
                innerarea1.add(panel4);
               
                JPanel panel5=new JPanel();//creating a panel for state(label and textfield)
                panel5.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel5.setBackground(new Color(227,242,253));
                JLabel State_lbl=new JLabel("State                 ");
                State_lbl.setFont(Textfont);
               
                String S[]={"--Select--","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Karnataka","Kerala","Chhattisgarh","Uttar Pradesh","Goa", "Gujarat","Himachal Pradesh",
                "Jammu and Kashmir","Jharkhand","West Bengal","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Punjab","Rajasthan","Sikkim",
                "Tamil Nadu","Telangana","Tripura","Uttarakhand","Andaman and Nicobar","Pondicherry","Dadra and Nagar Haveli","Daman and Diu","Delhi","Chandigarh","Lakshadweep"};
                JComboBox State=new JComboBox(S);
                State.setPreferredSize(new Dimension(260, 35));
                State.setFont(Textfont);
                State.setBackground(Color.white);
               
                panel5.add(State_lbl);
                panel5.add(State);
                innerarea1.add(panel5);
                
                
                Object obj = null;
		try {
			obj = new JSONParser().parse(new FileReader("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\insurance\\districts.json"));
		} catch (Exception e) {
			e.printStackTrace();
		} 
        
	        JSONObject jo = (JSONObject) obj;
	        
	        ArrayList<String>states=new ArrayList<String>();
	        districtsMap=new HashMap<String,ArrayList<String>>();  
	        
	        JSONArray jsonArray=(JSONArray)jo.get("states");
	        
	        Iterator<JSONObject> it=jsonArray.iterator();
	        
	        while(it.hasNext()) {
	        	JSONObject temp1=it.next();
	        	String state=temp1.get("state").toString();
	        	states.add(state);
	        	
	        	JSONArray districtsJSONArray=(JSONArray)temp1.get("districts");
	        	
	        	 Iterator<String> it2=districtsJSONArray.iterator();
	        	 ArrayList<String> districts=new ArrayList<String>();
	        	 
	        	 while(it2.hasNext()) {
	        		 	districts.add(it2.next());
	        	 }
	        	 districtsMap.put(state,districts);
	        	
	        }
                
                JPanel panel6=new JPanel();//creating a panel for email(label and textfield)
                panel6.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel6.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel6.setBackground(new Color(227,242,253));
                JLabel District_lbl=new JLabel("District             ");
                District_lbl.setFont(Textfont);
                
                
                District=new JComboBox();
                State.addItemListener(new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent e) {
                        
                        if(e.getStateChange()==ItemEvent.SELECTED){
                            //District.add(districtsMap.get(State.getSelectedItem()).toArray());
                            District.removeAllItems();
                            Object dis[]=districtsMap.get(State.getSelectedItem()).toArray();
                            for(int d=0;d<dis.length;d++){
                                District.addItem(dis[d]);
                            }
                        }
                        
                    }
                });
                District.setFont(Textfont);  
                District.setBackground(Color.white);
                District.setPreferredSize(new Dimension(260, 35));
               
                panel6.add(District_lbl);
                panel6.add(District);
                innerarea1.add(panel6);
               
                JPanel panel7=new JPanel();//creating a panel for email(label and textfield)
                panel7.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel7.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Email_lbl=new JLabel("Email                ");
                panel7.setBackground(new Color(227,242,253));
                Email_lbl.setFont(Textfont);
               
                JTextField Email=new JTextField();
                Email.setFont(Textfont);
                Email.setPreferredSize(new Dimension(275, 35));
                Email.setColumns(15);
               
                panel7.add(Email_lbl);
                panel7.add(Email);
                innerarea1.add(panel7);
               
                JPanel panel8=new JPanel();//creating a panel for password(label and textfield)
                panel8.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel8.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Password_lbl=new JLabel("    Password           ");
                panel8.setBackground(new Color(227,242,253));
                Password_lbl.setFont(Textfont);
               
                JPasswordField Password=new JPasswordField();
                Password.setFont(Textfont);
                Password.setPreferredSize(new Dimension(270, 35));
                Password.setColumns(15);
                
                Icon eyeicon = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\eyeicon.png");
                JToggleButton eyebutton= new JToggleButton(eyeicon); 
                eyebutton.setBackground(new Color(227,242,253));
                eyebutton.setBorder(null);
                eyebutton.setFocusPainted(false);
                
                eyebutton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(eyebutton.isSelected()){
                            Password.setEchoChar((char)0); //By this line of code. We will actually see the actual characters
                            
                        }else{
                            Password.setEchoChar('•');
                            
                        }
                    }
                });
               
                panel8.add(Password_lbl);
                panel8.add(Password);
                panel8.add(eyebutton);
                innerarea1.add(panel8);
               
                JPanel panel9=new JPanel();//creating a panel for password(label and textfield)
                panel9.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel9.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel9.setBackground(new Color(227,242,253));
                JLabel Mobile_no_lbl=new JLabel("Mobile             ");
                Mobile_no_lbl.setFont(Textfont);
               
                JTextField Mobile_no=new JTextField();
                Mobile_no.setFont(Textfont);
                Mobile_no.setPreferredSize(new Dimension(275, 35));
                Mobile_no.setColumns(15);
               
                panel9.add(Mobile_no_lbl);
                panel9.add(Mobile_no);
                innerarea1.add(panel9);
               
                JPanel panel10=new JPanel();//creating a panel for annualincome(label and textfield)
                panel10.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel10.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Account_no_lbl=new JLabel("Account No     ");
                panel10.setBackground(new Color(227,242,253));
                Account_no_lbl.setFont(Textfont);
               
                JTextField Account_no=new JTextField();
                Account_no.setFont(Textfont);
                Account_no.setPreferredSize(new Dimension(275, 35));
                Account_no.setColumns(15);
               
                panel10.add(Account_no_lbl);
                panel10.add(Account_no);
                innerarea1.add(panel10);
               
                JPanel panel11=new JPanel();
                panel11.setBorder(new EmptyBorder(0,0,10,0));
                panel11.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel11.setBackground(new Color(227,242,253));
                register=new JButton("   Register   ");
                register.setFocusPainted(false);
                register.setBackground(new java.awt.Color(3,29,68));
                register.setForeground(new java.awt.Color(255,252,242));
                register.setFont(new Font("Microsoft YaHei Light", Font.BOLD,24 ));
                register.setBorder(null);
                register.setBorder(new EmptyBorder(8, 20, 8, 20));
                panel11.add(register);
                innerarea1.add(panel11);
               
       
        area1.add(innerarea2);
        area1.add(innerarea1);
        add(area1);
       
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    CustomerRegistrationJB obj = new CustomerRegistrationJB();
                    obj.setFirstName(First_Name.getText());
                    obj.setLastName(Last_Name.getText());
                    obj.setDate_Of_Birth(((JTextField)Date_of_birth.getDateEditor().getUiComponent()).getText());
                    obj.setAdhaar_no(Adhaar_number.getText());
                    obj.setState(State.getSelectedItem().toString());
                    obj.setDistrict(District.getSelectedItem().toString());
                    obj.setEmail(Email.getText());
                    obj.setPassword(String.valueOf(Password.getPassword()));
                    obj.setAccount_no(Account_no.getText());
                    obj.setMobile(Mobile_no.getText());
                    //border for error fields
                    Border border_error = BorderFactory.createLineBorder(Color.RED, 2);
                    Border border_normal = BorderFactory.createLineBorder(Color.BLACK, 1);
                   
                    int count=0;
                   
                    //firstname validation
                    if(obj.getFirstName().length()>2){
                        count++;
                        First_Name.setBorder(border_normal);
                        First_Name.setText(obj.getFirstName());
                    }
                    else{
                        First_Name.setBorder(border_error);
                        //First_Name.setText("Invalid name");
                    }
                    //lastname validation
                    if(obj.getLastName().length()>0){
                        count++;
                        Last_Name.setBorder(border_normal);
                        Last_Name.setText(obj.getLastName());
                    }
                    else{
                        Last_Name.setBorder(border_error);
                        //Last_Name.setText("Invalid name");
                    }
                    //date of birth validation
                    if(obj.getDate_Of_Birth().length()>2){
                        count++;
                        Date_of_birth.setBorder(border_normal);
                    }
                    else{
                        Date_of_birth.setBorder(border_error);
                    }
                    //state validation
                    if(!obj.getState().equals("--Select--")){
                        count++;
                        State.setBorder(border_normal);
                        State.setSelectedItem(obj.getState());
                    }
                    else{
                        State.setBorder(border_error);
                        //State.setSelectedItem("Invalid state");
                    }
                    //district validation
                    if(obj.getDistrict().length()>2){
                        count++;
                        District.setBorder(border_normal);
                        District.setSelectedItem(obj.getDistrict());
                    }
                    else{
                        District.setBorder(border_error);
                        //District.setSelectedItem("Invalid district");
                    }
                    //email validation
                    String email_regex="^[a-z0-9]+[@]{1}[a-z.]+$";
                   
                    if(Pattern.matches(email_regex,obj.getEmail())){
                        count++;
                        Email.setBorder(border_normal);
                        Email.setText(obj.getEmail());
                    }
                    else{
                        Email.setBorder(border_error);
                        //Email.setText("Invalid email");
                    }
                    //password validation
                    String password_regex="^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9])[A-Za-z0-9]*[^A-Za-z0-9]$";
                            if(Pattern.matches(password_regex,obj.getPassword().toString())){
                        count++;
                        Password.setBorder(border_normal);
                        Password.setText(obj.getPassword().toString());
                    }
                    else{
                        Password.setBorder(border_error);
                        //Password.setText("Invalid password");
                    }
                    //mobileno validation
                    if(obj.getMobile().length()==10){
                        count++;
                        Mobile_no.setBorder(border_normal);
                        Mobile_no.setText(obj.getMobile());
                    }
                    else{
                        Mobile_no.setBorder(border_error);
                        //Mobile_no.setText("Invalid mobile no");
                    }
                    //adhaar no validation
                    if(obj.getAdhaar_no().length()==12){
                        count++;
                        Adhaar_number.setBorder(border_normal);
                        Adhaar_number.setText(obj.getAdhaar_no());
                    }
                    else{
                        Adhaar_number.setBorder(border_error);
                        //Adhaar_number.setText("Invalid adhaar no");
                    }
                    //account no validation
                    if(obj.getAccount_no().length()==15){
                        count++;
                        Account_no.setBorder(border_normal);
                        Account_no.setText(obj.getAccount_no());
                    }
                    else{
                        Account_no.setBorder(border_error);
                        //Account_no.setText("Invalid account no");
                    }
                   
                    System.out.println(count);
                    Connection conn = null;
                    Statement stmt = null;

                   
                    System.out.println("Connecting to database...");
                    conn = DataBaseConnect.getConnection();

                    //STEP 4: Execute a query
                    System.out.println("Creating statement...");
                    stmt = conn.createStatement();
                    String sql;
                    System.out.println("id found");
//                    int id=0;
//                    sql = "SELECT max(Customer_id) from customerregistration";
//                    ResultSet rs = stmt.executeQuery(sql);
//                    while(rs.next()){
//                        id = rs.getInt("max(Customer_id)");
//                        id++;
//                    }
                    
                    String id=UUID.randomUUID().toString();
                    System.out.println(id);
                    
                    if(count==10){
                        sql = "INSERT INTO customerregistration values('"+id+"','"+obj.getFirstName()+"','"+obj.getLastName()+"',"
                                + "'"+obj.getDate_Of_Birth()+"','"+obj.getState()+"','"+obj.getDistrict()+"',"
                                + "'"+obj.getEmail()+"','"+String.valueOf(obj.getPassword())+"',"
                                + "'"+obj.getAccount_no()+"','"+obj.getMobile()+"','"+obj.getAdhaar_no()+"')";
                        stmt.executeUpdate(sql);
                        JOptionPane.showMessageDialog(rootPane, "Registration Success!");
                        setVisible(false);
                        
                    }
                    //rs.close();
                    stmt.close();
                    conn.close();
                   
                }
               
                
                catch(SQLIntegrityConstraintViolationException sql){
                    JOptionPane.showMessageDialog(rootPane, "Aadhar or Account no. already in use!!!");
                    System.out.println(sql);
                }
                catch(Exception err){                    
                    JOptionPane.showMessageDialog(rootPane, "Enter Details!");
                    System.out.println(err);
                }
            }
        });
       
        setVisible(true);
       
   
    }
    public static void main(String [] args){
        new CustomerRegistration();
    }
    
    public void itemStateChanged(ItemEvent e) {

        if(e.getSource().equals(State)) {
            System.out.println(districtsMap.get(e.getItem().toString()));
            District.removeAllItems();

            Object[] districts=districtsMap.get(e.getItem().toString()).toArray();

            for(int i=0;i<districts.length;i++) {
                    District.addItem((String)districts[i]);
            }


        }

    }
    

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(e.getSource().equals(register)) {
             
             register.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
             register.setBackground(new Color(3,29,68));

	}
    
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(e.getSource().equals(register)) {
            register.setBorder(null);
            register.setBackground(new Color(3,29,68));
	}
    }

    
   
}