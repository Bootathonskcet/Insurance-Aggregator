package insurance.admin;

import java.awt.Container;
import database.DataBaseConnect;
import insurance.company.CompanyHome;
import java.awt.ItemSelectable;
import javax.swing.*;    
import javax.swing.event.*;  
import java.awt.*;
import java.sql.Statement;
import java.sql.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;


public class AdminHome extends JFrame implements MouseListener{
    public JTable policyTable;
    public JTable companyTable;
    public JTable customerTable;
    
    JButton btn_view_company;
    JButton btn_view_customer;
    JButton btn_view_policy;
    JButton btn_logout;

    public AdminHome(){
        setLayout(null);
        setExtendedState(MAXIMIZED_BOTH); 
        setTitle("ADMIN HOME");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        Container co=getContentPane();
        co.setBackground(Color.lightGray);
        
        //Navigation
        JPanel nav=new JPanel();
        nav.setBounds(0, 0, 400, 1000);
        nav.setBackground(new Color(3,29,68));
        add(nav);
        
        //Group Layout
        GroupLayout grp_nav=new GroupLayout(nav);
        grp_nav.setAutoCreateGaps(true);
        grp_nav.setAutoCreateContainerGaps(true);
        nav.setLayout(grp_nav);
        
        
        //Title WE4U
        Font t=new Font("Georgia", Font.BOLD,45);
        JLabel lbl_we4u=new JLabel("          WE4U");
        //lbl_we4u.setBounds(84, 200, 300, 70);
        lbl_we4u.setForeground(Color.white);
        lbl_we4u.setFont(t);
        nav.add(lbl_we4u);
        
        
        //View Company Button
        Font b=new Font("Microsoft YaHei Light", Font.BOLD,20);
        btn_view_company=new JButton("   View Company");
        btn_view_company.setMaximumSize(new Dimension(400, 50));
        btn_view_company.setBackground(new Color(3,29,68));
        btn_view_company.setForeground(new Color(255,252,242));
        btn_view_company.setFont(b);
        btn_view_company.setFocusPainted(false);
        btn_view_company.setBorder(null);
        btn_view_company.setFocusPainted(false);
        Icon company_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_company.png");
        JLabel compicon=new JLabel(company_icon);
        btn_view_company.add(compicon);
        btn_view_company.addMouseListener(this);
        nav.add(btn_view_company);
        
        
        //View Customer Button
        btn_view_customer=new JButton("    View Customer");
        btn_view_customer.setMaximumSize(new Dimension(400, 50));
        btn_view_customer.setBackground(new Color(3,29,68));
        btn_view_customer.setForeground(new Color(255,252,242));
        btn_view_customer.setFont(b);
        btn_view_customer.setFocusPainted(false);
        btn_view_customer.setBorder(null);
        btn_view_customer.setFocusPainted(false);
        Icon customer_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_customer.png");
        JLabel custicon=new JLabel(customer_icon);
        btn_view_customer.add(custicon);
        btn_view_customer.addMouseListener(this);
        nav.add(btn_view_customer);
        
        
        //View Policy Button        
        btn_view_policy=new JButton("  View Policy");
        btn_view_policy.setMaximumSize(new Dimension(400, 50));
        btn_view_policy.setBackground(new Color(3,29,68));
        btn_view_policy.setForeground(new Color(255,252,242));
        btn_view_policy.setFont(b);
        btn_view_policy.setFocusPainted(false);
        btn_view_policy.setBorder(null);
        btn_view_policy.setFocusPainted(false);
        Icon policy_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_policy.png");
        JLabel policyicon=new JLabel(policy_icon);
        btn_view_policy.add(policyicon);
        btn_view_policy.addMouseListener(this);
        nav.add(btn_view_policy);
        
        
        //Logout Button        
        btn_logout=new JButton("Logout");
        btn_logout.setMaximumSize(new Dimension(400, 50));
        btn_logout.setBackground(new Color(3,29,68));
        btn_logout.setForeground(new Color(255,252,242));
        btn_logout.setFont(b);
        btn_logout.setFocusPainted(false);
        btn_logout.setBorder(null);
        btn_logout.setFocusPainted(false);
        Icon logout_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\logout.png");
        JLabel logouticon=new JLabel(logout_icon);
        btn_logout.add(logouticon);
        btn_logout.addMouseListener(this);
        nav.add(btn_logout);
        
        
        
        
        //group layout horizontal
        grp_nav.setHorizontalGroup(grp_nav.createParallelGroup()
                .addGroup(grp_nav.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(lbl_we4u))
                .addComponent(btn_view_company)
                .addComponent(btn_view_policy)
                .addComponent(btn_view_customer)
                .addComponent(btn_logout)
        );
        
        //group layout vertical
        grp_nav.setVerticalGroup(grp_nav.createSequentialGroup()
                .addGroup(grp_nav.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lbl_we4u)).addGap(100)
                .addComponent(btn_view_company).addGap(50)
                .addComponent(btn_view_policy).addGap(50)
                .addComponent(btn_view_customer).addGap(50)
                .addComponent(btn_logout)
        );
        
        
        Font l=new Font("Microsoft YaHei Light", Font.BOLD,18);
        Font txt=new Font("Microsoft YaHei Light", Font.PLAIN,18);
        
        
        //View Company Content
        JPanel view_company=new JPanel();
        view_company.setLayout(new BoxLayout(view_company,BoxLayout.Y_AXIS));
        view_company.setBounds(400, 0, 1517, 1000);
        view_company.setBackground(new Color(187,222,251));
        
                //View Company table
                
                         //Filter Options
                        JPanel view_company_filter=new JPanel();
                        view_company_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_company_filter.setBackground(new Color(3,29,68));
                        view_company_filter.setMaximumSize(new Dimension(1300, 100));
                
                        JPanel search_by_state=new JPanel();
                        search_by_state.setBorder(new EmptyBorder(0,0,10,0));
                        search_by_state.setLayout(new FlowLayout(FlowLayout.CENTER));
                        JLabel filter_state=new JLabel("SEARCH BY STATE   ");
                        filter_state.setFont(b);
                        filter_state.setForeground(Color.WHITE);
                        search_by_state.add(filter_state);
                        
                        String state[]={"All","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Karnataka","Kerala","Chhattisgarh","Uttar Pradesh","Goa", "Gujarat","Himachal Pradesh",
                "Jammu and Kashmir","Jharkhand","West Bengal","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Punjab","Rajasthan","Sikkim",
                "Tamil Nadu","Telangana","Tripura","Uttarakhand","Andaman and Nicobar","Pondicherry","Dadra and Nagar Haveli","Daman and Diu","Delhi","Chandigarh","Lakshadweep"};
                
                        JComboBox cmb_filter_state = new JComboBox(state);
                        cmb_filter_state.setFont(txt);
                        cmb_filter_state.setPreferredSize(new Dimension(230, 40));
                        search_by_state.add(cmb_filter_state);       
                        
                        search_by_state.add(cmb_filter_state);
                        search_by_state.setBackground(new Color(3,29,68));
                        
                        
 
                        JLabel btn_search_state = new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                        btn_search_state.setPreferredSize(new Dimension(42, 42));
                        search_by_state.add(btn_search_state);
                        view_company_filter.add(search_by_state);
                        
                        
                                         
                        //Table                        
                        JPanel view_company_table=new JPanel();
                        view_company_table.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_company_table.setBackground(Color.white);
                        view_company_table.setMaximumSize(new Dimension(1300, 900));
                        
                        
                        String company[]= new String[6];
                         
                        String columnNames[]= {"         COMPANY NAME    ","      ESTD YEAR   ","            STATE   ","        DISTRICT  ","  NO OF POLICIES  ","NO OF CUSTOMERS  "};

                        companyTable=new JTable();

                        DefaultTableModel tableModel = (DefaultTableModel) companyTable.getModel();   
                        companyTable.setBorder(new EmptyBorder(20, 0, 0, 0));
                        companyTable.setPreferredSize(new Dimension(1300, 870));


                        for(int i=0;i<columnNames.length;i++) {
                                tableModel.addColumn(columnNames[i]);
                        }

                        companyTable.setBackground(new Color(227,242,253));
                        tableModel.addRow(columnNames);
                        
                        btn_search_state.addMouseListener(new MouseListener() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                try{ 
                                    
                                    int n=((DefaultTableModel)companyTable.getModel()).getRowCount();
                                   
                                    for(int i=n-1;i>=1;i--)
                                        ((DefaultTableModel)companyTable.getModel()).removeRow(i);

                                    

                                    Connection conn = DataBaseConnect.getConnection();
                                    Statement stmt = conn.createStatement();
                                    Statement stmt1 = conn.createStatement();
                                    Statement stmt2 = conn.createStatement();
                                                        
                                                            

                                    String sql="";
                                    if(cmb_filter_state.getSelectedItem().equals("All") ){

                                            sql="select * from companyregistration";
                                    }
                                                                   
                                    else{
                                        sql="select * from companyregistration where State='"+cmb_filter_state.getSelectedItem()+"' ";
                                    }
                                    
                                    
                                        
                                                   
                                        ResultSet rs=stmt.executeQuery(sql);
                                        while(rs.next()){
                                            ArrayList<String[]> data=new ArrayList<String[]>(); 
                                            company[0]=rs.getString("Company_Name");
                                            company[1]=rs.getString("Estd");
                                            company[2]=rs.getString("State");
                                            company[3]=rs.getString("District");
                                            
                                            String find_policy="select count(*) from policy where Company_id='"+rs.getString("Company_id")+"'";
                                            String find_customers="select count(*) from bought_policies where Company_id='"+rs.getString("Company_id")+"'";
                                            ResultSet count_policy=stmt2.executeQuery(find_policy);
                                            ResultSet count_cust=stmt1.executeQuery(find_customers); 
                                            if(count_policy.next() && count_cust.next()){
                                            String count_pol=count_policy.getString("count(*)"); 
                                            String count_cus=count_cust.getString("count(*)");
                                            
                                            company[4]=count_pol;
                                            company[5]=count_cus;
                                            }
                                            
                                            data.add(company);
                                            //adding in table
                                                tableModel.addRow(data.get(0));                                    
                                        
                                        }
                                    }
                                catch(Exception exp){
                                    exp.printStackTrace();
                                }       
                            }

            @Override
            public void mousePressed(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseExited(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

                        });
                        companyTable.getColumnModel().getColumn(0).setPreferredWidth(200);
                        companyTable.getColumnModel().getColumn(1).setPreferredWidth(50);
                        companyTable.getColumnModel().getColumn(2).setPreferredWidth(100);
                        
                                
                        JScrollPane scrollPane=new JScrollPane();
                        scrollPane.setViewportView(companyTable);                        

                        companyTable.setModel(tableModel);
                        companyTable.setRowHeight(30);
                        companyTable.setFont(txt);
                        view_company_table.add(companyTable);
                        
        view_company.add(view_company_filter);
        view_company.add(view_company_table);
        add(view_company);
        view_company.setVisible(true);
        
        
        
        
        //View Policy Content
        JPanel view_policy=new JPanel();
        view_policy.setLayout(new BoxLayout(view_policy,BoxLayout.Y_AXIS));
        view_policy.setBounds(400, 0, 1517, 1000);
        view_policy.setBackground(new Color(187,222,251));
        
                //View policy table
                
                         //Filter Options
                        JPanel view_policy_filter=new JPanel();
                        view_policy_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_policy_filter.setBackground(new Color(3,29,68));
                        view_policy_filter.setMaximumSize(new Dimension(1300, 100));
                
                        JPanel search_by_type=new JPanel();
                        search_by_type.setBorder(new EmptyBorder(0,0,10,0));
                        search_by_type.setLayout(new FlowLayout(FlowLayout.CENTER));
                        JLabel filter_type=new JLabel("SEARCH BY POLICY TYPE  ");
                        filter_type.setFont(b);
                        filter_type.setForeground(Color.WHITE);
                        search_by_type.add(filter_type);
                        
                        String filter_type_array[]={"All","Health Insurance","Life Insurance","Automobile Insurance","Property Insurance","Travel Insurance"};
                        JComboBox cmb_filter_type = new JComboBox(filter_type_array);
                        cmb_filter_type.setFont(txt);
                        cmb_filter_type.setPreferredSize(new Dimension(230, 40));
                        search_by_type.add(cmb_filter_type);       
                        
                        search_by_type.add(cmb_filter_type);
                        search_by_type.setBackground(new Color(3,29,68));
                        
                        JLabel filter_frequency=new JLabel("          SEARCH BY FREQUENCY  ");
                        filter_frequency.setFont(b);
                        filter_frequency.setForeground(Color.WHITE);
                        
                        
                        search_by_type.add(filter_frequency);
                        search_by_type.setBackground(new Color(3,29,68));
                        
                        
                        
                        
                        String filter_frequency_array[]={"All","Monthly","Quaterly","Semi-Annually","Annually"};
                        JComboBox cmb_filter_frequency = new JComboBox(filter_frequency_array);
                        cmb_filter_frequency.setFont(txt);
                        cmb_filter_frequency.setPreferredSize(new Dimension(230, 40));
                        search_by_type.add(cmb_filter_frequency);       
                        
                        search_by_type.add(cmb_filter_frequency);
                        search_by_type.setBackground(new Color(3,29,68));
 
                        JButton btn_search = new JButton(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                        btn_search.setPreferredSize(new Dimension(42, 42));
                        search_by_type.add(btn_search);
                        view_policy_filter.add(search_by_type);
                        
                        
                                         
                        //Table                        
                        JPanel view_policy_table=new JPanel();
                        view_policy_table.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_policy_table.setBackground(Color.white);
                        view_policy_table.setMaximumSize(new Dimension(1300, 900));
                        
                        
                        String policy[]= new String[8];
                        
                        String column[]= {"    COMPANY NAME","     POLICY TYPE","POLICY NAME"," PREMIUM"," FREQUENCY"," DURATION"," SUM INSURED"," INSURERS"};

                        policyTable=new JTable();

                        DefaultTableModel tableModel1 = (DefaultTableModel) policyTable.getModel();   
                        policyTable.setBorder(new EmptyBorder(20, 0, 0, 0));
                        policyTable.setPreferredSize(new Dimension(1300, 870));


                        for(int i=0;i<column.length;i++) {
                                tableModel1.addColumn(column[i]);
                        }

                        policyTable.setBackground(new Color(227,242,253));
                        tableModel1.addRow(column);
                        
                        btn_search.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {              
                                try{                           

                                    
                                    int n=((DefaultTableModel)policyTable.getModel()).getRowCount();
                                   
                                    for(int i=n-1;i>=1;i--)
                                        ((DefaultTableModel)policyTable.getModel()).removeRow(i);

                                    Connection conn = DataBaseConnect.getConnection();
                                    Statement stmt = conn.createStatement();
                                    
                                    Statement stmt1 = conn.createStatement();
                                    String company="select * from companyregistration";
                                    ResultSet rs1=stmt1.executeQuery(company);
                                    
                                    while(rs1.next()){
                                        
                                    

                                        String sql="";
                                        if(cmb_filter_type.getSelectedItem().equals("All") && cmb_filter_frequency.getSelectedItem().equals("All")){

                                                sql="select * from policy where Company_id='"+rs1.getString("Company_id")+"'";
                                        }
                                        else if(cmb_filter_type.getSelectedItem().equals("All")){
                                            sql="select * from policy where Company_id='"+rs1.getString("Company_id")+"' and Frequency='"+cmb_filter_frequency.getSelectedItem()+"'";
                                        }
                                        else if(cmb_filter_frequency.getSelectedItem().equals("All")){
                                            sql="select * from policy where Company_id='"+rs1.getString("Company_id")+"' and Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                                        }                                
                                        else{
                                            sql="select * from policy where Company_id='"+rs1.getString("Company_id")+"' and Frequency='"+cmb_filter_frequency.getSelectedItem()+"' and Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                                        }

                                            ResultSet rs=stmt.executeQuery(sql);
                                            while(rs.next()){
                                                ArrayList<String[]> data=new ArrayList<String[]>(); 
                                                policy[0]=rs1.getString("Company_Name");
                                                policy[1]=rs.getString("Policy_type");
                                                policy[2]=rs.getString("Policy_name");
                                                policy[3]=rs.getString("Premium");
                                                policy[4]=rs.getString("Frequency");
                                                policy[5]=rs.getString("Duration");
                                                policy[6]=rs.getString("Sum_insured");
                                                policy[7]="1"; 
                                                data.add(policy);
                                                //adding in table
                                                    tableModel1.addRow(data.get(0));                                    
                                            }                                
                                        }
                                }
                                    
                                    
                                catch(Exception exp){
                                    System.out.println(exp);
                                }             
                            }
                        });
                        policyTable.getColumnModel().getColumn(0).setPreferredWidth(100);
                        policyTable.getColumnModel().getColumn(1).setPreferredWidth(150);
                        policyTable.getColumnModel().getColumn(2).setPreferredWidth(60);
                        policyTable.getColumnModel().getColumn(3).setPreferredWidth(30);
                        policyTable.getColumnModel().getColumn(5).setPreferredWidth(30);
                        policyTable.getColumnModel().getColumn(7).setPreferredWidth(30);
                                
                        JScrollPane scrollPane1=new JScrollPane();
                        scrollPane1.setViewportView(policyTable);                        

                        policyTable.setModel(tableModel1);
                        policyTable.setRowHeight(30);
                        policyTable.setFont(txt);
                        view_policy_table.add(policyTable);
                        
        view_policy.add(view_policy_filter);
        view_policy.add(view_policy_table);
        add(view_policy);
        view_policy.setVisible(false);
       
     
        
        //View Customer Content
        JPanel view_customer=new JPanel();
        view_customer.setLayout(new BoxLayout(view_customer,BoxLayout.Y_AXIS));
        view_customer.setBounds(400, 0, 1517, 1000);
        view_customer.setBackground(new Color(187,222,251));
        
                //View Customer table
                
                        //Filter Options
                        JPanel view_cust_filter=new JPanel();
                        view_cust_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_cust_filter.setBackground(new Color(3,29,68));
                        view_cust_filter.setMaximumSize(new Dimension(1300, 100));
                
                        JPanel search_cust_by_type=new JPanel();
                        search_cust_by_type.setBorder(new EmptyBorder(0,0,10,0));
                        search_cust_by_type.setLayout(new FlowLayout(FlowLayout.CENTER));
                        JLabel filter_cust_type=new JLabel("SEARCH BY POLICY TYPE  ");
                        filter_cust_type.setFont(b);
                        filter_cust_type.setForeground(Color.WHITE);
                        search_cust_by_type.add(filter_cust_type);
                        
                        String filter_cust_type_array[]={"All","Health Insurance","Life Insurance","Automobile Insurance","Property Insuarnce","Travel Insurance"};
                        JComboBox cmb_cust_filter_type = new JComboBox(filter_cust_type_array);
                        cmb_cust_filter_type.setFont(txt);
                        cmb_cust_filter_type.setPreferredSize(new Dimension(230, 40));
                        search_cust_by_type.add(cmb_cust_filter_type);       
                        
                        search_cust_by_type.add(cmb_cust_filter_type);
                        search_cust_by_type.setBackground(new Color(3,29,68));
                        
                        JLabel filter_cust_frequency=new JLabel("          SEARCH BY FREQUENCY  ");
                        filter_cust_frequency.setFont(b);
                        filter_cust_frequency.setForeground(Color.WHITE);
                        
                        
                        search_cust_by_type.add(filter_cust_frequency);
                        search_cust_by_type.setBackground(new Color(3,29,68));                     
                        
                        
                        
                        String filter_cust_frequency_array[]={"All","Monthly","Quaterly","Semi-Annually","Annually"};
                        JComboBox cmb_cust_filter_frequency = new JComboBox(filter_cust_frequency_array);
                        cmb_cust_filter_frequency.setFont(txt);
                        cmb_cust_filter_frequency.setPreferredSize(new Dimension(230, 40));
                        search_cust_by_type.add(cmb_cust_filter_frequency);       
                        
                        search_cust_by_type.add(cmb_cust_filter_frequency);
                        search_cust_by_type.setBackground(new Color(3,29,68));
 
                        JButton btn_cust_search = new JButton(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                        btn_cust_search.setPreferredSize(new Dimension(42, 42));
                        search_cust_by_type.add(btn_cust_search);
                        view_cust_filter.add(search_cust_by_type);
                        
                        
                        
                        
                        view_cust_filter.add(search_cust_by_type);
                        
                            
                
                                         
                        //Table
                        
                        JPanel view_cust_policy_table=new JPanel();
                        view_cust_policy_table.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_cust_policy_table.setBackground(Color.white);
                        view_cust_policy_table.setMaximumSize(new Dimension(1300, 900));
                        
                        
                        String[] cust= new String[7];
                        

                        String column1[]= {"   CUSTOMER NAME","   POLICY NAME","   POLICY TYPE","COMPANY","FREQUENCY","DURATION","SUM INSURED"};

                        customerTable=new JTable();

                        DefaultTableModel tableModel2 = (DefaultTableModel) customerTable.getModel();   
                        customerTable.setBorder(new EmptyBorder(20, 0, 0, 0));
                        customerTable.setPreferredSize(new Dimension(1300, 870));
                        customerTable.setBackground(new Color(227,242,253));

                        for(int i=0;i<column1.length;i++) {
                                tableModel2.addColumn(column1[i]);
                        }

                        tableModel2.addRow(column1);

                                
                        btn_cust_search.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                
                                try{                           
                                    
                                    Connection conn = DataBaseConnect.getConnection();
                                    Statement stmt = conn.createStatement();

                                    String sql="";
                                    if(cmb_cust_filter_type.getSelectedItem().equals("All") && cmb_cust_filter_frequency.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies";
                                    }
                                    else if(cmb_cust_filter_type.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies where Frequency='"+cmb_cust_filter_frequency.getSelectedItem()+"'";
                                    }
                                    else if(cmb_cust_filter_frequency.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies where Policy_type='"+cmb_cust_filter_type.getSelectedItem()+"'";
                                    }                                
                                    else{
                                        sql="select * from bought_policies where Frequency='"+cmb_cust_filter_frequency.getSelectedItem()+"' and Policy_type='"+cmb_cust_filter_type.getSelectedItem()+"'";
                                    }
                                    ArrayList<String[]> data_cust=new ArrayList<String[]>();               
                                       ResultSet rs=stmt.executeQuery(sql);
                                       while(rs.next()){
                                           cust[0]=rs.getString("Customer_name");
                                           cust[1]=rs.getString("Policy_name");
                                           cust[2]=rs.getString("Policy_type");
                                           cust[3]=rs.getString("Company_Name");
                                           cust[4]=rs.getString("Frequency");
                                           cust[5]=rs.getString("Duration");
                                           cust[6]=rs.getString("Sum_insured");

                                           data_cust.add(cust);
                                           //adding in table
                                               tableModel2.addRow(data_cust.get(0));

                                       }
                                }
                                catch(Exception exp){
                                    System.out.println(exp);
                                }                
                            }
                        });
                        customerTable.getColumnModel().getColumn(0).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(1).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(2).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(5).setPreferredWidth(20);
                        customerTable.getColumnModel().getColumn(6).setPreferredWidth(20);
                                
                                
                        JScrollPane scrollPane2=new JScrollPane();
                        scrollPane2.setViewportView(customerTable);
                        

                        customerTable.setModel(tableModel2);
                        customerTable.setRowHeight(30);
                        customerTable.setFont(txt);
                        view_cust_policy_table.add(customerTable);



        view_customer.add(view_cust_filter);
        view_customer.add(view_cust_policy_table);
        add(view_customer);
        view_customer.setVisible(false);
        
        
        
        
        
        //Nav Button Action Listeners
        btn_view_company.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    view_company.setVisible(true);
                    view_policy.setVisible(false);
                    view_customer.setVisible(false);
                    
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        
        btn_view_policy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    
                    view_company.setVisible(false);
                    
                    view_policy.setVisible(true);
                    view_customer.setVisible(false);
                    
                   
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        
        btn_view_customer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    view_customer.setVisible(true);
                    view_company.setVisible(false);
                    
                    view_policy.setVisible(false);
                    
                    
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        
        
        btn_logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    setVisible(false);
                    
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }
        });
        
        setVisible(true);
    }
    public static void main(String argd[]){
        new AdminHome();
    }    

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       if(e.getSource().equals(btn_view_company)) {
             
             btn_view_company.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
             btn_view_company.setBackground(new Color(3,29,68));

	}
	if(e.getSource().equals(btn_view_policy)) {
			
			btn_view_policy.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_view_policy.setBackground(new Color(3,29,68));

        }
        if(e.getSource().equals(btn_view_customer)) {
			
			btn_view_customer.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_view_customer.setBackground(new Color(3,29,68));

        }
        
        if(e.getSource().equals(btn_logout)) {
			
			btn_logout.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_logout.setBackground(new Color(3,29,68));

        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(e.getSource().equals(btn_view_company)) {
            btn_view_company.setBorder(null);
            btn_view_company.setBackground(new Color(3,29,68));
	}
	if(e.getSource().equals(btn_view_policy)) {

            btn_view_policy.setBorder(null);
            btn_view_policy.setBackground(new Color(3,29,68));
	}
        if(e.getSource().equals(btn_view_customer)) {

            btn_view_customer.setBorder(null);
            btn_view_customer.setBackground(new Color(3,29,68));
	}
        
        if(e.getSource().equals(btn_logout)) {

            btn_logout.setBorder(null);
            btn_logout.setBackground(new Color(3,29,68));
	}
    }
    
}
