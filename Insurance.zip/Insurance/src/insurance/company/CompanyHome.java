package insurance.company;

import JavaBean.AddPolicyJB;
import JavaBean.CompanyRegistrationJB;
import database.DataBaseConnect;
import java.awt.Button;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class CompanyHome extends JFrame implements MouseListener{
    public JTable policyTable;
    private Map<String,ArrayList<String>> districtsMap;
    public JTable customerTable;
    String policy_id;
    private JButton btn_add_policy,btn_view_policy,btn_view_customer,btn_profile,btn_logout;
    
    public CompanyHome(String id){
        
        setLayout(null);
        setExtendedState(MAXIMIZED_BOTH); 
        setTitle("COMPANY HOME");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        Container co=getContentPane();
        co.setBackground(Color.lightGray);
        
        //Navigation
        JPanel nav=new JPanel();
        nav.setBounds(0, 0, 400, 1000);
        nav.setBackground(new Color(3,29,68));
        add(nav);
        
        //Group Layout
        GroupLayout grp_nav=new GroupLayout(nav);
        grp_nav.setAutoCreateGaps(true);
        grp_nav.setAutoCreateContainerGaps(true);
        nav.setLayout(grp_nav);
        
        
        //Title WE4U
        Font t=new Font("Georgia",Font.BOLD,45);
        JLabel lbl_we4u=new JLabel("           WE4U");
        //lbl_we4u.setBounds(84, 200, 300, 70);
        lbl_we4u.setForeground(Color.white);
        lbl_we4u.setFont(t);
        nav.add(lbl_we4u);
        
        
        //Add Policy Button
        Font b=new Font("Microsoft YaHei Light", Font.BOLD,20);
        btn_add_policy=new JButton("Add Policy");
        btn_add_policy.addMouseListener(this);
        btn_add_policy.setMaximumSize(new Dimension(400, 50));
        btn_add_policy.setBackground(new Color(3,29,68));
        btn_add_policy.setForeground(new Color(255,252,242));
        btn_add_policy.setFont(b);
        btn_add_policy.setBorder(null);
        btn_add_policy.setFocusPainted(false);        
       
        btn_add_policy.add(new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\add_policy.png")));
        nav.add(btn_add_policy);
        
        
        //View Policy Button        
        btn_view_policy=new JButton("View Policy");
        btn_view_policy.setMaximumSize(new Dimension(400, 50));
        btn_view_policy.addMouseListener(this);
        btn_view_policy.setBackground(new Color(3,29,68));
        btn_view_policy.setForeground(new Color(255,252,242));
        btn_view_policy.setFont(b);
        btn_view_policy.setBorder(null);
        btn_view_policy.setFocusPainted(false);
        btn_view_policy.add(new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_policy.png")));

        nav.add(btn_view_policy);
        
        //View Customer Button        
        btn_view_customer=new JButton("View Customer");
        btn_view_customer.setMaximumSize(new Dimension(400, 50));
        btn_view_customer.addMouseListener(this);
        btn_view_customer.setBackground(new Color(3,29,68));
        btn_view_customer.setForeground(new Color(255,252,242));
        btn_view_customer.setFocusPainted(false);
        btn_view_customer.setBorder(null);
        btn_view_customer.setFont(b);
        btn_view_customer.add(new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_customer.png")));

        nav.add(btn_view_customer);
        
        //Profile Button        
        btn_profile=new JButton("Profile");
        btn_profile.setMaximumSize(new Dimension(400, 50));
        btn_profile.addMouseListener(this);
        btn_profile.setBackground(new Color(3,29,68));
        btn_profile.setForeground(new Color(255,252,242));
        btn_profile.setFocusPainted(false);
        btn_profile.setBorder(null);
        btn_profile.setFont(b);
        btn_profile.add(new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\company.png")));

        nav.add(btn_profile);
        
        //Logout Button        
        btn_logout=new JButton("Logout");
        btn_logout.setMaximumSize(new Dimension(400, 50));
        btn_logout.addMouseListener(this);
        btn_logout.setBackground(new Color(3,29,68));
        btn_logout.setFocusPainted(false);
        btn_logout.setBorder(null);
        btn_logout.setForeground(new Color(255,252,242));
        btn_logout.setFont(b);
        btn_logout.add(new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\logout.png")));

        nav.add(btn_logout);
        
        
        
        
        //group layout horizontal
        grp_nav.setHorizontalGroup(grp_nav.createParallelGroup()
                .addGroup(grp_nav.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(lbl_we4u))
                .addComponent(btn_add_policy)
                .addComponent(btn_view_policy)
                .addComponent(btn_view_customer)
                .addComponent(btn_profile)
                .addComponent(btn_logout)
        );
        
        //group layout vertical
        grp_nav.setVerticalGroup(grp_nav.createSequentialGroup()
                .addGroup(grp_nav.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lbl_we4u)).addGap(100)
                .addComponent(btn_add_policy).addGap(50)
                .addComponent(btn_view_policy).addGap(50)
                .addComponent(btn_view_customer).addGap(50)
                .addComponent(btn_profile).addGap(50)
                .addComponent(btn_logout)
        );
        
        
        Font l=new Font("Microsoft YaHei Light", Font.BOLD,18);
        Font txt=new Font("Microsoft YaHei Light", Font.BOLD,18);
        //Add Policy Content
        JPanel add_policy=new JPanel();
        add_policy.setBounds(400, 0, 1517, 1000);
        add_policy.setBackground(new Color(187,222,251));
                    
                //Policy Form
                
                
                JPanel add_policy_form =new JPanel();
                add_policy_form.setBounds(500, 200, 500, 500);
                add_policy_form.setBackground(new Color(227,242,253));
                
                //Title
                JLabel space=new JLabel("                                                    ");
                space.setForeground(new Color(187,222,251));
                    
                space.setBackground(new Color(187,222,251));
                add_policy_form.add(space);
                
                JLabel temp=new JLabel("                     ADD POLICY                       ");
                temp.setFont(new Font("MicroSoft YaHei",Font.BOLD,24));
                add_policy_form.add(temp);
                
                JLabel lbl_policy_type = new JLabel("Policy Type");
                lbl_policy_type.setFont(l);
                add_policy_form.add(lbl_policy_type);
                
                String type[]={"Health Insurance","Life Insurance","Automobile Insurance","Property Insuarnce","Travel Insurance"};
                JComboBox cmb_policy_type = new JComboBox(type);
                cmb_policy_type.setFont(txt);
                cmb_policy_type.setBackground(Color.white);
                cmb_policy_type.setPreferredSize(new Dimension(100, 40));
                add_policy_form.add(cmb_policy_type);
                
                
                JLabel lbl_policy_name = new JLabel("Policy Name");
                lbl_policy_name.setFont(l);
                add_policy_form.add(lbl_policy_name);
                
                JTextField txt_policy_name = new JTextField();
                txt_policy_name.setFont(txt);
                add_policy_form.add(txt_policy_name);
                txt_policy_name.setPreferredSize(new Dimension(100, 40));
                
                JLabel lbl_premium = new JLabel("Premium");
                lbl_premium.setFont(l);
                add_policy_form.add(lbl_premium);  
                
                
                SpinnerModel value =new SpinnerNumberModel(500,500,50000,500);  
                
                JSpinner spr_premium = new JSpinner(value);
                spr_premium.setFont(txt);
                spr_premium.setPreferredSize(new Dimension(100, 40));
                add_policy_form.add(spr_premium);
                
                JLabel lbl_frequency = new JLabel("Frequency");
                lbl_frequency.setFont(l);
                add_policy_form.add(lbl_frequency);
                
                String frequency[]={"Monthly","Quaterly","Semi-Annually","Annually"};
                JComboBox cmb_frequency = new JComboBox(frequency);
                cmb_frequency.setFont(txt);
                cmb_frequency.setBackground(Color.white);
                cmb_frequency.setPreferredSize(new Dimension(100, 40));
                add_policy_form.add(cmb_frequency);
                
                
                JLabel lbl_duration = new JLabel("Duration");
                lbl_duration.setFont(l);
                add_policy_form.add(lbl_duration);  
                
                SpinnerModel d =new SpinnerNumberModel(1,1,100,1);  
                
                JSpinner spr_duration = new JSpinner(d);
                spr_duration.setFont(txt);
                spr_duration.setPreferredSize(new Dimension(100, 40));
                add_policy_form.add(spr_duration);
                
                JLabel lbl_sum_insured = new JLabel("Sum Insured");
                lbl_sum_insured.setFont(l);
                add_policy_form.add(lbl_sum_insured);
                
                SpinnerModel sum =new SpinnerNumberModel(10000,1000,100000000,1000);   
                
                JSpinner spr_sum_insured = new JSpinner(sum);
                spr_sum_insured.setFont(txt);
                spr_sum_insured.setPreferredSize(new Dimension(100, 40));
                add_policy_form.add(spr_sum_insured);
                
                
                
                
                JPanel add_panel=new JPanel();//UPDATE button
                add_panel.setBorder(new EmptyBorder(0,0,10,0));
                add_panel.setLayout(new FlowLayout(FlowLayout.CENTER));
                Button btn_add=new Button("ADD");
                btn_add.setFont(new Font("MicroSoft YaHei",Font.BOLD,25));
                btn_add.setPreferredSize(new Dimension(200,30));
                btn_add.setBackground(new Color(3,29,68));
                btn_add.setForeground(new Color(255,252,242));
                add_panel.add(btn_add);
                add_panel.setBackground(new Color(227,242,253));
                
                
                add_policy_form.add(add_panel);
                
                
                
                
                Border border_error = BorderFactory.createLineBorder(java.awt.Color.RED, 2);
                Border border_normal = BorderFactory.createLineBorder(java.awt.Color.BLACK, 1);
                
                
                //DataBase
                btn_add.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        
                        System.out.println(txt_policy_name.getText());
                        String name=txt_policy_name.getText();
                        String pat="[A-Z][a-z0-9 ]{2,}[A-Za-z0-9 ]*";
                        System.out.println(Pattern.matches(name,pat));
                        if(name.matches(pat)){                           
                            System.out.println(Pattern.matches(name,pat));
                            txt_policy_name.setBorder(border_normal);
                            String policy_id=UUID.randomUUID().toString();
                            try{

                                AddPolicyJB a=new AddPolicyJB();
                                a.setCompany_id(id);
                                a.setPolicy_id(policy_id);
                                a.setPolicy_name(txt_policy_name.getText());
                                a.setPolicy_type(String.valueOf(cmb_policy_type.getSelectedItem()));
                                a.setFrequency(String.valueOf(cmb_frequency.getSelectedItem()));
                                a.setPremium(Integer.valueOf(String.valueOf(spr_premium.getValue())));
                                a.setDuration(Integer.valueOf(String.valueOf(spr_duration.getValue())));
                                a.setSum_insured(Integer.valueOf(String.valueOf(spr_sum_insured.getValue())));

                                int no_of_pay=0;
                                String freq=a.getFrequency();
                                switch(freq){
                                    case "Monthly":{
                                        no_of_pay=a.getDuration()*12;
                                        break;
                                    }
                                    case "Quaterly":{
                                        no_of_pay=a.getDuration()*3;
                                        break;
                                    }
                                    case "Semi-Annually":{
                                        no_of_pay=a.getDuration()*2;
                                        break;
                                    }
                                    case "Anually":{
                                        no_of_pay=a.getDuration()*1;
                                        break;
                                    }
                                }
                                a.setNo_of_payments(no_of_pay);

                                Connection conn = null;
                                Statement stmt = null;
                                conn = DataBaseConnect.getConnection();
                                stmt = conn.createStatement();

                                String sql="insert into policy values('"+a.getCompany_id()+"',"
                                        + "'"+a.getPolicy_id()+"','"+a.getPolicy_type()+"',"
                                        + "'"+a.getPolicy_name()+"','"+a.getPremium()+"',"
                                        + "'"+a.getFrequency()+"','"+a.getDuration()+"',"
                                        + "'"+a.getSum_insured()+"','"+a.getNo_of_payments()+"')";

                                stmt.executeUpdate(sql);
                                JOptionPane.showMessageDialog(rootPane, "Policy Added!");
                                
                                stmt.close();
                                conn.close();
                            }
                            catch(Exception exp){
                                System.out.println(exp);
                            }
                        }                        
                        else{
                            txt_policy_name.setBorder(border_error);
                        }
                    }
                });
                
                
                //Group Layout 
                GroupLayout grp_add_policy=new GroupLayout(add_policy_form);
                grp_add_policy.setAutoCreateGaps(true);
                grp_add_policy.setAutoCreateContainerGaps(true);
                add_policy_form.setLayout(grp_add_policy);
                
                
                //group layout horizontal
                grp_add_policy.setHorizontalGroup(grp_add_policy.createParallelGroup()
                        .addGroup(grp_add_policy.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(space)).addGap(50)
                        .addComponent(temp)
                        .addComponent(lbl_policy_type).addComponent(cmb_policy_type)
                        .addComponent(lbl_policy_name).addComponent(txt_policy_name)
                        .addComponent(lbl_premium).addComponent(spr_premium)
                        .addComponent(lbl_frequency).addComponent(cmb_frequency)
                        .addComponent(lbl_duration).addComponent(spr_duration)
                        .addComponent(lbl_sum_insured).addComponent(spr_sum_insured)
                        .addComponent(btn_add)
                );

                //group layout vertical
                grp_add_policy.setVerticalGroup(grp_add_policy.createSequentialGroup()
                        .addGroup(grp_add_policy.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(space)).addGap(50)
                        .addComponent(temp).addGap(50)
                        .addComponent(lbl_policy_type).addGap(15).addComponent(cmb_policy_type).addGap(30)
                        .addComponent(lbl_policy_name).addGap(15).addComponent(txt_policy_name).addGap(30)
                        .addComponent(lbl_premium).addGap(15).addComponent(spr_premium).addGap(30)
                        .addComponent(lbl_frequency).addGap(15).addComponent(cmb_frequency).addGap(30)
                        .addComponent(lbl_duration).addGap(15).addComponent(spr_duration).addGap(30)
                        .addComponent(lbl_sum_insured).addGap(15).addComponent(spr_sum_insured).addGap(30)
                        .addComponent(btn_add)
                );

                
                add_policy.add(add_policy_form);
                
        add(add_policy);
        
        
        

        

        //View Policy Content
        JPanel view_policy=new JPanel();
        view_policy.setLayout(new BoxLayout(view_policy,BoxLayout.Y_AXIS));
        view_policy.setBounds(400, 0, 1517, 1000);
        view_policy.setBackground(new Color(187,222,251));
        
                //View policy table
                
                        
                
                         //Filter Options
                        JPanel view_policy_filter=new JPanel();
                        view_policy_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_policy_filter.setBackground(new Color(3,29,68));
                        view_policy_filter.setMaximumSize(new Dimension(1300, 100));
                
                        JPanel search_by_type=new JPanel();
                        search_by_type.setBorder(new EmptyBorder(0,0,10,0));
                        search_by_type.setLayout(new FlowLayout(FlowLayout.CENTER));
                        JLabel filter_type=new JLabel("SEARCH BY POLICY TYPE  ");
                        filter_type.setFont(l);
                        filter_type.setForeground(Color.WHITE);
                        search_by_type.add(filter_type);
                        
                        String filter_type_array[]={"All","Health Insurance","Life Insurance","Automobile Insurance","Property Insuarnce","Travel Insurance"};
                        JComboBox cmb_filter_type = new JComboBox(filter_type_array);
                        cmb_filter_type.setFont(txt);
                        cmb_filter_type.setPreferredSize(new Dimension(230, 40));
                        search_by_type.add(cmb_filter_type);       
                        
                        search_by_type.add(cmb_filter_type);
                        search_by_type.setBackground(new Color(3,29,68));
                        
                        JLabel filter_frequency=new JLabel("          SEARCH BY FREQUENCY  ");
                        filter_frequency.setFont(l);
                        filter_frequency.setForeground(Color.WHITE);
                        
                        
                        search_by_type.add(filter_frequency);
                        search_by_type.setBackground(new Color(3,29,68));
                        
                        
                        
                        
                        String filter_frequency_array[]={"All","Monthly","Quaterly","Semi-Annually","Annually"};
                        JComboBox cmb_filter_frequency = new JComboBox(filter_frequency_array);
                        cmb_filter_frequency.setFont(txt);
                        cmb_filter_frequency.setPreferredSize(new Dimension(230, 40));
                        search_by_type.add(cmb_filter_frequency);       
                        
                        search_by_type.add(cmb_filter_frequency);
                        search_by_type.setBackground(new Color(3,29,68));
 
                        JLabel btn_search = new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                        btn_search.setPreferredSize(new Dimension(42, 42));
                        search_by_type.add(btn_search);
                        
                        JLabel btn_edit = new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\edit.png"));
                        btn_edit.setPreferredSize(new Dimension(42, 42));
                        search_by_type.add(btn_edit);
                        
                        view_policy_filter.add(search_by_type);
                        
                        
                                         
                        //Table                        
                        JPanel view_policy_table=new JPanel();
                        view_policy_table.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_policy_table.setBackground(Color.WHITE);
                        view_policy_table.setMaximumSize(new Dimension(1300, 900));
                        
                        
                        String policy[]= new String[7];
                        
                        String columnNames[]= {"POLICY TYPE","POLICY NAME","PREMIUM","FREQUENCY","DURATION","SUM INSURED","INSURERS"};

                        policyTable=new JTable();
                        policyTable.setBackground(new Color(227,242,253));

                        DefaultTableModel tableModel = (DefaultTableModel) policyTable.getModel();   
                        policyTable.setBorder(new EmptyBorder(20, 0, 0, 0));
                        policyTable.setPreferredSize(new Dimension(1300, 870));
                        MatteBorder border = new MatteBorder(1, 1, 1,1, Color.BLACK);
                        policyTable.setGridColor(new Color(3, 29, 68));
                        policyTable.setBorder(border);
                        policyTable.setSelectionBackground(Color.white);
                        policyTable.setShowHorizontalLines(true);
                        policyTable.setShowVerticalLines(false);
                        policyTable.setIntercellSpacing(new Dimension(0,0));

                        for(int i=0;i<columnNames.length;i++) {
                                tableModel.addColumn(columnNames[i]);
                        }

                        
                        tableModel.addRow(columnNames);
                        
                        btn_search.addMouseListener(new MouseListener() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            try{
                                int n=((DefaultTableModel)policyTable.getModel()).getRowCount();

                                for(int i=n-1;i>=1;i--)
                                    ((DefaultTableModel)policyTable.getModel()).removeRow(i);


                                Connection conn = DataBaseConnect.getConnection();
                                Statement stmt = conn.createStatement();

                                String sql="";
                                if(cmb_filter_type.getSelectedItem().equals("All") && cmb_filter_frequency.getSelectedItem().equals("All")){

                                        sql="select * from policy where Company_id='"+id+"'";
                                }
                                else if(cmb_filter_type.getSelectedItem().equals("All")){
                                    sql="select * from policy where Company_id='"+id+"' and Frequency='"+cmb_filter_frequency.getSelectedItem()+"'";
                                }
                                else if(cmb_filter_frequency.getSelectedItem().equals("All")){
                                    sql="select * from policy where Company_id='"+id+"' and Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                                }                                
                                else{
                                    sql="select * from policy where Company_id='"+id+"' and Frequency='"+cmb_filter_frequency.getSelectedItem()+"' and Policy_type='"+cmb_filter_type.getSelectedItem()+"'";
                                }

                                    ResultSet rs=stmt.executeQuery(sql);
                                    while(rs.next()){
                                        ArrayList<String[]> data=new ArrayList<String[]>();    
                                        policy[0]=rs.getString("Policy_type");
                                        policy[1]=rs.getString("Policy_name");
                                        policy[2]=rs.getString("Premium");
                                        policy[3]=rs.getString("Frequency");
                                        policy[4]=rs.getString("Duration");
                                        policy[5]=rs.getString("Sum_insured");
                                        policy[6]="1"; 
                                        data.add(policy);
                                        //adding in table
                                            tableModel.addRow(data.get(0));
                                    }                                            
                                }
                            catch(Exception exp){
                                System.out.println(exp);
                            }     
                        }

                        @Override
                        public void mousePressed(MouseEvent e) {
                            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                        }

                        @Override
                        public void mouseReleased(MouseEvent e) {
                            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                        }

                        @Override
                        public void mouseEntered(MouseEvent e) {
                            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                        }
                    });
                        
                        
                        
                        
                        
                        policyTable.getColumnModel().getColumn(0).setPreferredWidth(100);
                        policyTable.getColumnModel().getColumn(1).setPreferredWidth(100);
                        policyTable.getColumnModel().getColumn(2).setPreferredWidth(100);
                        policyTable.getColumnModel().getColumn(6).setPreferredWidth(40);
                                
                        JScrollPane scrollPane=new JScrollPane();
                        scrollPane.setViewportView(policyTable);                        

                        policyTable.setModel(tableModel);
                        policyTable.setRowHeight(50);
                        policyTable.setFont(txt);
                        view_policy_table.add(policyTable);
                        
        view_policy.add(view_policy_filter);
        view_policy.add(view_policy_table);
        add(view_policy);
        view_policy.setVisible(false);
        
        
        
        
        
        
        //View Customer Content
        JPanel view_customer=new JPanel();
        view_customer.setLayout(new BoxLayout(view_customer,BoxLayout.Y_AXIS));
        view_customer.setBounds(400, 0, 1517, 1000);
        view_customer.setBackground(new Color(187,222,251));
        
                //View Customer table
                
                        //Filter Options
                        JPanel view_cust_filter=new JPanel();
                        view_cust_filter.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_cust_filter.setBackground(new Color(3,29,68));
                        view_cust_filter.setMaximumSize(new Dimension(1300, 100));
                
                        JPanel search_cust_by_type=new JPanel();
                        search_cust_by_type.setBorder(new EmptyBorder(0,0,10,0));
                        search_cust_by_type.setLayout(new FlowLayout(FlowLayout.CENTER));
                        JLabel filter_cust_type=new JLabel("SEARCH BY POLICY TYPE  ");
                        filter_cust_type.setFont(l);
                        filter_cust_type.setForeground(Color.WHITE);
                        search_cust_by_type.add(filter_cust_type);
                        
                        String filter_cust_type_array[]={"All","Health Insurance","Life Insurance","Automobile Insurance","Property Insuarnce","Travel Insurance"};
                        JComboBox cmb_cust_filter_type = new JComboBox(filter_cust_type_array);
                        cmb_cust_filter_type.setFont(txt);
                        cmb_cust_filter_type.setPreferredSize(new Dimension(230, 40));
                        search_cust_by_type.add(cmb_cust_filter_type);       
                        
                        search_cust_by_type.add(cmb_cust_filter_type);
                        search_cust_by_type.setBackground(new Color(3,29,68));
                        
                        JLabel filter_cust_frequency=new JLabel("          SEARCH BY FREQUENCY  ");
                        filter_cust_frequency.setFont(l);
                        filter_cust_frequency.setForeground(Color.WHITE);
                        
                        
                        search_cust_by_type.add(filter_cust_frequency);
                        search_cust_by_type.setBackground(new Color(3,29,68));                     
                        
                        
                        
                        String filter_cust_frequency_array[]={"All","Monthly","Quaterly","Semi-Annually","Annually"};
                        JComboBox cmb_cust_filter_frequency = new JComboBox(filter_cust_frequency_array);
                        cmb_cust_filter_frequency.setFont(txt);
                        cmb_cust_filter_frequency.setPreferredSize(new Dimension(230, 40));
                        search_cust_by_type.add(cmb_cust_filter_frequency);       
                        
                        search_cust_by_type.add(cmb_cust_filter_frequency);
                        search_cust_by_type.setBackground(new Color(3,29,68));
 
                        JLabel btn_cust_search = new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                        btn_cust_search.setPreferredSize(new Dimension(42, 42));
                        search_cust_by_type.add(btn_cust_search);
                        view_cust_filter.add(search_cust_by_type);
                        
                        
                        
                                         
                        //Table
                        
                        JPanel view_cust_policy_table=new JPanel();
                        view_cust_policy_table.setBorder(new EmptyBorder(20, 0, 0, 0));
                        view_cust_policy_table.setBackground(Color.WHITE);
                        view_cust_policy_table.setMaximumSize(new Dimension(1300, 1000));
                        
                        
                        String[] cust= new String[7];
                        

                        String column[]= {"CUSTOMER NAME","POLICY NAME","POLICY TYPE","PREMIUM","FREQUENCY","DURATION","SUM INSURED"};

                        customerTable=new JTable();

                        DefaultTableModel tableModel1 = (DefaultTableModel) customerTable.getModel();   
                        customerTable.setBorder(new EmptyBorder(20, 0, 0, 0));
                        customerTable.setPreferredSize(new Dimension(1300, 870));
                        customerTable.setBackground(new Color(227,242,253));
                        border = new MatteBorder(1, 1, 1,1, Color.BLACK);
                        customerTable.setGridColor(new Color(3, 29, 68));
                        customerTable.setBorder(border);
                        customerTable.setSelectionBackground(Color.white);
                        customerTable.setShowHorizontalLines(true);
                        customerTable.setShowVerticalLines(false);
                        customerTable.setIntercellSpacing(new Dimension(0,0));

                        for(int i=0;i<column.length;i++) {
                                tableModel1.addColumn(column[i]);
                        }

                        tableModel1.addRow(column);

                                
                        btn_cust_search.addMouseListener(new MouseListener() {
                            @Override
                            public void mouseClicked(MouseEvent e) {
                                try{                           
                                    String id="f28df4b8-5ff1-4c1f-8cd0-6f8bded37612";
                                    int n=((DefaultTableModel)customerTable.getModel()).getRowCount();
                                   
                                    for(int i=n-1;i>=1;i--)
                                        ((DefaultTableModel)customerTable.getModel()).removeRow(i);

                                    
                                    Connection conn = DataBaseConnect.getConnection();
                                    Statement stmt = conn.createStatement();

                                    String sql="";
                                    if(cmb_cust_filter_type.getSelectedItem().equals("All") && cmb_cust_filter_frequency.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies where Company_id='"+id+"'";
                                    }
                                    else if(cmb_cust_filter_type.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies where Company_id='"+id+"' and Frequency='"+cmb_cust_filter_frequency.getSelectedItem()+"'";
                                    }
                                    else if(cmb_cust_filter_frequency.getSelectedItem().equals("All")){
                                        sql="select * from bought_policies where Company_id='"+id+"' and Policy_type='"+cmb_cust_filter_type.getSelectedItem()+"'";
                                    }                                
                                    else{
                                        sql="select * from bought_policies where Company_id='"+id+"' and Frequency='"+cmb_cust_filter_frequency.getSelectedItem()+"' and Policy_type='"+cmb_cust_filter_type.getSelectedItem()+"'";
                                    }
                                                  
                                       ResultSet rs=stmt.executeQuery(sql);
                                       while(rs.next()){
                                           ArrayList<String[]> data_cust=new ArrayList<String[]>(); 
                                           cust[0]=rs.getString("Customer_name");
                                           cust[1]=rs.getString("Policy_name");
                                           cust[2]=rs.getString("Policy_type");
                                           cust[3]=rs.getString("Premium");
                                           cust[4]=rs.getString("Frequency");
                                           cust[5]=rs.getString("Duration");
                                           cust[6]=rs.getString("Sum_insured");

                                           data_cust.add(cust);
                                           //adding in table
                                           tableModel1.addRow(data_cust.get(0));
                                       }                                      
                                }
                                catch(Exception exp){
                                    System.out.println(exp);
                                }              
                            }

                            @Override
                            public void mousePressed(MouseEvent e) {
                                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                            }

                            @Override
                            public void mouseReleased(MouseEvent e) {
                                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                            }

                            @Override
                            public void mouseEntered(MouseEvent e) {
                                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                            }

                            @Override
                            public void mouseExited(MouseEvent e) {
                                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                            }
                        });
                        customerTable.getColumnModel().getColumn(0).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(1).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(2).setPreferredWidth(100);
                        customerTable.getColumnModel().getColumn(5).setPreferredWidth(20);
                        customerTable.getColumnModel().getColumn(6).setPreferredWidth(20);
                                
                                
                        JScrollPane scrollPane1=new JScrollPane();
                        scrollPane1.setViewportView(customerTable);
                        

                        customerTable.setModel(tableModel1);
                        customerTable.setRowHeight(30);
                        customerTable.setFont(txt);
                        view_cust_policy_table.add(customerTable);



        view_customer.add(view_cust_filter);
        view_customer.add(view_cust_policy_table);
        add(view_customer);
        view_customer.setVisible(false);
        
        
        
        
        //Profile content       
         
        JPanel area1=new JPanel();//creating main area
        
        area1.setLayout(new BoxLayout(area1,BoxLayout.Y_AXIS));
        area1.setBounds(400, 0, 1517, 1000);
        area1.setBackground(new Color(187,222,251));
        
        JPanel innerarea2=new JPanel();//This is for creating a gap between the innerarea1 and area1 
            innerarea2.setMaximumSize(new Dimension(100, 50));
            innerarea2.setBackground(new Color(187,222,251));
            
            
        JPanel innerarea1=new JPanel();// creating inner form
            innerarea1.setBorder(new EmptyBorder(20, 0, 0, 0));
            innerarea1.setBackground(new Color(227,242,253));
            innerarea1.setMaximumSize(new Dimension(600, 770));
            
            
                JPanel panel0=new JPanel();//creating a panel for Companyname(label and textfield)
                panel0.setBorder(new EmptyBorder(0,0,10,0));
                panel0.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel form_title=new JLabel("   PROFILE   ");
                form_title.setFont(new Font("MicroSoft YaHei",Font.BOLD,24));
                
                panel0.add(form_title);
                panel0.setBackground(new Color(227,242,253));
                innerarea1.add(panel0);
                
                
                JPanel panel1=new JPanel();//creating a panel for Companyname(label and textfield)
                panel1.setBorder(new EmptyBorder(0,0,10,0));
                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel companyname=new JLabel("Company Name    ");
                companyname.setFont(l);
               
                JTextField Companyname=new JTextField();
                Companyname.setFont(txt);
                Companyname.setPreferredSize(new Dimension(100, 35));
                Companyname.setColumns(15);
               
                panel1.add(companyname);
                panel1.add(Companyname);
                
                panel1.setBackground(new Color(227,242,253));
                innerarea1.add(panel1);
               
               
                JPanel panel2=new JPanel();//creating a panel for estd year(label and textfield)
                panel2.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel estd=new JLabel("Estd Year              ");
                estd.setFont(l);
               
                JTextField Estd=new JTextField();
                Estd.setPreferredSize(new Dimension(100, 35));
                Estd.setFont(txt);
                Estd.setColumns(15);
               
                panel2.add(estd);
                panel2.add(Estd);
                panel2.setBackground(new Color(227,242,253));
                innerarea1.add(panel2);
               
               
                JPanel panel4=new JPanel();//creating a panel for state(label and textfield)
                panel4.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_state=new JLabel("State                    ");
                lbl_state.setFont(l);
               
                String S[]={"Select","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Karnataka","Kerala","Chhattisgarh","Uttar Pradesh","Goa", "Gujarat","Himachal Pradesh",
                "Jammu and Kashmir","Jharkhand","West Bengal","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Punjab","Rajasthan","Sikkim",
                "Tamil Nadu","Telangana","Tripura","Uttarakhand","Andaman and Nicobar","Pondicherry","Dadra and Nagar Haveli","Daman and Diu","Delhi","Chandigarh","Lakshadweep"};
                JComboBox State=new JComboBox(S);
                State.setPreferredSize(new Dimension(260, 35));
                State.setFont(txt);
                State.setBackground(Color.white);
               
                panel4.add(lbl_state);
                panel4.add(State);
                panel4.setBackground(new Color(227,242,253));
                innerarea1.add(panel4);
                
                
                Object obj = null;
		try {
			obj = new JSONParser().parse(new FileReader("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\insurance\\districts.json"));
		} catch (Exception e) {
			e.printStackTrace();
		} 
        
	        JSONObject jo = (JSONObject) obj;
	        
	        ArrayList<String>states=new ArrayList<String>();
	        districtsMap=new HashMap<String,ArrayList<String>>();  
	        
	        JSONArray jsonArray=(JSONArray)jo.get("states");
	        
	        Iterator<JSONObject> it=jsonArray.iterator();
	        
	        while(it.hasNext()) {
	        	JSONObject temp1=it.next();
	        	String state=temp1.get("state").toString();
	        	states.add(state);
	        	
	        	JSONArray districtsJSONArray=(JSONArray)temp1.get("districts");
	        	
	        	 Iterator<String> it2=districtsJSONArray.iterator();
	        	 ArrayList<String> districts=new ArrayList<String>();
	        	 
	        	 while(it2.hasNext()) {
	        		 	districts.add(it2.next());
	        	 }
	        	 districtsMap.put(state,districts);
	        	
	        }
                
                JPanel panel3=new JPanel();//creating a panel for district(label and Datechooser(calendar))
                panel3.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel district=new JLabel("District                  ");
                district.setFont(l);
                
                
                JComboBox District=new JComboBox();
                State.addItemListener(new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent e) {
                        
                        if(e.getStateChange()==ItemEvent.SELECTED){
                            //District.add(districtsMap.get(State.getSelectedItem()).toArray());
                            District.removeAllItems();
                            Object dis[]=districtsMap.get(State.getSelectedItem()).toArray();
                            for(int d=0;d<dis.length;d++){
                                District.addItem(dis[d]);
                            }
                        }
                        
                    }
                });
                District.setFont(txt);                
                District.setPreferredSize(new Dimension(260, 35));
                District.setBackground(Color.white);
                
                panel3.add(district);
                panel3.add(District); 
                panel3.setBackground(new Color(227,242,253));
                innerarea1.add(panel3);
               
               
                JPanel panel5=new JPanel();//creating a panel for email(label and textfield)
                panel5.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel email=new JLabel("Email                    ");
                email.setFont(l);
               
                JTextField Email=new JTextField();
                Email.setFont(txt);
                Email.setPreferredSize(new Dimension(100, 35));
                Email.setColumns(15);
               
                panel5.add(email);
                panel5.add(Email);
                panel5.setBackground(new Color(227,242,253));
                innerarea1.add(panel5);
               
               
                JPanel panel6=new JPanel();//creating a panel for password(label and Passwordfield)
                panel6.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel6.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel password=new JLabel("Password              ");
                password.setFont(l);
               
                JTextField Password=new JTextField();
                Password.setFont(txt);
                Password.setPreferredSize(new Dimension(100, 35));
                Password.setColumns(15);
               
                panel6.add(password);
                panel6.add(Password);
                panel6.setBackground(new Color(227,242,253));
                innerarea1.add(panel6);
               
               
                JPanel panel7=new JPanel();//creating a panel for No.of Customers(label and textfield)
                panel7.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel7.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel noofcust=new JLabel("No.Of Customers   ");
                noofcust.setFont(l);
               
                JTextField Noofcust=new JTextField();
                Noofcust.setFont(txt);
                Noofcust.setPreferredSize(new Dimension(100, 35));
                Noofcust.setColumns(15);
               
                panel7.add(noofcust);
                panel7.add(Noofcust);
                panel7.setBackground(new Color(227,242,253));
                innerarea1.add(panel7);
               
               
                JPanel panel8=new JPanel();//creating a panel for No.of Policies(label and textfield)
                panel8.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel8.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel noofpolicy=new JLabel("No.Of Policies        ");
                noofpolicy.setFont(l);
               
                JTextField Noofpolicy=new JTextField();
                Noofpolicy.setFont(txt);
                Noofpolicy.setPreferredSize(new Dimension(100, 35));
                Noofpolicy.setColumns(15);
               
                panel8.add(noofpolicy);
                panel8.add(Noofpolicy);
                panel8.setBackground(new Color(227,242,253));
                innerarea1.add(panel8);
               
                JPanel panel9=new JPanel();//creating a panel for Ratings(label and SpinnerModel)
                panel9.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel9.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel ratings=new JLabel("Ratings                  ");
                ratings.setFont(l);
               
                JTextField Ratings=new JTextField();
                Ratings.setFont(txt);
                Ratings.setPreferredSize(new Dimension(100, 35));
                Ratings.setColumns(15);
               
                panel9.add(ratings);
                panel9.add(Ratings);
                panel9.setBackground(new Color(227,242,253));
                innerarea1.add(panel9);

               
                JPanel panel10=new JPanel();//creating a panel for IRDAI Number(label and textfield)
                panel10.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel10.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel irdai=new JLabel("IRDAI Number        ");
                irdai.setFont(l);
               
                JTextField Irdai=new JTextField();
                Irdai.setFont(txt);
                Irdai.setPreferredSize(new Dimension(100, 35));
                Irdai.setColumns(15);
               
                panel10.add(irdai);
                panel10.add(Irdai);
                panel10.setBackground(new Color(227,242,253));
                innerarea1.add(panel10);
               
                JPanel panel11=new JPanel();//UPDATE button
                panel11.setBorder(new EmptyBorder(0,0,10,0));
                panel11.setLayout(new FlowLayout(FlowLayout.CENTER));
                Button update=new Button("      UPDATE     ");
                update.setBackground(new Color(3,29,68));
                update.setForeground(new Color(255,252,242));
                update.setFont(new Font("MicroSoft YaHei",Font.BOLD,25));
                panel11.add(update);
                panel11.setBackground(new Color(227,242,253));
                innerarea1.add(panel11);
                
                
                
                //Getting details from table
                try{
                    
                    Connection conn = DataBaseConnect.getConnection();
                    Statement stmt = conn.createStatement();
                    Statement stmt1 = conn.createStatement();
                    Statement stmt2 = conn.createStatement();
                    String sql="select * from companyregistration where Company_id='"+id+"'";                    
                    String find_policy="select count(*) from policy where Company_id='"+id+"'";
                    String find_customers="select count(*) from bought_policies where Company_id='"+id+"'";
                    ResultSet count_policy=stmt.executeQuery(find_policy);
                    ResultSet count_cust=stmt1.executeQuery(find_customers);
                    if(count_policy.next() && count_cust.next()){
                        String count_pol=count_policy.getString("count(*)"); 
                        String count_cus=count_cust.getString("count(*)"); 
                        ResultSet rs=stmt2.executeQuery(sql);
                        while(rs.next()){
                            Companyname.setText(rs.getString("Company_name"));
                            Estd.setText(rs.getString("Estd"));
                            State.setSelectedItem(rs.getString("State"));
                            District.setSelectedItem(rs.getString("District"));
                            Email.setText(rs.getString("Email"));
                            Password.setText(rs.getString("Password"));
                            Noofcust.setText(String.valueOf(count_cus));Noofcust.setEditable(false);
                            Noofpolicy.setText(String.valueOf(count_pol));Noofpolicy.setEditable(false);
                            Ratings.setText(rs.getString("Ratings"));Ratings.setEditable(false);
                            Irdai.setText(rs.getString("IRDAI"));
                        }
                    }
                    
                }
                catch(Exception e){
                    System.out.println(e);
                }

                
                update.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String pwd_regex="^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9])[A-Za-z0-9]*[^A-Za-z0-9]$";
                        int count=0;
                        if(Companyname.getText().matches("[A-Za-z ]+")) count++;
                        else Companyname.setBorder(border_error);
                        if(Email.getText().matches("[a-z]+[@][a-z]+[.][a-z]+[a-z.]*")) count++;
                        else Email.setBorder(border_error);
                        if(Integer.valueOf(Estd.getText())>1950 && Integer.valueOf(Estd.getText())<2022) count++;
                        else Estd.setBorder(border_error);
                        if(Password.getText().matches(pwd_regex)) count++;
                        else Password.setBorder(border_error);
                        
                        
                        if(count==4){
                        
                            CompanyRegistrationJB c=new CompanyRegistrationJB();
                            c.setCompanyname(Companyname.getText());
                            System.out.println(Companyname.getText().matches("[A-Za-z ]+"));
                            c.setEstd(Integer.valueOf(Estd.getText()));
                            c.setState(String.valueOf(State.getSelectedItem()));
                            c.setDistrict(String.valueOf(District.getSelectedItem()));
                            c.setEmail(Email.getText());
                            c.setPassword(Password.getText());
                            c.setIRDAI(Irdai.getText());

                            Companyname.setBorder(border_normal);
                            Email.setBorder(border_normal);
                            Estd.setBorder(border_normal);
                            Password.setBorder(border_normal);
                            try{
                                Connection conn=null;
                                Statement stmt=null;
                                conn = DataBaseConnect.getConnection();
                                stmt = conn.createStatement();
                                String sql="update companyregistration set Company_Name='"+c.getCompanyname()+"',"
                                        + "Email='"+c.getEmail()+"',Password='"+c.getPassword()+"',"
                                        + "State='"+c.getState()+"',District='"+c.getDistrict()+"',"
                                        + "Estd='"+c.getEstd()+"',IRDAI='"+c.getIRDAI()+"' where Company_id='"+id+"'";
                                stmt.executeUpdate(sql);
                                stmt.close();
                                conn.close();
                                System.out.println("Successful!!");
                                JOptionPane.showMessageDialog(rootPane, "Updated !");
                            }
                            catch(SQLIntegrityConstraintViolationException s){
                                JOptionPane.showMessageDialog(rootPane, "IRDAI already in use!!!");
                                System.out.println(s);
                            }
                            catch(NullPointerException nul){
                                JOptionPane.showMessageDialog(rootPane, "Enter Details!");
                            }
                            catch(Exception err){                    

                                System.out.println(err);
                            }
                        }
                        
                    }
                });
                
         
        area1.add(innerarea2);
        area1.add(innerarea1);
        add(area1);
        area1.setVisible(false);
        
        
        
        JPanel delete_policy=new JPanel();//creating main area
        
        delete_policy.setLayout(new BoxLayout(delete_policy,BoxLayout.Y_AXIS));
        delete_policy.setBounds(400, 0, 1517, 1000);
        delete_policy.setBackground(new Color(187,222,251));
        
        JPanel gap=new JPanel();//This is for creating a gap between the innerarea1 and area1 
            gap.setMaximumSize(new Dimension(100, 50));
            gap.setBackground(new Color(187,222,251));
            
            
        JPanel delete_policy_form=new JPanel();// creating inner form
            delete_policy_form.setBorder(new EmptyBorder(20, 0, 0, 0));
            delete_policy_form.setBackground(new Color(227,242,253));
            delete_policy_form.setMaximumSize(new Dimension(600, 770));
            
            
                JPanel heading=new JPanel();//creating a panel for Companyname(label and textfield)
                heading.setBorder(new EmptyBorder(0,0,10,0));
                heading.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_heading=new JLabel("   EDIT POLICY   ");
                lbl_heading.setFont(new Font("MicroSoft YaHei",Font.BOLD,24));
                
                heading.add(lbl_heading);
                heading.setBackground(new Color(227,242,253));
                delete_policy_form.add(heading);
                
                
                JPanel select=new JPanel();//creating a panel for Companyname(label and textfield)
                select.setBorder(new EmptyBorder(0,0,10,0));
                select.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_select=new JLabel("Select Policy    ");
                lbl_select.setFont(txt);                
                select.add(lbl_select);
                
                JComboBox cmb_select=new JComboBox();
                cmb_select.setFont(txt);cmb_select.setBackground(Color.white);
                cmb_select.setPreferredSize(new Dimension(270, 35)); 
                select.add(cmb_select);
                JLabel search=new JLabel(new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\search.png"));
                search.setPreferredSize(new Dimension(42, 42));
                select.add(search);
                select.setBackground(new Color(227,242,253));
                delete_policy_form.add(select);
                
                try{
                    Connection conn=null;
                    Statement stmt=null;
                    
                    conn=DataBaseConnect.getConnection();
                    stmt=conn.createStatement();
                    
                    String sql="select Policy_name from policy where Company_id='"+id+"'";
                    
                    ResultSet rs=stmt.executeQuery(sql);
                    while(rs.next()){
                        cmb_select.addItem(rs.getString("Policy_name"));
                    }
                    rs.close();
                    stmt.close();
                    conn.close();
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
                
                
                
                
                JPanel policy_type=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_type.setBorder(new EmptyBorder(0,0,10,0));
                policy_type.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_type=new JLabel("Policy Type         ");
                lbl_type.setFont(txt);
               
                JComboBox cmb_policy_type1=new JComboBox(type);
                cmb_policy_type1.setFont(txt);
                cmb_policy_type1.setBackground(Color.white);
                cmb_policy_type1.setPreferredSize(new Dimension(270, 35));                
               
                policy_type.add(lbl_type);
                policy_type.add(cmb_policy_type1);                
                policy_type.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_type);
                
                
                JPanel policy_name=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_name.setBorder(new EmptyBorder(0,0,10,0));
                policy_name.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_name=new JLabel("Policy Name        ");
                lbl_name.setFont(txt);
               
                JTextField txt_name=new JTextField();
                txt_name.setFont(txt);
                txt_name.setPreferredSize(new Dimension(270, 35));                
               
                policy_name.add(lbl_name);
                policy_name.add(txt_name);                
                policy_name.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_name);
                
                
                JPanel policy_premium=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_premium.setBorder(new EmptyBorder(0,0,10,0));
                policy_premium.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_premium_amt = new JLabel("Premium             ");
                lbl_premium_amt.setFont(txt);
                policy_premium.add(lbl_premium_amt);                 
                JSpinner spr_premium_amt = new JSpinner(value);
                spr_premium_amt.setFont(txt);
                spr_premium_amt.setPreferredSize(new Dimension(270, 40));
                policy_premium.add(spr_premium_amt);                
                policy_premium.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_premium);
                
                
                
                
                JPanel policy_freq=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_freq.setBorder(new EmptyBorder(0,0,10,0));
                policy_freq.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_freq = new JLabel("Frequency           ");
                lbl_freq.setFont(txt);
                policy_freq.add(lbl_freq);              
                JComboBox cmb_freq = new JComboBox(frequency);
                cmb_freq.setFont(txt);
                cmb_freq.setBackground(Color.white);
                cmb_freq.setPreferredSize(new Dimension(270, 40));
                policy_freq.add(cmb_freq);                
                policy_freq.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_freq);
                
                JPanel policy_duration=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_duration.setBorder(new EmptyBorder(0,0,10,0));
                policy_duration.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_dur = new JLabel("Duration             ");
                lbl_dur.setFont(txt);
                policy_duration.add(lbl_dur);        
                JSpinner spr_dur = new JSpinner(d);
                spr_dur.setFont(txt);
                spr_dur.setPreferredSize(new Dimension(270, 40));
                policy_duration.add(spr_dur);
                policy_duration.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_duration);
                
                JPanel policy_sum=new JPanel();//creating a panel for Companyname(label and textfield)
                policy_sum.setBorder(new EmptyBorder(0,0,10,0));
                policy_sum.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel lbl_sum_insure= new JLabel("Sum Insured         ");
                lbl_sum_insure.setFont(l);
                policy_sum.add(lbl_sum_insure);
                
                JSpinner spr_sum_insure = new JSpinner(sum);
                spr_sum_insure.setFont(txt);
                spr_sum_insure.setPreferredSize(new Dimension(270, 40));
                policy_sum.add(spr_sum_insure);
                policy_sum.setBackground(new Color(227,242,253));
                delete_policy_form.add(policy_sum);
                
                
                JPanel modify=new JPanel();//creating a panel for Companyname(label and textfield)
                modify.setBorder(new EmptyBorder(0,0,10,0));
                modify.setLayout(new FlowLayout(FlowLayout.CENTER));
                JButton update_policy=new JButton("Update");
                update_policy.setBackground(new Color(3,29,68));
                update_policy.setForeground(new Color(255,252,242));
                update_policy.setFont(new Font("MicroSoft YaHei",Font.BOLD,25));
                update_policy.setFocusPainted(false);
                modify.add(update_policy);
                update_policy.setPreferredSize(new Dimension(150, 40));
                
                JButton btn_delete_policy=new JButton("Delete");
                btn_delete_policy.setBackground(new Color(3,29,68));
                btn_delete_policy.setForeground(new Color(255,252,242));
                btn_delete_policy.setFont(new Font("MicroSoft YaHei",Font.BOLD,25));
                btn_delete_policy.setFocusPainted(false);
                modify.add(btn_delete_policy);
                btn_delete_policy.setPreferredSize(new Dimension(150, 40));
                
                modify.setBackground(new Color(227,242,253));
                delete_policy_form.add(modify);
               
                search.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        try{
                            Connection conn=null;
                            Statement stmt=null;

                            conn=DataBaseConnect.getConnection();
                            stmt=conn.createStatement();

                            String sql="select * from policy where Policy_name='"+String.valueOf(cmb_select.getSelectedItem())+"'";

                            ResultSet rs=stmt.executeQuery(sql);

                            while(rs.next()){
                                policy_id=rs.getString("Policy_id");
                                cmb_policy_type1.setSelectedItem(rs.getString("Policy_type"));
                                txt_name.setText(rs.getString("Policy_name"));
                                spr_premium_amt.setValue(rs.getInt("Premium"));
                                cmb_freq.setSelectedItem(rs.getString("Frequency"));
                                spr_dur.setValue(rs.getInt("Duration"));
                                spr_sum_insure.setValue(rs.getInt("Sum_insured"));
                            }
                            rs.close();
                            stmt.close();
                            conn.close();
                        }
                        catch(Exception exp){
                            exp.printStackTrace();
                        }
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }
                });
                
                update_policy.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try{
                            Connection conn=null;
                            Statement stmt=null;

                            conn=DataBaseConnect.getConnection();
                            stmt=conn.createStatement();

                            System.out.println(policy_id);
                            
                            if((txt_name.getText()).matches("[A-Z][a-z0-9 ]{2,}[A-Za-z0-9 ]*")){
                                
                                AddPolicyJB a=new AddPolicyJB();
                                
                                
                                

                                a.setPolicy_name(txt_name.getText());
                                a.setPolicy_type(String.valueOf(cmb_policy_type1.getSelectedItem()));
                                a.setPremium(Integer.valueOf(String.valueOf(spr_premium_amt.getValue())));
                                a.setFrequency(String.valueOf(cmb_freq.getSelectedItem()));
                                a.setDuration(Integer.valueOf(String.valueOf(spr_dur.getValue())));
                                a.setSum_insured(Integer.valueOf(String.valueOf(spr_sum_insure.getValue())));
                                
                                int no_of_pay=0;
                                String freq=a.getFrequency();
                                switch(freq){
                                    case "Monthly":{
                                        no_of_pay=a.getDuration()*12;
                                        break;
                                    }
                                    case "Quaterly":{
                                        no_of_pay=a.getDuration()*3;
                                        break;
                                    }
                                    case "Semi-Annually":{
                                        no_of_pay=a.getDuration()*2;
                                        break;
                                    }
                                    case "Anually":{
                                        no_of_pay=a.getDuration()*1;
                                        break;
                                    }
                                }
                                a.setNo_of_payments(no_of_pay);
                                
                                String sql="update policy set Policy_type='"+a.getPolicy_type()+"',Policy_name='"+a.getPolicy_name()+"'"
                                        + ",Premium='"+a.getPremium()+"',Frequency='"+a.getFrequency()+"',Duration='"+a.getDuration()+"'"
                                        + ",Sum_insured='"+a.getSum_insured()+"',No_of_payments='"+a.getNo_of_payments()+"' where Policy_id='"+policy_id+"'";
                                
                                stmt.executeUpdate(sql);
                            }
                            
                            stmt.close();
                            conn.close();
                            System.out.println("Successful!!");
                            JOptionPane.showMessageDialog(rootPane, "Updated !");
                            
                        }
                        catch(Exception exp){
                            System.out.println(exp);
                        }
                    }
                });
                
                btn_delete_policy.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try{
                            Connection conn=null;
                            Statement stmt=null;

                            conn=DataBaseConnect.getConnection();
                            stmt=conn.createStatement();

                            System.out.println(policy_id);
                            String sql="delete from policy where Policy_id='"+policy_id+"'";
                            stmt.executeUpdate(sql);
                            
                            stmt.close();
                            conn.close();
                            
                            JOptionPane.showMessageDialog(rootPane, "Deleted !");
                        }
                        catch(Exception exp){
                            System.out.println(exp);
                        }
                    }
                });
                
                
                
         
        delete_policy.add(gap);
        delete_policy.add(delete_policy_form);
        add(delete_policy);
        delete_policy.setVisible(false);
        
        
        
        //Action Listener
        btn_edit.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try{
                    delete_policy.setVisible(true);
                    view_policy.setVisible(false);
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseExited(MouseEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        
        btn_add_policy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    add_policy.setVisible(true);
                    area1.setVisible(false);
                    view_policy.setVisible(false);
                    view_customer.setVisible(false);
                    
                   
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        
        btn_view_policy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    
                    add_policy.setVisible(false);
                    area1.setVisible(false);
                    view_policy.setVisible(true);
                    view_customer.setVisible(false);
                    
                   
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        
        btn_view_customer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    view_customer.setVisible(true);
                    add_policy.setVisible(false);
                    area1.setVisible(false);
                    view_policy.setVisible(false);
                    
                    
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        btn_profile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{                    
                    area1.setVisible(true);
                    add_policy.setVisible(false);
                    view_policy.setVisible(false);
                    view_customer.setVisible(false);
                    
                
                }
                catch(Exception exp){
                    System.out.println(exp);
                }               
            }
        });
        
        btn_logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    setVisible(false);
                    
                }
                catch(Exception exp){
                    System.out.println(exp);
                }
            }
        });
        
        setVisible(true);
    }
    public static void main(String argd[]){
        //new CompanyHome();
    }    

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       if(e.getSource().equals(btn_add_policy)) {
             
             btn_add_policy.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
             btn_add_policy.setBackground(new Color(3,29,68));

	}
	if(e.getSource().equals(btn_view_policy)) {
			
			btn_view_policy.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_view_policy.setBackground(new Color(3,29,68));

        }
        if(e.getSource().equals(btn_view_customer)) {
			
			btn_view_customer.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_view_customer.setBackground(new Color(3,29,68));

        }
        if(e.getSource().equals(btn_profile)) {
			
			btn_profile.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_profile.setBackground(new Color(3,29,68));

        }
        if(e.getSource().equals(btn_logout)) {
			
			btn_logout.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
			btn_logout.setBackground(new Color(3,29,68));

        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if(e.getSource().equals(btn_add_policy)) {
            btn_add_policy.setBorder(null);
            btn_add_policy.setBackground(new Color(3,29,68));
	}
	if(e.getSource().equals(btn_view_policy)) {

            btn_view_policy.setBorder(null);
            btn_view_policy.setBackground(new Color(3,29,68));
	}
        if(e.getSource().equals(btn_view_customer)) {

            btn_view_customer.setBorder(null);
            btn_view_customer.setBackground(new Color(3,29,68));
	}
        if(e.getSource().equals(btn_profile)) {

            btn_profile.setBorder(null);
            btn_profile.setBackground(new Color(3,29,68));
	}
        if(e.getSource().equals(btn_logout)) {

            btn_logout.setBorder(null);
            btn_logout.setBackground(new Color(3,29,68));
	}
    }
}