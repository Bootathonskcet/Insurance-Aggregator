package insurance.company;
import JavaBean.CompanyRegistrationJB;

import database.DataBaseConnect;
import java.awt.Container;
import java.util.*;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JComboBox;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import javax.swing.JTextField;
import javax.swing.JToggleButton;

import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class CompanyRegistration extends JFrame implements ItemListener,MouseListener{
    private Map<String,ArrayList<String>> districtsMap;
    JComboBox State,District;
    private JButton register;
    public CompanyRegistration(){
        setLayout(null);
        setExtendedState(MAXIMIZED_BOTH); 
        setTitle("COMPANY REGISTRATION");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\tree.png");
        setIconImage(icon);
        Container co=getContentPane();
        co.setBackground(java.awt.Color.LIGHT_GRAY);
       
        Font We4ufont=new Font("Georgia", Font.BOLD, 45);
        Font Buttonfont=new Font("Microsoft YaHei Light", Font.BOLD, 24);
        Font Textfont=new Font("Microsoft YaHei Light",Font.BOLD, 18);
        //Navigation bar
        JPanel nav=new JPanel();
        GroupLayout grouplayout=new GroupLayout(nav);
        nav.setBounds(0, 0, 400, 1000);
        nav.setBackground(new java.awt.Color(3,29,68));
        grouplayout.setAutoCreateGaps(true);
        grouplayout.setAutoCreateContainerGaps(true);
        nav.setLayout(grouplayout);
        add(nav);
           
            //Project title(WE4U)
            JLabel we4u=new JLabel("  WE4U");
            we4u.setForeground(Color.white);
            we4u.setFont(We4ufont);
       
           
            //Company registration button
            Icon company_icon=new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\view_company.png");
            JLabel compicon=new JLabel(company_icon);
            JButton companyreg=new JButton(" Company SignUp ");
            companyreg.setBackground(new java.awt.Color(3,29,68));
            companyreg.setForeground(new java.awt.Color(255,252,242));
            companyreg.setFocusPainted(false);
            companyreg.setMaximumSize(new Dimension(400, 50));
            companyreg.setFont(Buttonfont);
            companyreg.setBorder(null);
            companyreg.setFocusPainted(false);
           
           
           
            //adding the components of the nav bar using horizontalgroup method parallely
            grouplayout.setHorizontalGroup(grouplayout.createParallelGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.CENTER)
                    .addComponent(we4u)
                    .addComponent(compicon)
                    .addComponent(companyreg)
                   
                    ));
            // add the gaps between the components using verticalgroup method sequentially
            grouplayout.setVerticalGroup(grouplayout.createSequentialGroup()
                    .addGroup(grouplayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(we4u)).addGap(150)
                    .addComponent(compicon)
                    .addGap(10)
                    .addComponent(companyreg).addGap(75)
                 
            );
       
        // Main area(Customer area)
        JPanel area1=new JPanel();//creating main area
        JPanel innerarea2=new JPanel();//This is for creating a gap between the innerarea1 and area1
        JPanel innerarea1=new JPanel();// creating inner form
        area1.setLayout(new BoxLayout(area1,BoxLayout.Y_AXIS));
        area1.setBounds(400, 0, 1517, 1000);
        area1.setBackground(new java.awt.Color(187,222,251));
            innerarea2.setMaximumSize(new Dimension(100, 75));
            innerarea2.setBackground(new java.awt.Color(187,222,251));
            innerarea1.setMaximumSize(new Dimension(600, 650));
            innerarea1.setBorder(new EmptyBorder(20, 0, 0, 0));
            innerarea1.setBackground(new Color(227,242,253));
           
                JPanel panel1=new JPanel();//creating a panel for Companyname(label and textfield)
                panel1.setBorder(new EmptyBorder(0,0,10,0));
                panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
                JLabel Companyname_lbl=new JLabel("Company Name    ");
                Companyname_lbl.setFont(Textfont);
                panel1.setBackground(new Color(227,242,253));
               
                JTextField Companyname=new JTextField();
                Companyname.setFont(Textfont);
                Companyname.setPreferredSize(new Dimension(275,35));
                Companyname.setColumns(15);
               
                panel1.add(Companyname_lbl);
                panel1.add(Companyname);
                innerarea1.add(panel1);
               
               
                
                JPanel panel2=new JPanel();//creating a panel for estd year(label and textfield)
                panel2.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel2.setBackground(new Color(227,242,253));
                JLabel Estd_lbl=new JLabel("Estd Year              ");
                Estd_lbl.setFont(Textfont);
               
                JTextField Estd=new JTextField();
                Estd.setFont(Textfont);
                Estd.setPreferredSize(new Dimension(275,35));
                Estd.setColumns(15);
               
                panel2.add(Estd_lbl);
                panel2.add(Estd);
                innerarea1.add(panel2);
               
                
                JPanel panel3=new JPanel();//creating a panel for state(label and textfield)
                panel3.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel3.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel3.setBackground(new Color(227,242,253));
                JLabel State_lbl=new JLabel("State                    ");
                State_lbl.setFont(Textfont);
               
                String S[]={"--Select--","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Karnataka","Kerala","Chhattisgarh","Uttar Pradesh","Goa", "Gujarat","Himachal Pradesh",
                "Jammu and Kashmir","Jharkhand","West Bengal","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Punjab","Rajasthan","Sikkim",
                "Tamil Nadu","Telangana","Tripura","Uttarakhand","Andaman and Nicobar","Pondicherry","Dadra and Nagar Haveli","Daman and Diu","Delhi","Chandigarh","Lakshadweep"};
                JComboBox State=new JComboBox(S);
                State.setPreferredSize(new Dimension(260, 35));
                State.setBackground(Color.WHITE);
                State.setFont(Textfont);
               
                panel3.add(State_lbl);
                panel3.add(State);
                innerarea1.add(panel3);
                
                
                Object obj = null;
		try {
			obj = new JSONParser().parse(new FileReader("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\insurance\\districts.json"));
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
        
	        JSONObject jo = (JSONObject) obj;
	        
	        ArrayList<String>states=new ArrayList<String>();
	        districtsMap=new HashMap<String,ArrayList<String>>();  
	        
	        JSONArray jsonArray=(JSONArray)jo.get("states");
	        
	        Iterator<JSONObject> it=jsonArray.iterator();
	        
	        while(it.hasNext()) {
	        	JSONObject temp1=it.next();
	        	String state=temp1.get("state").toString();
	        	states.add(state);
	        	
	        	JSONArray districtsJSONArray=(JSONArray)temp1.get("districts");
	        	
	        	 Iterator<String> it2=districtsJSONArray.iterator();
	        	 ArrayList<String> districts=new ArrayList<String>();
	        	 
	        	 while(it2.hasNext()) {
	        		 	districts.add(it2.next());
	        	 }
	        	 districtsMap.put(state,districts);
	        	
	        }
                JPanel panel4=new JPanel();//creating a panel for district(label and Datechooser(calendar))
                panel4.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel4.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel4.setBackground(new Color(227,242,253));
                JLabel District_lbl=new JLabel("District                  ");
                
                District_lbl.setFont(Textfont);
                
                District=new JComboBox();
                State.addItemListener(new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent e) {
                        
                        if(e.getStateChange()==ItemEvent.SELECTED){
                            //District.add(districtsMap.get(State.getSelectedItem()).toArray());
                            District.removeAllItems();
                            Object dis[]=districtsMap.get(State.getSelectedItem()).toArray();
                            for(int d=0;d<dis.length;d++){
                                District.addItem(dis[d]);
                            }
                        }
                        
                    }
                });
                District.setFont(Textfont);
                
                District.setBackground(Color.white);                
                District.setPreferredSize(new Dimension(260, 35));
               
                panel4.add(District_lbl);
                panel4.add(District);
                innerarea1.add(panel4);
               
                
               
                JPanel panel5=new JPanel();//creating a panel for email(label and textfield)
                panel5.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel5.setLayout(new FlowLayout(FlowLayout.CENTER));
                panel5.setBackground(new Color(227,242,253));
                JLabel Email_lbl=new JLabel("Email                    ");
                Email_lbl.setFont(Textfont);
               
                JTextField Email=new JTextField();
                Email.setFont(Textfont);
                Email.setPreferredSize(new Dimension(275,35));
                Email.setColumns(15);
               
                panel5.add(Email_lbl);
                panel5.add(Email);
                innerarea1.add(panel5);
               
               
                JPanel panel6=new JPanel();//creating a panel for password(label and Passwordfield)
                panel6.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel6.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel6.setBackground(new Color(227,242,253));
                JLabel Password_lbl=new JLabel("  Password              ");
                Password_lbl.setFont(Textfont);
               
                JPasswordField Password=new JPasswordField();
                Password.setFont(Textfont);
                Password.setPreferredSize(new Dimension(275,35));
                Password.setColumns(15);
                
                Icon eyeicon = new ImageIcon("C:\\Users\\hp\\Documents\\NetBeansProjects\\Insurance\\src\\images\\eyeicon.png");
                JToggleButton eyebutton= new JToggleButton(eyeicon); 
                eyebutton.setBackground(new Color(227,242,253));
                eyebutton.setBorder(null);
                eyebutton.setFocusPainted(false);
                
                eyebutton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(eyebutton.isSelected()){
                            Password.setEchoChar((char)0); //By this line of code. We will actually see the actual characters
                            
                        }else{
                            Password.setEchoChar('•');
                            
                        }
                    }
                });
               
                
                panel6.add(Password_lbl);
                panel6.add(Password);
                panel6.add(eyebutton);
                innerarea1.add(panel6);
               
               
               
               /*
                JPanel panel7=new JPanel();//creating a panel for No.of Policies(label and textfield)
                panel7.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel7.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel7.setBackground(new Color(227,242,253));
                JLabel No_Of_Policy_lbl=new JLabel("No.Of Policies        ");
                No_Of_Policy_lbl.setFont(Textfont);
               
                JTextField No_Of_Policy=new JTextField();
                No_Of_Policy.setFont(Textfont);
                No_Of_Policy.setColumns(15);
               
                panel7.add(No_Of_Policy_lbl);
                panel7.add(No_Of_Policy);
                innerarea1.add(panel7);
                
                */
                

               
                JPanel panel8=new JPanel();//creating a panel for IRDAI Number(label and textfield)
                panel8.setBorder(new EmptyBorder(0, 0, 10, 0));
                panel8.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel8.setBackground(new Color(227,242,253));
                JLabel IRDAI_lbl=new JLabel("IRDAI Number       ");
                IRDAI_lbl.setFont(Textfont);
               
                JTextField IRDAI=new JTextField();
                IRDAI.setFont(Textfont);
                IRDAI.setPreferredSize(new Dimension(275,35));
                IRDAI.setColumns(15);
               
                panel8.add(IRDAI_lbl);
                panel8.add(IRDAI);
                innerarea1.add(panel8);
                innerarea1.add(Box.createRigidArea(new Dimension(0,75)));
               
    
                JPanel panel9=new JPanel();//Register button
                panel9.setBorder(new EmptyBorder(0,0,10,0));
                panel9.setLayout(new FlowLayout(FlowLayout.CENTER));
                 panel9.setBackground(new Color(227,242,253));
                JButton register=new JButton("     Register     ");
                register.setFocusPainted(false);
                register.setBackground(new java.awt.Color(3,29,68));
                register.setForeground(new java.awt.Color(255,252,242));
                register.setFont(new Font("Microsoft YaHei Light",Font.BOLD,20));
                register.setPreferredSize(new Dimension(170,40));
                register.setBorder(null);
                register.addMouseListener(this);
                panel9.add(register);
                innerarea1.add(panel9);
               
       
        area1.add(innerarea2);
        area1.add(innerarea1);
        add(area1);
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    CompanyRegistrationJB obj = new CompanyRegistrationJB();
                    obj.setCompanyname(Companyname.getText());
                    obj.setDistrict(District.getSelectedItem().toString());
                    obj.setEstd(Integer.parseInt(Estd.getText()));
                    obj.setState(State.getSelectedItem().toString());
                    obj.setEmail(Email.getText());
                    obj.setPassword(String.valueOf(Password.getPassword()));
                    obj.setIRDAI(IRDAI.getText());
//                    obj.setNo_of_Policies(No_Of_Policy.getText());
                    //border for error fields
                    Border border_error = BorderFactory.createLineBorder(java.awt.Color.RED, 2);
                    Border border_normal = BorderFactory.createLineBorder(java.awt.Color.BLACK, 1);
                   
                    int count=0;
                   
                    //firstname validation
                    if(Pattern.matches("[A-Z][a-z0-9 ]+[A-Za-z0-9 ]*",obj.getCompanyname().toString())){
                        count++;
                        Companyname.setBorder(border_normal);
                        Companyname.setText(obj.getCompanyname());
                    }
                    else{
                        Companyname.setBorder(border_error);
                        //Companyname.setText("Invalid name");
                    }
                    
                    //Year of birth establishment
                    if(obj.getEstd()>1900 && obj.getEstd()<2022){
                        count++;
                        Estd.setBorder(border_normal);
                    }
                    else{
                        Estd.setBorder(border_error);
                    }
                    //state validation
                    if(!obj.getState().equals("--Select--")){
                        count++;
                        State.setBorder(border_normal);
                        State.setSelectedItem(obj.getState());
                    }
                    else{
                        State.setBorder(border_error);
                        State.setSelectedItem("Invalid state");
                    }
                    //district validation
                    if(obj.getDistrict().length()>2){
                        count++;
                        District.setBorder(border_normal);
                        District.setSelectedItem(obj.getDistrict());
                    }
                    else{
                        District.setBorder(border_error);
                        District.setSelectedItem("Invalid district");
                    }
                    //email validation
                    String email_regex="^[a-z0-9]+[@]{1}[a-z.]+$";
                   
                    if(Pattern.matches(email_regex,obj.getEmail())){
                        count++;
                        Email.setBorder(border_normal);
                        Email.setText(obj.getEmail());
                    }
                    else{
                        Email.setBorder(border_error);
                        //Email.setText("Invalid email");
                    }
                    //password validation
                     String password_regex="^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9])[A-Za-z0-9]*[^A-Za-z0-9]$";
                    if(Pattern.matches(password_regex,obj.getPassword().toString())){
                        count++;
                        Password.setBorder(border_normal);
                        Password.setText(obj.getPassword().toString());
                    }
                    else{
                        Password.setBorder(border_error);
                        //Password.setText("Invalid password");
                    }
                    //Irdai validation
                    if(Pattern.matches("[0-9]{15}",obj.getIRDAI().toString())){
                        count++;
                        IRDAI.setBorder(border_normal);
                        IRDAI.setText(obj.getIRDAI());
                    }
                    else{
                        IRDAI.setBorder(border_error);
                        //IRDAI.setText("Invalid IRDAI no");
                    }
                    
                    /*
                    //no_of-policies validation
                    if(Integer.parseInt(obj.getNo_of_Policies())>=2){
                        count++;
                        No_Of_Policy.setBorder(border_normal);
                        No_Of_Policy.setText(obj.getNo_of_Policies());
                    }
                    else{
                        No_Of_Policy.setBorder(border_error);
                        //No_Of_Policy.setText("Invalid no of Policies");
                    }
                    */                    

                    System.out.println(count);
                    Connection conn = null;
                    Statement stmt = null;

                   
                    System.out.println("Connecting to database...");
                    conn = DataBaseConnect.getConnection();

                    //STEP 4: Execute a query
                    System.out.println("Creating statement...");
                    stmt = conn.createStatement();
                    String sql;
                    
                    String id=UUID.randomUUID().toString();
                    System.out.println(id);
                    
                    if(count==7){
                        sql ="INSERT INTO companyregistration values('"+id+"','"+obj.getCompanyname()+"','"+obj.getEmail()+"',"
                                + "'"+String.valueOf(obj.getPassword())+"','"+obj.getState()+"','"+obj.getDistrict()+"',"
                                + "'"+obj.getEstd()+"','"+obj.getIRDAI()+"',3)";
                        stmt.executeUpdate(sql);
                        
                        JOptionPane.showMessageDialog(rootPane, "Registration Success!");
                        setVisible(false);
                    }
                    
                    stmt.close();
                    conn.close();
                   
                }
                
                catch(SQLIntegrityConstraintViolationException sql){
                    JOptionPane.showMessageDialog(rootPane, "IRDAI already in use!!!");
                    System.out.println(sql);
                }
                catch(NullPointerException nul){
                    JOptionPane.showMessageDialog(rootPane, "Enter Details!");
                }
                catch(Exception err){                  
                    
                    System.out.println(err);
                }
            }
        });
           
       
        setVisible(true);
       
    }
    public static void main(String args[]){
        new CompanyRegistration();
    }
    @Override
    public void itemStateChanged(ItemEvent e) {

        if(e.getSource().equals(State)) {
            System.out.println(districtsMap.get(e.getItem().toString()));
            District.removeAllItems();

            Object[] districts=districtsMap.get(e.getItem().toString()).toArray();

            for(int i=0;i<districts.length;i++) {
                    District.addItem((String)districts[i]);
            }


        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if(e.getSource().equals(register)) {
             
             register.setBorder(new MatteBorder(1, 0, 1, 0, Color.WHITE));
             register.setBackground(new Color(3,29,68));

	}
    }

    @Override
    public void mouseExited(MouseEvent e) {
       if(e.getSource().equals(register)) {
            register.setBorder(null);
            register.setBackground(new Color(3,29,68));
	}
    }

    
}

