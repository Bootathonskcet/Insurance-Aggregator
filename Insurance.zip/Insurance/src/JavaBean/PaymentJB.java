
package JavaBean;
import java.time.LocalDate;
public class PaymentJB {
    private String Policy_name,Payment_time;
    private int Payment_amount;
    private LocalDate Payment_date;

    public void setPayment_amount(int Payment_amount) {
        this.Payment_amount = Payment_amount;
    }

    public void setPayment_date(LocalDate Payment_date) {
        this.Payment_date = Payment_date;
    }

    public void setPayment_time(String Payment_time) {
        this.Payment_time = Payment_time;
    }

    public void setPolicy_name(String Policy_name) {
        this.Policy_name = Policy_name;
    }

    public int getPayment_amount() {
        return Payment_amount;
    }

    public LocalDate getPayment_date() {
        return Payment_date;
    }

    public String getPayment_time() {
        return Payment_time;
    }

    public String getPolicy_name() {
        return Policy_name;
    }
    
}
