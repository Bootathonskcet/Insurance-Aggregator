package JavaBean;
public class CustomerRegistrationJB {
    private String FirstName,LastName,Email,Password,Date_Of_Birth,Adhaar_no,State,District,Mobile,Account_no;

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getEmail() {
        return Email;
    }

    public String getPassword() {
        return Password;
    }

    public String getDate_Of_Birth() {
        return Date_Of_Birth;
    }

    public String getAccount_no() {
        return Account_no;
    }

    public String getAdhaar_no() {
        return Adhaar_no;
    }

    public String getDistrict() {
        return District;
    }

    public String getMobile() {
        return Mobile;
    }

    public String getState() {
        return State;
    }

    public void setAccount_no(String Account_no) {
        this.Account_no = Account_no;
    }

    public void setAdhaar_no(String Adhaar_no) {
        this.Adhaar_no = Adhaar_no;
    }

    public void setDate_Of_Birth(String Date_Of_Birth) {
        this.Date_Of_Birth = Date_Of_Birth;
    }

    public void setDistrict(String District) {
        this.District = District;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setState(String State) {
        this.State = State;
    }
   
}