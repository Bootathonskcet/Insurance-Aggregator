package JavaBean;

import java.time.LocalDate;

public class BoughtPoliciesJB {
    private String Bought_id,Customer_id,Customer_name,Policy_id,Company_id,Policy_name,Company_name,Policy_type,Frequency;
    private LocalDate start_date,end_date,next_payment;
    private int no_of_payments,Premium,Duration,Sum_insured;

    public void setBought_id(String Bought_id) {
        this.Bought_id = Bought_id;
    }

    public void setCompany_id(String Company_id) {
        this.Company_id = Company_id;
    }

    public void setCustomer_name(String Customer_name) {
        this.Customer_name = Customer_name;
    }

    
    public void setCompany_name(String Company_name) {
        this.Company_name = Company_name;
    }

    public void setCustomer_id(String Customer_id) {
        this.Customer_id = Customer_id;
    }

    public void setDuration(int Duration) {
        this.Duration = Duration;
    }

    public void setEnd_date(LocalDate end_date) {
        this.end_date = end_date;
    }

    public void setFrequency(String Frequency) {
        this.Frequency = Frequency;
    }

    public void setNext_payment(LocalDate next_payment) {
        this.next_payment = next_payment;
    }

    public void setNo_of_payments(int no_of_payments) {
        this.no_of_payments = no_of_payments;
    }

    public void setPolicy_id(String Policy_id) {
        this.Policy_id = Policy_id;
    }

    public void setPolicy_name(String Policy_name) {
        this.Policy_name = Policy_name;
    }

    public void setPolicy_type(String Policy_type) {
        this.Policy_type = Policy_type;
    }

    public void setPremium(int Premium) {
        this.Premium = Premium;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public void setSum_insured(int Sum_insured) {
        this.Sum_insured = Sum_insured;
    }
    
    

    public String getBought_id() {
        return Bought_id;
    }

    public String getCompany_id() {
        return Company_id;
    }

    public String getCustomer_name() {
        return Customer_name;
    }

    
    public String getCompany_name() {
        return Company_name;
    }

    public String getCustomer_id() {
        return Customer_id;
    }

    public int getDuration() {
        return Duration;
    }

    public LocalDate getEnd_date() {
        return end_date;
    }

    public String getFrequency() {
        return Frequency;
    }

    public LocalDate getNext_payment() {
        return next_payment;
    }

    public int getNo_of_payments() {
        return no_of_payments;
    }

    public String getPolicy_id() {
        return Policy_id;
    }

    public String getPolicy_name() {
        return Policy_name;
    }

    public String getPolicy_type() {
        return Policy_type;
    }

    public int getPremium() {
        return Premium;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public int getSum_insured() {
        return Sum_insured;
    }
    
    
    
}
