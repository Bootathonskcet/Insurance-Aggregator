/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaBean;

/**
 *
 * @author hp
 */
public class AddPolicyJB {
    private String Company_id,Policy_id,Policy_type,Policy_name,Frequency;
    private int Premium,Duration,Sum_insured,No_of_payments;

    public void setCompany_id(String Company_id) {
        this.Company_id = Company_id;
    }

    public void setPolicy_id(String Policy_id) {
        this.Policy_id = Policy_id;
    }

    public void setPolicy_type(String Policy_type) {
        this.Policy_type = Policy_type;
    }

    public void setPolicy_name(String Policy_name) {
        this.Policy_name = Policy_name;
    }

    public void setFrequency(String Frequency) {
        this.Frequency = Frequency;
    }

    public void setPremium(int Premium) {
        this.Premium = Premium;
    }

    public void setDuration(int Duration) {
        this.Duration = Duration;
    }

    public void setSum_insured(int Sum_insured) {
        this.Sum_insured = Sum_insured;
    }

    public void setNo_of_payments(int No_of_payments) {
        this.No_of_payments = No_of_payments;
    }

    public String getCompany_id() {
        return Company_id;
    }

    public String getPolicy_id() {
        return Policy_id;
    }

    public String getPolicy_type() {
        return Policy_type;
    }

    public String getPolicy_name() {
        return Policy_name;
    }

    public String getFrequency() {
        return Frequency;
    }

    public int getPremium() {
        return Premium;
    }

    public int getDuration() {
        return Duration;
    }

    public int getSum_insured() {
        return Sum_insured;
    }

    public int getNo_of_payments() {
        return No_of_payments;
    }
    
    
    
}
