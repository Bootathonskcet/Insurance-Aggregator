package JavaBean;
public class CompanyRegistrationJB {
    private String Companyname,State,District,Email,Password,IRDAI;
    private int Estd;

    public void setCompanyname(String Companyname) {
        this.Companyname = Companyname;
    }
        
    

    public void setDistrict(String District) {
        this.District = District;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setEstd(int Estd) {
        this.Estd = Estd;
    }

    public void setIRDAI(String IRDAI) {
        this.IRDAI = IRDAI;
    }

    

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getCompanyname() {
        return Companyname;
    }

    public String getDistrict() {
        return District;
    }

    public String getEmail() {
        return Email;
    }

    public int getEstd() {
        return Estd;
    }

    public String getIRDAI() {
        return IRDAI;
    }

    

    public String getPassword() {
        return Password;
    }

    public String getState() {
        return State;
    }

}